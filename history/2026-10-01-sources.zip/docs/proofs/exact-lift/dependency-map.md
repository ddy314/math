# 关键公式依赖图

本文件对应原总稿 §42，用于从 exact lift 追踪到三分支终端系统和最终的 prefix-uniform 缺口。

## 本轮新增条件链与审计边界（2026-10-01）

- `canonical sphere + fixed original decimal word equation`
  → [共同三进正规化](global-framework.md#denominator-common-mod9)
  → 同 `v3(b_i)`、同 `c_i mod3` 下的 `sum c_i^2=0 mod9` 必要条件。
  违反者为空；通过者仍须满足原完整方程。
  同一 original plane 与 sphere 的
  [Gaussian norm identity](global-framework.md#denominator-word-norm)
  → `Delta_dec` 是有理二平方和
  → 剥离任意共同三进 content 后的 pair sum 不得为 `3/6 mod9`。
  此投影不另计独立高度预算。
  同模九单位分母 → 所有 `bi=b*10^ei` 分母射线为空；
  [单位前缀、一位尾分母](global-framework.md#unit-prefix-single-digit-denominator)
  则直接由 `3/2/5` unit 矛盾全部排除，不需要有限高度归约。
  [三个一位分母](global-framework.md#single-digit-denominator-complete-certificate)
  → triangle 与整数 sphere gap 的完整长度盒
  → 任意高度第一分子的精确 quadratic recovery
  → 两种 reader 各 `26,836,101` 行零原解的完整有限证书。
  该有限盒只覆盖一位分母，不对无界分母取并集。
  [一位 tail 的分母整除](global-framework.md#single-digit-tail-denominator-divisibility)
  → 原 word 的 `v_p(R)>=-v_p(beta)` 与 sphere 的最浅单位层
  → `b3|10Q`，跨三支且前缀无界；DD 读取为 `v=1`。
  该整除仅为必要条件。
  正 `E2>=2` 的 sphere 模八 → 相差一层的另外两分母数量为偶数；
  与一位尾 original word depth / denominator recovery 联立
  → [DD third-2-dominant](branches/double-deficit/core.md#single-digit-tail-third-two-dominant-closure)
  只余 `(17,6,8)` → unit 矛盾或有完整高度界的 7020 行有限证书。
  [唯一最大 denominator recovery](global-framework.md#denominator-complement-lcm-divisibility)
  → `bi|lcm(bj,bk,Ci)`（完整素幂）；固定后两分母可有效枚举第一分母，
  无界后缀并集仍不因此有限。
  [后两分母为一位的完整子域](global-framework.md#single-digit-denominator-suffix-complete-certificate)
  → 994 个分母投影经必要条件压到 19 组
  → 全部分子高度归约与精确 quadratic recovery
  → Python/C++ 两种 reader 各 3,804,494 行零原解。
  第一分母任意；多位第二/第三分母仍未统一归约。
  [DD 两位第二分母、尾八子层](branches/double-deficit/core.md#two-digit-second-eight-tail-complete-dd-certificate)
  → 3369 个完整分母投影压到五组
  → 高尾与短尾的全部高度盒（保留 `n2+n3>3`）
  → 两 reader 各 103,548,188 行零原解；可选 norm 长度筛不是闭合依赖。
  尾四的完整投影只余四组 → 全部分母乘二，suffix 位数与既约性不变
  → `D` 和 `q` 同乘二、sphere ghosts 不变 → 映入尾八证书；
  这是核对原 coefficient plane 后的合法转移，不使用 Gaussian flip。
- `joint integer + p+q<267/500 + true tail eta/(10u)`
  → [§10.8 正余量与尾部耦合](branches/a1-only/top-layer-r1-joint-halfgap-collapse.md#joint-surplus-curvature-wall-extension)
  → `E<(47/100)10^(N-2k)`、`contact+radius<51/100`
  → `N<=2k,N<=4g` 稳定区的整数矛盾。
  首个 `N=4g+1` 壳层再由 [§10.9 凸端点界](branches/a1-only/top-layer-r1-joint-halfgap-collapse.md#joint-surplus-first-radius-shell-upper-tail-collapse)
  排除 `u>=28/125`；低 `u` 五窗口仍开放。
  首个 contact 边界 `k+r=g` 再由
  [§10.10](branches/a1-only/top-layer-r1-joint-halfgap-collapse.md#joint-surplus-first-contact-wall-collapse)
  的初步凸界与位数耦合进一步排除整个 `1/10<=u<=529/1000` 子域。
  `y=0` 的实际 word / sphere 五进赋值再给
  [contact 深度约束](branches/a1-only/top-layer-r1-joint-halfgap-collapse.md#joint-surplus-contact-endpoint-5adic-depth)
  `nu+1<=v5(b3)<=nu+m3`；高深度 resonance 未关闭。
  两项 exact word gap 的 `2/5`-adic 形状再由
  [较浅首分母条件](branches/a1-only/top-layer-r1-joint-halfgap-collapse.md#joint-surplus-contact-endpoint-2adic-depth)
  联立：double-low 的 `n3` 奇偶冲突，regular double-high 的 `m3 mod3`
  冲突；regular mixed high 再由位数尺度冲突排除，留下 balanced。
  正整数 `D(1-u)` 又把 balanced 压到相对 `3r` gap。
  5-beta 的真实三项 cancellation 与 `2/5` 质量又给较浅首分母域的
  `13<=g<26r+6` 相对盒；去掉首分母条件时必须保留三种真实赋值分裂。
  条件之外、近 balanced 与 sign-resonance 仍未关闭。
- 原 A1 四层 carrier → `d=-1` 的 significand 严格递增；
  [balanced `2/5` denominator word gap](branches/a1-only/top-layer.md#lower-layer-decimal-denominator-kernel)
  → `0<=g<=1,e1!=e2` 的两个素数深度冲突，整个 unit 因子无界的子域为空。
  一般 `g` 的 unequal-prefix unit source 只余 `e3-e2=g` 的明确等深走廊；
  equal-prefix 正深度的 strict source 给 `m3=3(e3-e1)`；`g=0` 或
  `e3-e1>=g+2` 的 unit product 为 `11/19 mod20`，`g>=1` 的首个
  strict 层则为 `1/9 mod20`。`g=1,e3=e1+1` 的 resonance 为空。
  此链不使用最高层 joint-surplus 假设，其余 equal-prefix 与不平衡深度仍保留。
  pure equal-prefix 的原 sphere/word → `j|Q0` → `g=0` 奇数首深度为空、
  偶数首深度有明确相对盒 → `e=2` 的原 numerator recovery
  → `e=2/4` 的完整有限证书为空；`e=4` 用 C++ 精确核对 262,115,848
  个 gap，1377 个筛后状态再由 Python 原判别式复核。
  `g=0` pure equal-prefix balanced-tail 的偶数 `e>=6` 仍需继续恢复。
  同一实际 word / `V>=1` 与 contact 角点
  → `g=0,b1=b2=1` 的 balanced tail
  → 有完整长度界的 161 gap 行有限证书为空。
  任意第三分母下的 pure equal-prefix `d=2` 则由全 `g` contact 直接排除。
  `g>0,d=1` 的原平均第二坐标还含 `10^(-g)`；漏因子的推广已撤回，
  `g=1,delta=2` 改用 `V>=1` 的真实完整界
  → `d=0,k<=7` 与 `d=1,k<=9` → 30,923 gap 行零原解。
- `corrected one-channel short head + two-adic reader + same Schmidt defect budget`
  → [共享界 `3Gamma-2mu+delta<=(5/2)delta+o(1)`](branches/double-deficit/dd-gcd-normal-d0-gap-crt-dichotomy-2026-09-06.md#canonical-large-gap-exclusion)
  → exact `F_-=L(u+2v)a(g_*/v)` 与 Archimedean upper
  → `a/(d0*v)<=10^(-(K_*-(5/2)delta)S+o(S))`。
  只在 canonical `delta<=1/2` 无界序列上使用；ordinary CRT 代表不是矛盾。
  固定 `delta0<0.27644656895...` 时两单独 residues 都 ordinary 恢复 `a`，
  但其 parent 消去恰为旧 determinant，不能另记一份 payer。
- [A2 q4 的固定 `p_C` 点](branches/a2-only/outer-external-q4-root-split.md)
  → `(P2,P4)` 的唯一二阶 lift 与第三方程 normalized unit
  → 四对象共同深度至多一层。
  [actual 减向 transport](branches/a2-only/crt-descent-ledger.md#transport-direction-audit)
  重建 `H2/H4` 与 strict `(26/p)=+1` 条件；旧加向链及 fixed-3 generic
  `6/10` 精确深度降级。实际同源 sphere/plane normalization 再给
  [新 `8/12` 初项](branches/a2-only/fixed3-terminal-spill.md#fixed3-corrected-depths)
  → fixed-3 odd parity 只可能来自 `a2`-shallow f-contact，或须由 non-3 pool 补给。
  同源 `A3` 再给下一字层 `10` 的偶深度子片；初项零的 contact 不升级为空。
  [exact `eta=2` slots](branches/a2-only/fixed3-f-contact-orientation.md#eta2-contact-slots)
  → 八个 positive / `d<=2,e3=1` 类型；实际 `A3` 的额外 inert supplier
  建立同 `p_C` 分离与真实 gcd 接口，共同 `A3/That2/L23/qf` saturation
  至多一层 `11`，且该层不能复用 descendant common。未获得全 pool
  分离或 product 矛盾。
  actual `A3/q/GDelta` → 单层 `43/109` 且 outer units；
  `A3/f/GDelta` → 单层 `7`。
  inert-height 的真实 `p∤omega` 接口与整数 Bezout → 单层 `7/12569471`，
  后者 outer units；全共同复用仍留新的 `(3,4,-1) mod7` 必要 sheet。
  actual `eta=2` 恢复进一步只余两个 shared-7 类型
  → 对真实 `(m,cu,g)` 唯一的分子重构及 `m>=68/80` 必要长度
  → sphere 模三固定实际 `K/3=1`；明确 3/7 偶深度片须由其他 inert
  标签供给。这个 handoff 不额外增加高度预算，source/Hensel 兼容层仍开放。
- [DD 两-channel period](branches/double-deficit/dd-corrected-quartic-orientation-dependency-audit-2026-09-06.md#ordinary-gap-full-word-dictionary)
  在 fixed `a2+gap+orientations` 下给 `U*v1^2*v2`，而非联合参数族唯一性。
  直接枚举 `a2` → gap 至多一个 → prefix 至多一个，保留 `n2` 线性熵；
  与同一 denominator defect budget 联合后恢复
  [fixed `delta0<1/2` 的 global 稀疏性](branches/double-deficit/dd-corrected-terminal-global-sparsity-sharp-2026-09-06.md)。
  旧 fixed-denominator subexponential 边已降级；新 counting 仍不是空性。
  [全奇 DD 的二进 word-norm](branches/double-deficit/core.md#all-odd-decimal-norm-mod4-exclusion)
  则严格排除 `n3>m3>=3,Q*b3=1 mod4` 与 `m3=2,Q*b3=3 mod4` 子域，
  没有覆盖余类与 canonical 偶分母核心。
  canonical 原 word norm 再配同一 sharp defect budget，推出
  [`Z=1 mod4` 的 eventual 限制](branches/double-deficit/dd-corrected-terminal-two-adic-uz-neighborhood-2026-08-22.md#canonical-decimal-norm-z-mod4)；
  `Z=3 mod4` 无界 state 排除，有限例外与 `Z=1 mod4` 核心未关闭。

# 42. 当前主依赖与未闭合边

```text
正既约三块 + 原十进制 word
  -> 整数 sphere + 同一 coefficient plane
  -> denominator recovery / prime graph / rational two-square norm
  -> carrier 穷尽分类
       A2 -> source / endpoint / CRT / height
       DD -> exact gap / valuation funnel / ordinary reconstruction
       A1 -> four-layer contact / endpoint / numerator recovery
  -> 各专题的明确子域排除或有限证书
  -> 尚缺：覆盖三个完整无界分支的统一矛盾
```

- [公共框架](global-framework.md)：整数化、统一 tail、gap discriminant 和分母过滤。
- [A2](branches/a2-only/README.md)：现行 actual source normalization 与剩余 payer 接口。
- [DD](branches/double-deficit/README.md)：当前覆盖、非有效边界和 ordinary small-gap。
- [A1](branches/a1-only/README.md)：最高层稳定区、lower-layer kernel 和真正的 numerator recovery。
- [严格状态](status.md)：每条边的作用域与未闭合声明。

旧阶段的长公式链，包括已被新专题覆盖的数值和路线，原文保存在
[历史依赖账本](research-history-ledger.md#history-dependency)。
箭头表示已声明假设下的蕴含；未闭合边不因结构整理而补齐。
