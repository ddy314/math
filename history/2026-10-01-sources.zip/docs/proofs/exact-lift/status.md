# 严格证明状态与后续工作

本文件对应原总稿 §§32–39，是当前证明状态的权威入口。完整推导位于
公共框架及分支规范专题，中央入口只记录覆盖范围、证书和剩余核心。

## 状态边界（2026-10-01）

**主不存在性命题尚未完成证明。`A_2`、DD、`A_1` 三个完整分支均为
待证。** 下列结论只关闭所列子域，不推出无界分母的并集为空。

本轮已将 `main` 从 GitHub 快进到 `2cd7d73`，合并并保留此前的本地
joint-surplus 推进和范围修正。旧中央状态、依赖与阶段结论原文保存在
[研究历史账本](research-history-ledger.md)，不作为当前覆盖声明。

## 公共框架：严格排除与完整有限证书

| 状态 | 精确覆盖范围与结果 | 推导与验证入口 |
| --- | --- | --- |
| 已严格完成 | 同三进深度、同模三符号的分母须满足单位化平方和 `0 mod9`；等分母和任意 `bi=b*10^ei` 射线全空 | [共同模九](global-framework.md#denominator-common-mod9)；54 类中排除 36 类 |
| 已严格完成 | 原 word 的 rational two-square norm；共同三进 content 剥离后 pair sum 为 `3/6 mod9` 的无界子域全空 | [分母 norm](global-framework.md#denominator-word-norm)；702 类中排除 144 类 |
| 已严格完成 | `b1=b2=1,1<=b3<=9`，任意正既约分子全空 | [单位前缀](global-framework.md#unit-prefix-single-digit-denominator)；完整 `3/2/5` unit 矛盾 |
| 已严格完成：必要条件 | 任意原解满足 `bi|lcm(bj,bk,Ci)`；若 `b3<=9` 则 `b3|10Q` | [完整素幂 recovery](global-framework.md#denominator-complement-lcm-divisibility)、[一位尾整除](global-framework.md#single-digit-tail-denominator-divisibility)；通过者不判为原解 |
| 有限证书 | `1<=bi<=9`，全部分子高度经证明归约或精确恢复，零原解 | [一位分母完整证书](global-framework.md#single-digit-denominator-complete-certificate)；两 reader 各 `26,836,101` 行 |
| 有限证书 | `b1` 任意、`1<=b2,b3<=9`，所有分子高度全覆盖，零原解 | [一位分母后缀完整证书](global-framework.md#single-digit-denominator-suffix-complete-certificate)；994 分母投影压到 19 组，Python/C++ 各两 reader，`n3=1` 为 45,015 行，`n3>=2` 为 3,759,479 行 |

局部允许的模类不代表原解存在。有限证书的范围来自正文证明，
不来自任意搜索截断；后两分母固定可枚举第一分母不推出所有后缀有限。

## A1：当前覆盖

规范入口：[A1 README](branches/a1-only/README.md)。

| 状态 | 当前严格结果 | 作用域与剩余边界 |
| --- | --- | --- |
| 已严格完成 | joint-surplus 稳定区扩大到 `N<=2k`；首 radius 壳层排除 `u>=28/125`，首 contact 子片排除 `u<=529/1000` | [joint-surplus §10.8–10.10](branches/a1-only/top-layer-r1-joint-halfgap-collapse.md#joint-surplus-curvature-wall-extension)；amplified contact/radius/curvature 与低 significand 仍开放 |
| 已严格完成：必要条件与子域排除 | 首 contact 的完整 `2/5` word 深度，double-low/regular double-high/mixed-high 矛盾；近 beta 的相对盒 | [endpoint 深度](branches/a1-only/top-layer-r1-joint-halfgap-collapse.md#joint-surplus-contact-endpoint-2adic-depth)；较浅首分母假设须保留，三种真实首分母赋值与 sign/resonance 不混用 |
| 已严格完成 | `d=-1` 的前两分母 significand 严格递增；`g=0/1` 的 balanced `2/5` 深度 unequal-prefix 无界子域全空 | [lower-layer kernel §11](branches/a1-only/top-layer.md#lower-layer-decimal-denominator-kernel)；非十进制 unit 因子任意，一般 `g` 只给明确相对走廊 |
| 已严格完成 | pure equal-prefix 且 balanced-tail 的实际恢复要求 `j|Q0`，其中 `g=0` 奇数正首深度全空；任意 `g` 的 pure equal-prefix `d=2` contact 全空 | [同一 lower-layer 专题](branches/a1-only/top-layer.md#lower-layer-decimal-denominator-kernel)；最后一项允许任意第三分母，首 strict 层与更深层的 unit product 不同；`d=1` 深层 contact 只保留已核实的 `g=0` 范围 |
| 有限证书 | `g=0,b1=b2=10^e`、balanced tail 的 `e=2/4` 完整余核全空 | 同专题 LK21–22；`e=2` 为 219,101 gap 行；`e=4` C++ 为 262,115,848 gap 行，1377 个筛后状态由 Python 原判别式独立核对；偶数 `e>=6` 仍无界 |
| 有限证书 | `g=0,b1=b2=1` 的整个 balanced-tail 子域全空 | 同专题 LK24；161 个完整 gap 行；其他 `g` 与不平衡尾分母仍开放 |
| 有限证书 | pure equal-prefix balanced-tail 的 `g=1,delta=2` 首 strict 层全空 | 同专题 LK23；按真实 `V>=1` 归约 `d=0,k<=7`、`d=1,k<=9`，30,923 个完整 gap 行，保留唯一平方投影的整数/正性失败 |

一般 `g>=1` 的首 strict 层 `delta=g+1` 的 unit product 为 `1/9 mod20`；
只有 `g=0` 或 `delta>=g+2` 才用 `11/19 mod20`。错误的跨层推广已撤回。
原 quadratic recovery 的符号修正保留在规范专题，旧错误方向不参与证书。
`g>0` 的 contact 平均必须保留第二坐标的 `10^(-g)`；漏因子的
`d=1` 推广已降级。相关 `g=1,delta=2` 末端已扩大至完整 `k<=9`，
重算仍为零原解，不能沿用旧 contact 排除或旧计数。

## DD：当前覆盖

规范入口：[DD README](branches/double-deficit/README.md)。

| 状态 | 当前严格结果 | 作用域与剩余边界 |
| --- | --- | --- |
| 已严格完成：非有效渐近 | canonical `t2=1,delta<=1/2` 的 `a>=d0v` 不可随高度无界；最终进入 ordinary small-gap | [gcd-normal §10](branches/double-deficit/dd-gcd-normal-d0-gap-crt-dichotomy-2026-09-06.md#canonical-large-gap-exclusion)；有限例外、ordinary core 和 non-canonical 未排除 |
| 已严格完成：稀疏性 | 枚举真实 `a2` 后按同一两-channel period 恢复；与共享 defect budget 联合给固定 `delta0<1/2` 下的指数稀疏界 | [ordinary dictionary](branches/double-deficit/dd-corrected-quartic-orientation-dependency-audit-2026-09-06.md#ordinary-gap-full-word-dictionary)、[global sparsity](branches/double-deficit/dd-corrected-terminal-global-sparsity-sharp-2026-09-06.md)；稀疏性不推出空性 |
| 已严格完成 | 全奇分母的实际 word norm 模四排除，以及 canonical 的 eventual `Z=1 mod4` | [全奇二进过滤](branches/double-deficit/core.md#all-odd-decimal-norm-mod4-exclusion)、[Z unit](branches/double-deficit/dd-corrected-terminal-two-adic-uz-neighborhood-2026-08-22.md#canonical-decimal-norm-z-mod4)；其他余类和有效例外界仍待证 |
| 已严格完成与有限证书 | 一位尾 third-2-dominant 状态压到 `(17,6,8)`，低层 7020 行全空；后两分母一位的完整 DD 子域全空 | [third-2-dominant](branches/double-deficit/core.md#single-digit-tail-third-two-dominant-closure)、[完整后缀证书](branches/double-deficit/core.md#single-digit-last-two-denominators-complete-dd-certificate) |
| 已严格完成 | `b3=5,5∤b1b2,n3>=2,1<=m2<=2` 的 unique-5 无界前缀全空 | [gcd-normal §11](branches/double-deficit/dd-gcd-normal-d0-gap-crt-dichotomy-2026-09-06.md#single-digit-tail-v-one)；`m2>=3` 的移动 split 支持未统一排除 |
| 有限证书与严格转移 | `b1` 任意、`10<=b2<=99,b3=4/8,n3>=2,n2+n3>3` 的完整 DD 子层全空 | [尾八证书](branches/double-deficit/core.md#two-digit-second-eight-tail-complete-dd-certificate)：3369 个分母投影压到五组，两 reader 各 `103,548,188` 行；[尾四推论](branches/double-deficit/core.md#two-digit-second-four-tail-scaling-corollary)：2818 个分母投影压到四组，保持位数与既约性映入尾八层；`n2=1,n3=2` 与其他分支不在范围内 |

canonical Gaussian denominator norm 的 valuations 来自同一预算；
ordinary determinant 消去、inert `U/Z` 深度或同源 norm 不增加独立 payer。

## A2：修复后的当前覆盖

规范入口：[A2 README](branches/a2-only/README.md)。

| 状态 | 当前严格结果 | 作用域与剩余边界 |
| --- | --- | --- |
| 已严格完成 | fixed `pC` 四对象共同深度至多一层；actual 减向 transport 给真实 `H2/H3/H4` 和 strict `(26/p)=+1` 条件 | [transport 审计](branches/a2-only/crt-descent-ledger.md#transport-direction-audit)、[outer root](branches/a2-only/outer-external-q4-root-split.md)；更深 triple saturation boundary 仍开放 |
| 已严格完成 | actual source 重建 fixed-3 generic 深度 `8/12`；fixed-3 odd parity 只能由明确 f-contact 或 non-3 pool 支付；`eta=1` high-factor contact 排除 | [corrected 初项](branches/a2-only/fixed3-terminal-spill.md#fixed3-corrected-depths)、[orientation](branches/a2-only/fixed3-f-contact-orientation.md)；初项零不能直接定奇偶 |
| 已严格完成：必要条件 | `eta=2` 只余八个 positive 类型；full source/height/descendant/outer 共同复用只余一个单层 shared-7 sheet | [eta2 与 actual payer 接口](branches/a2-only/fixed3-f-contact-orientation.md#eta2-contact-slots)；该局部 sheet 与无限 Hensel lift 兼容，不升级为空 |
| 已严格完成：必要恢复 | shared-7 只余 `(31,51)/(527,3)`；按真实 `(m,cu,g)` 至多恢复一对分子，binary unit 窗口要求 `m>=68/80` | 同专题 §9；完整球面模三再强迫实际 `K/3=1 mod3`，明确的 3/7 偶深度片须由其他 inert 标签支付；没有新增独立高度预算 |

remaining source divisor、余数、球面和十进制窗口仍在无界 `m` 上。
标签局部分离不等于全 pool product-height 矛盾。

## 失效/降级与核对原则

- A2 的旧加向 transport、fixed-3 旧 generic `6/10` 深度已撤回，使用
  上述 actual source 重建结果。
- DD 的旧 fixed-denominator numerator `10^o(S)` 循环计数已降级；
  安全计数保留真实 `a2` 的线性熵，同一预算联合后的稀疏界不判空。
- Gaussian flip、重复 source character 和局部 payer 标签不自动保持
  原 coefficient plane，也不提供独立高度预算。
- 计算核对必须保留实际位数、既约性、整数平方根、退化方程和全部
  有界参数。`proof_tree.py check` 只检查结构，不是数学证明器。

# 32. 历史总关闭的审计边界

完全共享分母分解不推出空性；有限盒不能代替保持原 word 与位数的
无界下降；两个 gap 的文字尺度比较必须落实成明确矛盾。
完整原文见 [历史审计](research-history-ledger.md#history-status)。

# 33. 失效或降级路线

Gaussian flip 一般不保持原 coefficient plane；ordinary CRT 唯一性
不推出空性；重复 source-only character、class group 或固定目标定理
不自动增加独立高度预算。本轮 A2 加向 transport 与 DD 循环计数的
具体修正见上方权威条目与对应专题。

# 34. 有限证书的角色

先证明参数范围，再穷尽对应切片；精确平方根、既约性和真实位数均须
核对。完整的一位分母证书不覆盖多位分母。

# 35. 全局关闭的逻辑门槛

每个固定前缀的有限或唯一候选不推出所有前缀的并集有限或为空。
关闭无界分支需要覆盖全部参数的矛盾或有效统一上界和完整余项证书。

# 36. 当前严格证明状态

主不存在性命题尚未完成证明。`A_2`、DD、`A_1` 均为 **待证**；
本页开头区分已严格完成的子域、有限证书和失效/降级链。

# 37. 三个分支的剩余核心

| 分支 | 尚未统一排除的对象 | 权威入口 |
| --- | --- | --- |
| A2 | deep-even、剩余 source/height/CRT 与真实十进制窗口 | [A2](branches/a2-only/README.md) |
| DD | ordinary small-gap、canonical 有限例外、non-canonical/post-tail | [DD](branches/double-deficit/README.md) |
| A1 | amplified contact/radius/curvature、一般低层与非 balanced 分母 | [A1](branches/a1-only/README.md) |

# 38. 后续研究接口

从剩余系统回到同一原 sphere/word、真实整数恢复、位数和既约性。
优先寻找 prefix-uniform 的高度矛盾；允许局部点与失败路线应保留，
不以有限筛选或 payer 标签数量代替统一覆盖。

# 39. 主定理的完成标准

三个分支各给出可追溯的完整关闭证明，并核对分支分类穷尽。
在此之前，局部闭合和稀疏性界均不能提升为主不存在性定理。

历史阶段的完整状态、旧数字和攻关路线已原文保存在
[中央研究历史账本](research-history-ledger.md)。
