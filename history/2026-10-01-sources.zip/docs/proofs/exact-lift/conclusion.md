# 当前研究结论

# 43. 研究结论

截至 2026-10-01，**主不存在性命题仍为待证，三个异常分支均未全局关闭**。
本轮从 GitHub 快进同步到 `2cd7d73`，保留并合并已有本地研究改动。
当前严格范围以 [status.md](status.md) 和三个分支入口为准。

本轮按北京时间 **2026-10-01 02:00** 的上限结束新的证明研究和参数
搜索，并完成成果与入口规约。三个完整分支仍为待证，不能将本轮
子域证书提升为主不存在性定理。

本轮成果包括公共分母 norm/模九阻碍、完整一位分母后缀有限证书、A1 的
明确稳定区和低层分母排除、DD canonical 的渐近限制及二进 unit
排除、A2 actual transport 修复与同源 prime-power 接口。
各结果只在所列假设下使用，不扩大为完整分支空性。

| 分支 | 已推进的接口 | 当前全局缺口 |
| --- | --- | --- |
| [A2](branches/a2-only/README.md) | actual source、fixed-3 初项、endpoint slots、payer overlap | deep-even 与真实 source/height/CRT/window 统一矛盾 |
| [DD](branches/double-deficit/README.md) | 原 word norm、gap recovery、shared defect budget、有限低层证书 | ordinary small-gap、non-canonical/post-tail、有效全局高度界 |
| [A1](branches/a1-only/README.md) | joint-surplus 稳定区、four-layer denominator kernel、原 numerator quadratic | amplified 区域、一般低层和 moving-prefix 恢复 |

必须保留三个证明边界：

- 有限证书先依赖完整范围归约，不覆盖未设上界的分母并集。
- 非有效渐近界允许有限例外，稀疏性和唯一性允许非空候选。
- Gaussian flip、旧符号方向和重复 payer 不自动保持原 coefficient plane 或提供新预算。

[dependency-map.md](dependency-map.md) 给出当前依赖；
[research-history-ledger.md](research-history-ledger.md#history-conclusion)
保留整理前的阶段结论全文，供来源核对，不作为当前状态。

交付核对：本轮涉及的 26 个 Python 核对入口与 2 个 C++ 核对源码
均有成功的精确核验记录；C++ 完整 UBSan 复算、源码编译、196 个
证明文档的结构检查、131 处新增内部锚点链接和 `git diff --check`
通过。历史归并的三个正文块逐字保全，`archive/`、项目依赖与锁文件
未修改。`pytest` 未安装，未记为通过的检查。改动保存于本地，未提交或推送。
