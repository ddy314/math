# 中央研究历史账本

本文件于 2026-10-01 将状态、依赖图与结论入口中的历史接续机械归并。
三个来源正文保持原文，公式、证明标签和旧章节编号均未改写；
`archive/` 的原始快照未修改。

**用途：历史追溯。** 这些旧状态会包含后来被更新或撤回的结论，
不能作为当前覆盖范围。当前权威入口为 [status.md](status.md)，
数学推导以三个分支的现行规范专题为准。

- [旧状态与失败路线](#history-status)
- [旧公式依赖](#history-dependency)
- [旧阶段结论](#history-conclusion)

归并时逐块校验的原文记录（不含本文件的来源标题和分隔注释）：

| 来源 | 原文行数 | SHA256 |
| --- | ---: | --- |
| `status.md` 历史段 | 1923 | `f621533533cdb6b66c2956a4bce6463d04e3df47aa68c12325d0e7cfccf3301c` |
| `dependency-map.md` 历史段 | 1514 | `9d839b96a6b596030a73f00c281170e2eaa58c78d11bc5f33333b776b7d5da27` |
| `conclusion.md` 原文 | 324 | `c7c7f16ce3c4da3adf76b0892e8ba4e2f93e472b0164d8998968109ddf647efa` |

<a id="history-status"></a>

> 整合来源：`status.md`（2026-10-01 归并前正文；不是当前状态）。

## 2026-09-06 本轮推进与范围审计

- **已严格完成：** A1 最高层 `d=2,g>=1` 的
  [joint-surplus 定理](branches/a1-only/top-layer-r1-joint-halfgap-collapse.md#joint-surplus-stable-region)
  排除 `N=max(r+g+1,s)` 满足 `k+s>=2g+2,k+r>=g+1,N<=4g,N<=2k-1`
  的全部候选。特别地 `k>=2g+1,1<=r<=3g-1,1<=s<=4g` 整片无界区域为空。
  新增覆盖包含 `r,s>=2` 的内部，不只是原来分别处理的两条边界。
- **失效/降级：** 旧 `r=1` joint-half-gap 证明缺少 `k>=g`；已补齐其
  定理和 frontier 的适用范围。此审计没有给出原命题反例。
- **状态同步：** 下方 A1 “尚存候选必须 `k=g>=32`”只适用于旧的
  minimal-diagonal 子问题，不能代表全 A1。后续已有闭合记录，见
  [A1 入口](branches/a1-only/README.md)；本轮不把未重新核验的旧证书记作新成果。
- **待证：** A1 最高层突破上述稳定区的 amplified contact/radius/curvature
  区域、`g=0` 与 `d=-1,0,1`，以及 A2、DD 的其余无界核心。

本轮符号和精确有理常数核对通过；无界结论来自专题中的完整不等式证明。
后续专题导航已补回三个分支入口；补链接不提升任何证明状态。

## 2026-08-20 当前前沿

本节是 2026-08-20 导航快照，由后续专题与上方更新覆盖；下方 2026-08-13 DD 合并状态与 §§32–39 保留为历史状态、失效路线和证明边界的详细记录。

- **`A_2`：`待证`。** endpoint/source/height/CRT 工作已排除或降级大量局部分配，并把 denominator 接触压到 pure-prefix gcd、固定 `11,23` lift 与真实 sphere-height channel；但 `m_2>=11` 的无界 deep-even 核及这些剩余通道尚未统一排除。详见 [A2 入口](branches/a2-only/README.md)。
- **DD：`待证`。** 旧 equality frontier 已严格关闭，故无界解若存在则 `limsup n_3/S<6.308883577618...`；canonical `t_2=1` double-resonant funnel 可压到 `limsup n/S<=6`，但该界尚未覆盖全部 DD dominant states，也没有有效绝对高度界。当前缺口是 projective/gap、bottom/common-numerator 与 residual split-Gaussian payer 的 simultaneous height bound。详见 [DD 入口](branches/double-deficit/README.md)。
- **`A_1`：`待证`。** fixed layers `1<=k=g<=31` 已由有限证书关闭，central denominator 在 `k=g>=26` 时为空；尚存候选必须进入 `k=g>=32` 的 deep denominator，核心为统一 `2`-high/`5`-low master branch。详见 [A1 入口](branches/a1-only/README.md)。

仓库整理只改变材料的物理组织与导航，不提升任何数学结论。细粒度来源已机械归并进各分支的研究账本，并保留原标题、正文、证明状态和来源锚点。

## 2026-08-13 DD 合并状态

本节覆盖下方由 2026-08-10 原总稿机械拆分出的 DD 旧状态。完整命题、假设、推导与逻辑修正见
[DD 主干 §27.33](branches/double-deficit/core.md#2733-2026-08-13-后续合并进展)。

- **`已严格完成`**：§27.33 的解析与局部算术推导证明 `n_3=8S_12-1` 整层为空，故 `n_3<=8S_12-2`；同时有 prefix-uniform 解析锥 `n_3<31S_12/4+6581/960`，以及 11 个固定 surplus modes。
- **`有限证书`**：`S_12=5,n_3=39,m_3=17,...,21` 的精确 Hensel--CRT / 判别平方证书为空，与已有的 `m_3=14,15,16,22,...,32` 证书合并后关闭整个该尺寸。
- **`已严格完成`（依赖经典外部定理，阈值非有效）**：固定目标 Schmidt Subspace Theorem 给出 `limsup m_3/S_12<=5` 与 `limsup_DD n_3/S_12<=6.308883577618...`。这些是渐近结论，不给出可计算的绝对 `S_12` 上界。
- **`已严格完成`（frontier 条件蕴含）**：若存在逼近 `6.308883...` frontier 的无界 DD 序列，则其位数比例、S-unit phase、rough cofactors 和 denominator imbalance 被压到唯一渐近形状；固定 moving Gaussian core `(C_L,Pi)` 后，`A_0`、`A_12` 与最后的 `q_c/R_2` lift 至多唯一。这些结论只在假想 frontier sequence 上使用。
- **`失效/降级`**：`g_*` 不是独立高度惩罚；terminal Pell-like cancellation 只是 prefix norm 的重写；继续单素数 Hensel、ordinary quadratic character 或重复 fixed-target Subspace Theorem 都不能当作新闭合步骤。
- **`待证`**：DD 全局空性、有效绝对界 `S_12<=S_0`、moving pair-max Gaussian core 的 uniform elimination，以及一般 projective/common-scale 与 5-adic angular allocation 仍未完成。

## 维护规则

这里的清单必须与三个分支文件同步。新增局部结论时，要说明它属于 `已严格完成`、`有限证书`、`待证` 或 `失效/降级` 哪一类。有限切片不能自动提升为 prefix-uniform 的全局结论。

## 研究优先级

原总稿建议的优先级是 DD 中低层 → `A_2` deep-even 的 resultant/Hensel 接触 → `A_1` saturated 的 coefficient-plane invariant。具体命题、公式和开放缺口见本文件的拆分正文。

> 迁移说明：以下正文由原始总稿机械拆分，公式和证明状态不作数学改写。
# 32. 早期“完整证明”为什么不能作为最终证明

研究过程中曾经形成过一版形式上已经把三个分支全部“关闭”的预印本框架。严格审计后发现，其中承担全局不存在性作用的若干步骤没有真正建立。

这些问题已经明确撤回，不能继续作为证明依据。

## 32.1 “完全共享分母结构已关闭”曾被无证明引用

如果每个素数在三个分母中的最高赋值都至少出现两次，可以严格得到

\[
b_1=q_0c_2c_3,
\]

\[
b_2=q_0c_1c_3,
\]

\[
b_3=q_0c_1c_2,
\]

其中 \(c_1,c_2,c_3\) 两两互素。

这个分解本身正确。

错误在于曾经从这里直接跳到“完全共享分母分支已经排除”。  
分解定理只描述结构，并没有自动导出与 exact balance 的矛盾。

后续研究通过更细 denominator prime graph、局部高斯匹配和分支正规化替代了这个未经证明的“总关闭”。

---

## 32.2 有限证书不能替代无界下降

早期 \(A_2\) 证明中曾经存在这样的逻辑：

1. 用计算排除一个有限盒子；
2. 宣称更高位候选会“下降”回该盒子；
3. 因而全局排除。

问题在于第 2 步没有给出保持以下所有性质的严格映射：

- 正性；
- 既约性；
- exact balance；
- 整数球面；
- 十进制位数；
- 同一 carrier 分支。

后续真正证明的 Gaussian flip 又不保持原十进制 coefficient plane，因此无法补上这条缺口。

现在有限证书只被用于已经先有严格参数上界的有限切片。

---

## 32.3 DD 中“素数同时进入 gap 与二平方和所以矛盾”不成立

曾经尝试认为某个独占最高素幂同时进入

\[
H-y_3
\]

和

\[
y_1^2+y_2^2
\]

会与二平方定理冲突。

这是错误的。

二平方定理对

\[
p\equiv3\pmod4
\]

只要求它在二平方和中的总赋值为偶数，并不禁止它同时整除一个因子 \(H-y_3\)。

因此 DD 后来必须转向更精细的：

- unique-max denominator graph；
- \(e_1=e_2<e_3\)；
- exact \(p\)-adic capacity；
- near-square；
- resonance；
- near-\(S\)-unit。

---

## 32.4 \(A_1\) 中“两个 gap 尺度不相容”的文字论证不够

早期 \(A_1\) 终端论证曾使用：

- 远 gap；
- 第二个独立 gap；
- cyclotomic kernel；
- 尺度不相容；

但没有给出一个可以逐行核验的矛盾，例如

\[
v_p(X)\ge A
\quad\text{且}\quad
v_p(X)\le A-1,
\]

或

\[
0<T<M\le T.
\]

因此该“terminal incompatibility”没有成立。

后续真正可靠的结果是薄环、尾商斜率、统一 tail quadratic、saturated tail bound 与 denominator-only 奇素数锁。

---

# 33. 后来被严格判死或降级的证明路线

## 33.1 \(A_2\to A_1\) 的 Vieta jumping

关于第三坐标的二次方程确实有 companion root。

但在相邻 \(A_2\) 中可以证明 companion 第三坐标全局为负。

做符号反射后虽然得到更小的正坐标

\[
\widehat r_3<r_3,
\]

甚至有精确差值

\[
r_3-\widehat r_3
=
\frac{
20GP
}{
Q(\kappa+2G)
},
\]

但反射后的点不再满足原十进制 coefficient plane。

所以没有合法的

\[
\text{正根}\to\text{更小正根}
\]

Vieta jumping。

---

## 33.2 反复 Gaussian flip

对 \(L>1\)，flip 确实把球面因子中的 \(L\) 从一侧移到另一侧。

然而十进制平面系数会多出 \(L\)，因此一次 flip 后就离开原族。

对 saturated \(L=1\)，flip 又退化为 projective identity。

所以两个极端都无法形成传统无限下降。

---

## 33.3 Source-only Legendre/Jacobi 全局乘积

曾经尝试把所有 source prime 的二次剩余条件相乘，希望得到全局 \(-1\)。

严格整理后发现各项之间存在结构性抵消，最终只得到

\[
\boxed{
1=1.
}
\]

这说明 source-only quadratic character 没有利用到真正关键的十进制相位信息。

---

## 33.4 Generic \(u_0,c_u,\rho\) 二次剩余追逐

大量模素数条件在已知 Gaussian norm / source split 下自动满足。

继续逐个做 Legendre symbol 只会重复已有局部 norm 条件，不能控制十进制 coefficient plane。

因此该路线被降级。

---

## 33.5 “模数大于区间”只给唯一性，不给空性

如果一个变量 \(R\) 满足 CRT 且

\[
0<R<D,
\]

而模数 \(M>D\)，只能推出区间内至多有一个候选。

这只是

\[
\boxed{
\text{at most one},
}
\]

因此无法推出

\[
\boxed{
\text{zero}.
}
\]

真正还需要证明唯一代表不能满足 Gaussian divisor、窄实数窗口或平方条件。

---

## 33.6 普通 class group / genus / Hasse norm

外部系数本身已经满足大量全局 norm 条件。

单独使用 genus theory 或普通 Hasse norm obstruction 没有直接抓住十进制 coefficient plane。

class group 中某个小 ideal class 也可能被 source-side prime 补偿。

因此这些工具目前只可能作为辅助，不适合做主路线。

---

## 33.7 Scalar descent

曾经构造过一个线性变换 \(\mathcal M\)，但它满足

\[
\mathcal M^2=-\mathfrak d I.
\]

也就是说两步变换只回到原向量的标量倍数。

这种结构属于有限阶/projective 对称，无法形成无限下降。

---

## 33.8 错误的 odd-inert 推断

曾一度从

\[
E_1+\mathcal K
=
R_*(A_0^2+C_0^2)
\]

以及某个 \(p\equiv3\pmod4\) 在 \(E_1\) 中奇次出现，直接推断

\[
p\mid a_1.
\]

这是无效的，因为赋值可能出现类似

\[
3+1=4
\]

的普通加法抵消。

因此曾经由此得到的“某些 core 已全局关闭”“所有 odd inert prime 必来自固定 core”等说法已经撤回。

真正留下来的结构是 odd inert excess 三分法与 source 双 Hensel 接触。

---

# 34. 有限计算在完整证明中的正确角色

有限计算目前有三种用途。

### 34.1 验证严格有界切片

例如 \(A_2\) deep-even 中

\[
m_2\le10
\]

已经可以用纯整数模平方证书排除。

只要候选范围本身先由严格数学推导得到，这类计算可以成为证明的一部分。

### 34.2 诊断无界参数空间的实际稀疏程度

例如更高 \(m_2\) 层的 denominator recovery 过滤，可以告诉我们哪些理论约束最有杀伤力，从而决定下一步该证明哪个统一引理。

这类结果是研究导航，不应写成全局定理。

### 34.3 为最终有限余项提供证书

最理想的全局证明不一定需要纯手工排除所有小参数。

如果能够先证明

\[
S_{12}\le S_0
\]

或

\[
m_2\le M_0,
\]

那么剩余有限范围完全可以由可复核的整数程序关闭。

因此目标不应执着于“完全不用计算”，而应要求：

\[
\boxed{
\text{无限族必须先被理论上统一压成有限族。}
}
\]

---

# 35. “固定前缀有限”与“全局空”之间的逻辑门槛

这是整个项目中最重要的方法论教训之一。

在 \(A_2\) 中，固定前两块后第三块可以被平方判别和 recovery 压成有限集合。

在 DD 中，固定 ghost \((y_1,y_2)\) 后

\[
La\mid y_1^2+y_2^2
\]

使第三坐标只有有限候选。

在 \(A_1\) 中也存在相同的逐纤维有限化。

但如果前缀参数

\[
m_2,\ a_2,\ b_2
\]

或 ghost

\[
y_1,y_2
\]

仍然无界，那么

\[
\bigcup_{\text{所有前缀}}
\text{有限候选集}
\]

仍可能是无限集合。

因此以下推理是无效的：

\[
\forall P,\quad
\#F(P)<\infty
\quad\Longrightarrow\quad
\bigcup_PF(P)
\text{ 有限}.
\]

真正需要的是某种 **prefix-uniform** 结论：

\[
\boxed{
\text{统一高度上界、统一矛盾、或保持原问题族的严格下降。}
}
\]

目前主定理仍开放，正是因为这最后一层还没有完全建立。

---

# 36. 当前严格证明状态

截至本文整理时，可以可靠写成以下状态。

## 36.1 已严格完成

1. exact lift 的十进制正权平均重写；
2. carrier 原理；
3. 正常位数区域排除；
4. 三异常分支穷尽；
5. 整数球面提升；
6. primitive recovery；
7. denominator prime graph 的主要全局结构；
8. 第三块公共尾商正规化；
9. 统一整数尾权 \(\kappa\)；
10. 统一二次式和平方判别式；
11. primitive tail quadratic；
12. \(10^\ell\mid\kappa^2(\kappa+2G)\)；
13. 三分支线性 denominator-tail cone；
14. 完整高斯共轭匹配的局部结构；
15. 高斯 flip 不保持十进制 coefficient plane；
16. \(A_2\) 相邻边界区
    \[
    (s_2,s_3)=(-1,1);
    \]
17. \(A_2\) deep-even 终端通道；
18. \(a_1=3\) 全局排除；
19. \(A_2\) 的 source split、Hensel 商、五进同步与 factor allocation；
20. \(A_2\) 的 prefix defect、odd inert excess 与 source 双 Hensel 系统；
21. \(A_2\) 的有限切片
    \[
    m_2\le10
    \]
    排除；
22. DD 的公共商正规化；
23. DD 的 surplus simplex；
24. DD 的 near-square gap；
25. DD 的
    \[
    d_3\le5S_{12};
    \]
26. DD 顶部 \(2/5\)-adic 双 resonance；
27. DD near-\(S\)-unit 化；
28. DD 极端 denominator 不对称；
29. DD 最大 denominator-tail 层排除；
30. DD 拼接行列式 gap 的精确赋值恒等式；
31. DD 双 resonance 终端尖角
    \[
    10S_{12}+11\le n_3\le11S_{12}+3
    \]
    的全排除；
32. DD 的五进正规形先给出中间上界
    \[
    n_3
    <
    \left(5+3\log_5 10\right)S_{12}
    +\frac32\log_5 10;
    \]
33. DD 中高层的奇偶锁 \(10\mid b_3\)、唯一五进正规形与超深五进单位抵消；
34. DD 中高层的二进非 resonance 锁 \(\Delta_2>0\) 与三条二进正规形；
35. DD 二进主导项锁
    \[
    v_2(\kappa)=v_2(G)+1
    \]
    及整个单五进 resonance 中高层的排除；
36. DD 此前的全局相对界
    \[
    n_3\le8S_{12};
    \]
37. DD 阈值以下的上层
    \[
    n_3\ge(5+2\log_5 10)S_{12}+\log_5 10
    \]
    被压成唯一五进 resonance 正规形或 \(\Delta_5>0\)；
38. DD 五进入口以上的整个 \(\Delta_5>0\) 支已经排除；其中
    \[
    v_5(\kappa)=v_5(G)
    \]
    由 \(v_5(\kappa+2G)\) 的高度排除，而
    \(v_5(\kappa)>v_5(G)\) 由 primitive recovery 强制
    \(v_5(F_-)=v_5(\kappa)>n_3\) 后排除；
39. DD 上层 resonance 的加权赋值惩罚
    \[
    n_3
    <8S+6+\log_{10}2-\log_{10}\Xi,
    \qquad
    \Xi\ge2,
    \]
    以及最高整数层 \(\Xi\in\{2,16\}\) 的终端正规形；
40. DD 最高整数层
    \[
    n_3=8S_{12}+5
    \]
    已按三个二进位置全部排除；\(t_2=1\) 最终只需关闭
    \((S,m_3)=(4,17),(5,21)\) 两个严格推出的尺寸，均由
    \(\kappa>10QG\) 矛盾排除；
41. DD 入口以上、\(b_3\) 二进主导且 \(t_2\ge2\) 的无界
    resonance 子锥满足
    \[
    n_3\le8S_{12};
    \]
    当前最高剩余层 \(n_3=8S_{12}+4\) 因而只能落入 \(t_2=1\)，
    先压成十个 \((S,m_3)\) 尺寸及统一极端前缀位数形状，再由
    225 个赋值元组及其有界余因子区间的有限证书全部排除；
42. DD 的一般余因子区间证书不再依赖极端位数形状，并连续排除
    \[
    n_3=8S_{12}+3,\qquad n_3=8S_{12}+2;
    \]
    两层分别压成 32、59 个尺寸和 2677、14095 个赋值元组，所有
    余因子区间均无幸存者；
43. DD 的 \(n_3=8S_{12}+1\) 层已经全部排除：\(S\ge4\) 的
    86 个尺寸和 48808 个赋值元组只留下 \((S,m_3)=(5,16)\)
    的一个余因子，它固定 \((b_1,b_2)=(768,97)\) 后使
    near-square 判别式模 \(3\) 为非平方；\(S=2,3\) 则由严格
    分扇区归约压成 618、39710 个 denominator-tail 元组，最终
    2、8 个统一判别式均由有限证书验证为非平方；
44. DD 新边界 \(n_3=8S_{12}\) 的入口上部分已经分解：
    \(S\ge11,t_2=1\) 被压成 70 个尺寸和 51828 个赋值行，精确
    floor-sum 余因子证书没有幸存者；\(t_2\ge2\) 则严格强制
    \[
    m_3=3S,\quad d_3=5S,\quad
    \kappa=10^{2S}c,\quad1\le c\le8,
    \]
    并有极端前缀位数形状与 \(10^{S-3}\mid b_3\)。后者仍是八个
    无界族，不是八个有限候选；
45. 上述八个无界核也已由 \(F_-=10^{2S}\rho\)、\(0<\rho<20000\)
    和精确大除数
    \[
    \frac{c10^{2S}+2G}{\gcd(c10^{2S},G)}\mid\rho Q
    \]
    全部排除。八核固定赋值给出
    \(\gcd(c10^{2S},G)/c\le128\)，使整除式两侧的
    \(10^{2S}\) 与 \(10^S\) 增长率矛盾。因此
    \(n_3=8S\Rightarrow S\le10\)，并且 \(S\ge11\) 时
    \(n_3\le8S-1\)；
46. 在 \(4\le S\le10,n_3=8S\) 的 \(b_3\)-二进主导、
    \(t_2=1\)、唯一五进正规形子支中，56 个尺寸的 97693 个赋值行
    先压到 3121 个同步 \(F_-\) 行和 113 个余因子对；真实分母分解
    只剩 \((b_1,b_2)=(768,97)\) 的一个尾核，并由 near-square
    模 3 非平方排除；
47. 同一唯一五进正规形的 \(t_2\ge2\) 子支在 \(S\ge7\) 已由大除数
    无界矛盾排除；\(S=4,5,6\) 的 129600、1296000、12960000 个
    有序真实分母块也在局部预算、尾区间与大除数条件后没有幸存者。
    因此该五进正规形在 \(4\le S\le10\) 的 \(b_3\)-二进主导位置
    全空；其他入口下五进状态仍待证；
48. DD 的整个 \(n_3=8S\)、\(S\ge4\) 等号层已经排除：若
    \(5\mid b_3\)，位数下界自动恢复 \(e_5=q_5\)，resonance、
    \(\Delta_5<0\)、\(\Delta_5>0\) 三态分别由唯一正规形、高度与
    primitive recovery 排除；若 \(5\nmid b_3\)，尾权强制
    \(\kappa=2\cdot5^{3S}\)，最终三个二进剩余类均超过真实
    \(G\) 上界。因此
    \[
    n_3=8S\Longrightarrow S\in\{2,3\},
    \qquad
    S\ge4\Longrightarrow n_3\le8S-1;
    \]
49. DD 的剩余 \(S=2,3,n_3=8S\) 等号层也已关闭。non-dominant
    扇区分别强迫 \(m_3\ge14,21\)，但 primitive denominator-tail
    核在 \(m_3=10,17\) 后已经为空，因此无需枚举无界 prefix
    surplus。dominant 扇区的 1527、72092 个 tail rows 经二进位置、
    两素数三状态、既约性与 squarefree gap 后，分别只需检查 703、
    38633 个统一判别式；精确整数平方根证书验证全部非平方。因此
    \[
    n_3=8S_{12}\text{ 整层为空},
    \qquad
    n_3\le8S_{12}-1;
    \]
50. DD 的 denominator-tail 界已对全部 \(S\ge2\) 加强为
    \(m_3\le6S+2\)，从而 non-dominant 扇区统一满足
    \(n_3\le7S+2\)。新的最高允许层 \(n_3=8S-1\) 因而全部
    dominant；在 \(S\ge18\) 的五进 resonance 区，\(t_2\ge2\)
    被压成 19、9、0 个常数核并由大除数矛盾排除，\(t_2=1\) 则压成
    45 个尺寸、15525 个 valuation rows，并由 floor-sum 余因子证书
    全部排除。因此
    \[
    n_3=8S-1\Longrightarrow S\le17,
    \]
    该层已经成为真正有限的原问题切片，但其最终空性仍待核验；
51. DD 的 \(n_3=8S-1\) 层中 \(S=2,3\) 两个最小尺寸已经由有限
    证书排除：dominant 尾核分别有 2665、126669 行，全部有界前缀
    经二进位置、两素数三状态、既约性与 squarefree gap 后产生
    24396、1582338 个非负统一判别式，精确整数平方根检查全部非平方。
    因此在处理下一个尺寸以前，最高层先缩为
    \[
    n_3=8S-1,\qquad4\le S\le17;
    \]
52. 对任意 DD 候选，\(F_-\)、primitive recovery 与正拼接 gap
    还给出不依赖 resonance 的精确大除数
    \[
    \frac{\mathfrak L_F}{\gcd(\mathfrak L_F,Q)}\mid F_-,
    \qquad
    \mathfrak L_F=
    \frac{\kappa(\kappa+2G)}
    {\gcd(\kappa(\kappa+2G),\kappa+G)}.
    \]
    在最高层的 \(S=4\) 切片中，squarefree gap 先把最低尾长
    \(m_3=11,12,13,14\) 压成 1、3、7、13 个有序位数形状；四个完整
    有限证书最终检查 694825、10987773、714489、99342 个大整数
    判别式幸存者，全部非平方。
    余下 \(m_3=15,\ldots,21\) 由流式 C++ 精确枚举检查
    14150484、9828、8792、112243、70、1887、0 个 valuation-tail
    判别式，最终整数平方数都为零；\(m_3=22,\ldots,26\) 的 primitive
    denominator-tail 核逐层为空。因此
    \[
    S=4,\quad n_3=31\Longrightarrow\text{无 DD 候选},
    \]
    当前最高层只剩
    \[
    n_3=8S-1,\qquad5\le S\le17.
    \]
    这仍是明确有界的有限证书，不关闭更低无界层；
53. DD 最高层的 \(S=5,n_3=39\) 尺寸中，完整流式证书先排除
    \(m_3=22,\ldots,26\)：五层的 136692、23052、3742、401、35 个
    primitive tail rows 最终没有平方判别式；\(m_3=27,\ldots,32\)
    的 primitive denominator-tail 核逐层为空。第 27.30 节又证明
    \(m_3=14\) 的唯一位数形状在四角、valuation box、通用
    \(F_-\) 大除数与二/五进单位性盒后只剩 75 条 primitive tails；
    全部 7930779 个 squarefree-gap 前缀都不满足完整两素数三状态。
    第 27.31 节再以三个严格位数形状的完整流式证书排除 \(m_3=15\)：
    五类必要过滤后分别剩 1404、17、5499 条 primitive tails，所有
    多精度精确判别式仍无平方。第 27.32 节同样排除 \(m_3=16\) 的
    七个严格位数形状：141826212 个 valuation-tail pairs 最终没有
    精确平方判别式。因此这个尺寸只剩
    \[
    17\le m_3\le21,
    \qquad18\le d_3\le22.
    \]
    这仍是明确有界的有限证书，没有关闭整个 \(S=5\) 尺寸；
54. \(A_1\) saturated 支的 denominator-only 尾长界；
55. \(A_1\) saturated 非十进制奇素数只能来自 \(G\) 且为 \(1\bmod4\)。

---

## 36.2 尚未完成

\[
\boxed{
A_2\text{-only 尚未全局关闭}.
}
\]

\[
\boxed{
DD 尚未全局关闭.
}
\]

\[
\boxed{
A_1\text{-only 尚未全局关闭.
}
\]

因此

\[
\boxed{
\text{主不存在性定理尚未完成证明}.
}
\]

---

# 37. 三个分支的剩余核心

## 37.1 \(A_2\)

真正开放的是

\[
\boxed{
m_2\ge11
}
\]

下 deep-even 终端系统的统一空性。

局部素数追逐已经基本耗尽，继续方向应集中在：

\[
\boxed{
\text{source 双 Hensel}
+
\text{十进制窄窗口}
}
\]

以及

\[
\boxed{
\text{Gaussian ellipse}
+
\text{真实 }2/5\text{-adic phase}.
}
\]

最新 endpoint-lattice 推进在最危险 `(a,k)=(9,2)` reflection high-2
子族中严格得到：`eta=2m-M=-1,0` 均不可能，`eta=1` 只剩五个
`(d,c_Q,k_h,slot)` 类型。这里仍须保留两条状态边界：

- **`已严格完成`**：固定 `eta=1` 的连续槽相交分类先成为有限十五型，
  exact concatenation 相关界排除 `(107,1,-)` 与 `(163,1,+)`，随后
  `q_0` barrier 给出的 `r>4/5` 又排除两个 `K_+=153/40` 类型，
  Gaussian norm 的素数支持再排除所有含 `5`、`7`、`23`
  的类型；
- **`失效/降级`**：唯一的 `k_h=3` 类型虽强迫四个 sphere 坐标共享
  `3`，但 LCM sphere 不自动整体本原；同时除以 `3` 会改变第三块位数，
  不能构成保持 decimal plane 的下降；
- **`失效/降级`**：粗 slot 本身不能对所有 `eta` 给出空性，
  `(eta,d,c_Q,k_h,slot)=(1,2,31,1,+)` 的两个必要实区间严格相交。

因此下一步必须把这五型与 `c_Q\mid Q_0`、source split、平方单边
allocation 的自然代表或 `C` 的 CRT phase 联立。三个 `k_h=1` 类型
现已分别压到模 `515,795,775` 的有限平方根相位；`k_h=53` 类型则有
模 `53` 的两个 Gaussian 相位及 `53\nmid c_u`。这些仍不是 A2 关闭。

为避免把主线退化成逐层枚举，最新的 `eta`-uniform 推进进一步令

\[
X_h=\frac{k_hg}{2},
\qquad c_Q=c_-c_+,
\]

并对整个 reflection high-2 cone 严格得到

\[
\gcd(k_h,c_Q5^d)=1,
\qquad
5^dc_-\mid X_h-a_3,
\qquad
c_+\mid X_h+a_3.
\]

因此模 `c_Q5^d` 的平方根符号不是独立自由度，而由原
square-side allocation 唯一定向；特别地 `5^d` 恒取正根。定义相应
正奇数 `r_-,r_+` 后，还得到 exact linear/product system 以及

\[
gr_-\equiv\varepsilon a_2c_+
\pmod{5^{\lambda-d}},
\qquad
\lambda-d\ge\lambda/2.
\]

进一步与 source 双 Hensel 及
`v_5(N_0)=lambda-2d` 的两相位合并，已消去 `g,omega,theta`，得到

\[
r_-\equiv
\varepsilon\iota\,9\cdot2^{M+m}c_+c_u
\pmod{5^{\lambda-2d}},
\qquad
\iota^2\equiv-1.
\]

同一系统还严格给出新的近本原 Gaussian norm transfer

\[
r_-^2+
\left(9\cdot2^{M+m}c_+c_u\right)^2
=k_h5^{\lambda-2d}X,
\qquad
\gcd(r_-,9\cdot2^{M+m}c_+c_u)\mid9.
\]

把它与 prefix norm 同时除去同 orientation 的
`(2 plus or minus i)^{lambda-2d}` 后，两条 `5`-primitive Gaussian
向量的交叉行列式仍满足精确深度

\[
v_5\!\left(
\operatorname{Im}(\mathcal R_5\overline{\mathcal A_5})
\right)=d.
\]

此外还存在互补的近本原表示与精确 Gaussian composition：

\[
r_+^2+
\left(9\cdot2^{M+m}c_uc_-5^d\right)^2
=k_hY,
\]

\[
\mathcal R_5\overline{\mathcal A_5}
=X\left(
\varepsilon r_+-i\,9\cdot2^{M+m}c_uc_-5^d
\right).
\]

这把剩余核进一步变成同一 `k_h` 在两条互补近本原二平方表示中的
Gaussian prime orientation 兼容问题。

对精确 composition 使用 `Z[i]` 唯一分解后，进一步严格得到：令
`X_(3)=X/3^{v_3(X)}`，则存在

\[
N(\alpha_X)=X_{(3)},
\qquad
\alpha_X\mid\mathcal A_5,
\qquad
\alpha_X\mid\mathcal R_5.
\]

也就是说 `X` 的全部非 `3` 部分是真正可整体消去的共同 Gaussian
divisor。唯一例外的 `3`-primary defect 满足

\[
v_3(X)+v_3(Y)\le4,
\qquad
v_3(k_h)\le4.
\]

这尚未证明约分后的坐标回到原 decimal coefficient plane，但已经
排除“任意新奇素数形成无界 obstruction”的可能。

对唯一的奇 `3`-primary defect 还可作完整赋值分类。写
`e_3=v_3(k_h)`，则

\[
e_3\text{ 为奇数}
\Longrightarrow
\begin{cases}
v_3(a_3)=1,\ e_3=1,\ v_3(a_2)\ge2,\\
\text{or}\\
v_3(a_2)=1,\ v_3(a_3)\ge2,\ e_3\in\{1,3\}.
\end{cases}
\]

两通道都进一步强迫

\[
v_3(H)=v_3(\alpha)=1,
\qquad
v_3(\beta)=0.
\]

因此奇 `3` 缺陷已被压到两个明确通道，并必须与真实 denominator
concatenation 的模 `3` source/Hensel 表达兼容。

进一步地，`3` 的奇性也可以在 Gaussian UFD 内统一吸收。由三条 norm
恒等式，

\[
v_3(X)\equiv v_3(Y)\equiv v_3(k_h)\pmod2.
\]

令 `delta` 为这一公共奇偶性，则存在完整共同 Gaussian divisor

\[
N(\alpha_X^\sharp)=3^\delta X,
\qquad
\alpha_X^\sharp\mid\mathcal A_5,\mathcal R_5,
\]

约去后满足

\[
N(\mathcal B_5)=Y/3^\delta,
\qquad
N(\mathcal G_5)=k_h/3^\delta,
\]

\[
\varepsilon r_+-iR_1
=3^\delta\mathcal G_5\overline{\mathcal B_5}.
\]

所以当前已不存在独立的 Gaussian prime-allocation 障碍；真正缺口是
证明共同因子约分必然保持原 decimal coefficient plane，并把它升级
为严格降低高度且仍合法的 A2 descent；另一条可行路线是直接从
quotient 与原平面的强制关系推出矛盾。仅证明 quotient 不保持平面
不能排除原候选。

把完整共同 divisor 从 source Hensel 兼容式中消去后，进一步得到不含
`X`、不含固定 `eta` 分类的纯 Gaussian quotient kernel：

\[
\pi_\iota^d\bar\pi_\iota^{\lambda-d}
\mid
c_u\mathcal G_5
-\varepsilon c_+\omega\mathcal B_5,
\]

其中

\[
N(\mathcal B_5)=Y/3^\delta,
\qquad
N(\mathcal G_5)=k_h/3^\delta.
\]

Gaussian 模数的 norm 恰为 `5^lambda`，故相应线性式的 norm 必须被
`5^lambda` 整除；由精确 composition 的非零虚部，该线性式不可能为
零，所以其 norm 实际至少为 `5^lambda`。进一步审计表明该整除来自
同一个 Gaussian 商的精确分解；短 orientation 的赋值恰为 `d`，任何
额外增深只能留在长 orientation，而 `theta` 写法与 `omega` 核严格
线性相关，并不提供第二条独立 Hensel 条件。

原拼接平面还给出

\[
\omega\mid\alpha,
\qquad H_0=c_u(\alpha/\omega),
\]

并把 endpoint 小余量固定为

\[
5^\lambda C
=g(a_3+3\cdot10^m)
+\varepsilon a_2c_Q5^d
-\frac{g^2k_h}{2}.
\]

所以当前可审计的直接闭环目标已变成：证明这个唯一自然代表不能落在
`0<C<mathfrak L_0/1000`，或由精确 quotient 构造合法降高；不能再对
`omega/theta` 两种写法重复收费。

Archimedean 侧也不再只有一个无方向 norm bound。预约分商
`S_5=alpha_X^sharp W_5` 满足

\[
4<\tan\arg(-\varepsilon\mathcal S_5)<5,
\]

并且相对 prefix 向量 `Z_a=a_2+iC_0` 的侧别恰由 `epsilon` 决定。
约掉共同 `X` 后还有精确面积式

\[
\operatorname{Im}
\left(
\mathcal W_5\bar\pi_\iota^{\nu_5}
\overline{\mathcal B_5}
\right)
=-\frac{c_uR_1}{3^\delta5^d}.
\]

因此下一步所需的不是再做粗角度估计，而是证明这个固定窄楔与精确
面积不允许任何 canonical split-prime argument，或由其恢复合法下降。

同一精确商还能写成有理 Gaussian 格上的中心余数：

\[
5^{\lambda-d}\mathcal W_5
+\varepsilon c_+\omega
\pi_\iota^{\nu_5}\mathcal B_5
=c_u\pi_\iota^{\nu_5}\mathcal G_5.
\]

low-`m` 高度锥统一给出

\[
\frac{c_u^2k_h}{5^\lambda}<\frac1{25},
\qquad
\left|c_u\pi_\iota^{\nu_5}\mathcal G_5\right|
<\frac15 5^{\lambda-d}.
\]

故右端是相应同余类在半径 \(5^{\lambda-d}/2\) 圆盘内的唯一代表。
主缺口因而进一步缩成：排除这个唯一中心代表同时具有既定 norm、
有向面积与 `C` 自然代表；这仍只关闭到 reflection high-2 kernel，
不是 A2 全局空性。

中心代表与主向量之比还满足统一指数界

\[
\frac{
|c_u\pi_\iota^{\nu_5}\mathcal G_5|
}{
c_+\omega|\pi_\iota^{\nu_5}\mathcal B_5|
}
<\frac1{7680}.
\]

因此 quotient 的两个坐标都是唯一最近整数商；其方向不再只落在
`4<tan(phi_S)<5`，而是满足

\[
0<\varepsilon
\left(
\tan\phi_S-\frac{C_0}{a_2}
\right)
<\frac7{2000}.
\]

这把剩余对象压成贴着真实 decimal prefix slope 的确定单侧格点条带，
但“唯一最近商”仍不等于“不存在”；必须继续接入 `C` 自然代表或精确
面积才能得到矛盾。

进一步把 quotient slope 按 \(J_{\rm def}\) 展开后，两项 decimal
contribution 精确抵消，并得到

\[
\tan\phi_S-\frac{C_0}{a_2}
=
\frac{
\varepsilon C_0J_{\rm def}
}{
a_2(\mathcal K a_2-\mathcal U-\varepsilon J_{\rm def})
}.
\]

因此实际方向锁是

\[
0<\varepsilon
\left(
\tan\phi_S-\frac{C_0}{a_2}
\right)
<\frac1{a_2}.
\]

于是 `epsilon=+1` 时 \(C_0=\lfloor a_2\tan\phi_S\rfloor\)，
`epsilon=-1` 时 \(C_0=\lceil a_2\tan\phi_S\rceil\)。这说明提升后
quotient \(\mathcal S_5=\alpha_X^\sharp\mathcal W_5\) 的方向可唯一恢复
原 prefix 系数。它仍含共同 Gaussian factor；裸 quotient 的绝对
argument、完整尺度、\(a_2\) 与顶部补余量 \(C\) 尚未同步恢复。

同一精确式还把有向面积
\(\Delta_S=\varepsilon(a_2Y_S-C_0X_S)\) 锁入

\[
\frac35<\frac{\Delta_S}{X_S}<\frac45.
\]

因此 \(X_S=\Delta_S+E_S\) 的 Euclidean 商恰为 `1`，且
\(\Delta_S/4<E_S<2\Delta_S/3\)。这给出严格更小的正整数余量，但尚未
证明该余量保持 Gaussian norm 与 decimal plane，故还不是合法下降。

进一步审计表明，该实线性 split 的变换 determinant 为
\(-\varepsilon a_2\)，所以它确实不保持二平方 norm。改在裸
quotient pair 上做 Gaussian 除法，则首商被唯一固定为纯实整数

\[
Q_E=\operatorname{nint}
\left(\frac{c_+\omega}{5^{\lambda-d}}\right).
\]

对应非零余数
\(\mathcal R_E=-\varepsilon\mathcal W_5-Q_E\mathcal V_5\) 满足

\[
0<N(\mathcal R_E)<\frac14N(\mathcal V_5),
\qquad
v_{\pi_\iota}(\mathcal R_E)=0.
\]

这是严格的 canonical Gaussian norm descent；尚缺的是证明该余数继续
满足 decimal coefficient plane / Hensel 形状，才能迭代为 A2 下降。

乘回同一不对称模数后还有

\[
\mathfrak K_5\mathcal R_E
=r_E\mathcal B_5-\varepsilon c_u\mathcal G_5,
\]

其中 \(r_E\) 是中心区间内唯一的 scalar Hensel representative，
\(5\nmid r_E\)，并满足

\[
r_E\equiv c_-^{-1}\theta\pmod{5^{\lambda-d}}.
\]

取 norm 后得到一维正定二次核

\[
5^\lambda N(\mathcal R_E)
=
\frac{Yr_E^2-2c_ur_+r_E+c_u^2k_h}{3^\delta},
\]

其 discriminant 恰为 \(-4c_u^2R_1^2\)。因此下一直接目标是排除该
唯一中心代表达到剩余长 orientation，而不再处理二维 Gaussian
quotient-choice。

继续展开 Hensel slot 得到

\[
g\varrho=5^{\lambda+1}H-c_Qc_u.
\]

第一层 \(r_E\) 余类中的 \(H\) 项被模 \(5^{\lambda-d}\) 消去，但提升商

\[
z_E=\frac{gr_E-c_+c_u}{5^{\lambda-d}}
\]

满足

\[
-\frac g2<z_E<\frac g2,
\qquad
c_-z_E\equiv-5^{d+1}H\pmod g,
\]

并且是唯一中心奇代表。代入一维核后得到

\[
3^\delta g^2N(\mathcal R_E)
=5^{\nu_5}Yz_E^2
-2\varepsilon c_ua_2c_-z_E+c_u^2c_-^2X,
\]

其 discriminant 恰为 \(-4c_u^2c_-^2C_0^2\)。对应二平方表示的两个
坐标均被完整 \(g\) 整除；约分后精确等于
\[
3^\delta\bar\pi_\iota^{\nu_5}
\mathcal R_E\overline{\mathcal B_5}.
\]
所以 `H,a_2,C_0` 已进入同一个正规化 Gaussian 向量，但该向量仍未
证明对应合法 decimal child。

第二层代表还与顶部补余量满足

\[
c_uC+\varepsilon a_2c_-z_E\equiv0\pmod g,
\qquad
\chi_E=\frac{c_uC+\varepsilon a_2c_-z_E}{g}\in\mathbf Z,
\]

并给出 `(z_E,chi_E)` 的完全整数正定核。另一方面，完整
`g`-约分所得 canonical Gaussian child 的绝对斜率小于
`1/3999`（乘 unit 后则大于 `3999`），不可能回到
`(9/2,5)` 的 A2 prefix window；因此直接同型下降路线已严格降级，
不能把 Gaussian norm 下降本身当作 A2 空性。

独立的 rational-root 条件现已剥去全部十进制素因子：

\[
\Xi_C=
\frac{F(3)}{2^{2M+2}5^{\nu_5}C}
\in\mathbf Z_{>0},
\qquad
\gcd(\Xi_C,10)=1.
\]

它在完整 denominator 上满足

\[
\Xi_C\equiv q^2c_+^2Y(3T+a_3)^2\pmod D,
\]

所以 `Xi_C/Y` 在 `2^m5^d` 上是显式平方类。把同一
rational root 在相邻整数点平移，还得到

\[
D-C\mid F(2),
\qquad
D+C\mid F(4),
\qquad
\gcd(D-C,D+C)=1,
\]

以及正奇 `5`-进单位 cofactor `Xi_-,Xi_+`；三者模
`2^m5^d` 共享同一个 `Y`-平方类。这是严格的无界必要条件，
不是有限证书。当前最具体的直接缺口是从三个 odd-prime cofactor 的
resultant/reciprocity 与 `(z_E,chi_E)` 中心代表推出矛盾。

此外 mixed bridge 重新恢复旧 source coprimality，并严格新增符号锁

\[
\gcd(c_uH,g)=1,
\qquad
\operatorname{sgn}\chi_E=\operatorname{sgn}(\varepsilon z_E),
\qquad
\left|
\frac{g\chi_E}{\varepsilon a_2c_-z_E}-1
\right|<\frac3{50000}.
\]

其中 coprimality 与旧 source split 一致，不重复计作 obstruction；新
结论是该中心核的象限自由度消失。模 \(p^e\Vert g\) 时还有

\[
\min\{v_p(\Xi_C),e\}
=\min\{2v_p(3T+a_3),e\},
\]

所以零因子只剩 \(3T+a_3\) 的饱和通道；窄有理接触本身尚未形成矛盾。
在非饱和奇素数 \(p\mid g\) 上，继续消去
\(C,c_u,z_E,H,q\) 后有

\[
\left(\frac{\Xi_C}{p}\right)
=\left(\frac{-\varepsilon a_25^{M+d}}p\right).
\]

这把下一步精确化为：从 \(2^m5^d\) 的 \(Y\)-平方类或
\(\Xi_-,\Xi_+\) 的共同 cubic quotient 固定相反字符。
但把同一 congruence 提升到模 \(g^2\) 后，精确修正为

\[
\Xi_C\equiv
Y(qc_+(3T+a_3))^2(1-3DC^{-1})\pmod{g^2},
\]

而 \(1-3DC^{-1}\) 在 \(g^2\) 的每个 prime-power 分量上自动为平方。
所以普通 quadratic-character 提升路线已严格降级；下一输入必须是
非二次特征的加性 resultant、符号/高度或饱和层大小。

三点 secant cubic 已提供第一条这样的加性信息。定义

\[
\Delta_-=\frac{\Xi_C-\Xi_-}{2^m5^d},
\qquad
\Delta_+=\frac{\Xi_+-\Xi_C}{2^m5^d},
\]

则严格有

\[
1<\frac{\Delta_-}{\Delta_+}<2,
\qquad
v_2(\Delta_-)=v_2(\Delta_+)=1,
\]

\[
\Delta_--\Delta_+
=2^{m+1}5^dc_u^2
\{g((20P-9)T-a_3)-H_0\},
\]

\[
v_2(\Delta_--\Delta_+)=m+1,
\qquad
v_5(\Delta_--\Delta_+)=d.
\]

这已覆盖 pure-\(2\) fallback 的精确相邻-gap 结构，但尚未证明该加法
与 \(D-C,D+C\) 的奇除数不相容。
进一步取 \(F(2),F(3),F(4)\) 的中心二阶差分后，\(\Delta_+\) 已由两条
互素 congruence 唯一固定在模 \(D^2-C^2\) 的显式 CRT 类中；
\(\Delta_-=\Delta_++\Gamma_\Delta\)。当前剩余自由度因此缩成 CRT 商
\[
Q_\Delta=\left\lfloor\frac{\Delta_+}{D^2-C^2}\right\rfloor,
\]
但尚无它的全局上界。

同时，中心二阶差分先除去 \(2^{m+1}5^d\) 得到
\(\widetilde{\mathcal T}_2\)，但显式式进一步给出精确赋值
\(v_5(\widetilde{\mathcal T}_2)=d\)。真正的 \(2,5\)-本原正整数为
\[
\widehat{\mathcal T}_2
=\frac{\mathcal T_2}{2^{m+1}5^{2d}},
\]
严格满足

\[
\widehat{\mathcal T}_2
\equiv-5^{\lambda-d}(c_uC)^2\pmod g,
\qquad
\widehat{\mathcal T}_2\equiv3\pmod4,
\qquad
\gcd(\widehat{\mathcal T}_2,10c_ug)=1.
\]

所以它必供应一个不整除 \(g\) 的 \(3\bmod4\) 惰性素数到奇次。但完整
代入 canonical square 后得到
\[
5^d\widehat{\mathcal T}_2
=5^{\epsilon_5}Z_\nu^2+\mathscr J_\Delta,
\qquad \mathscr J_\Delta\equiv2\pmod4,
\]
这恰好恢复旧 odd inert excess，而非第二个独立 obstruction。后续必须
排除其 denominator-prefix、source、spontaneous 三类来源。
进一步化简显示
\[
\widehat{\mathcal T}_2
=2^mc_u^2g^2\mathscr S_0
-(c_Qq)^2 5^{2\lambda-d}XY,
\]
所以当前只有“尺度项减 norm”，没有把差变成 norm 所需的内积/正交
恒等式；该漂亮路线已审计到一个明确而真实的 orientation 缺口。
新的接触律
\[
\gcd(\widehat{\mathcal T}_2,Q_0XY)
=\gcd(\mathscr S_0,Q_0XY),
\qquad
\gcd(\widehat{\mathcal T}_2,f)
=\gcd(\mathscr R_f,f)
\]
已把 \(qf\) denominator excess 压成两个显式 gcd 问题；非 \(3\)
inert prime 不能来自 \(XY,c_u,g\)。固定素数 \(3\) 的一阶出现条件
也已由 (16.310) 精确分类，但允许 residue 中的赋值奇偶仍待控制。
对非 \(3\) denominator prime，\(\mathscr S_0\) 的
\(K\)-判别式进一步识别为判别数 \(-23\) 的二元型：
\[
\operatorname{disc}_K(\mathscr S_0)=8\mathscr R_{23}.
\]
\(q\)-channel 因而满足 (16.316)/(16.318) 的 \(23\)-分裂约束，
\(f\)-channel 满足独立的 (16.320) curvature character。它们仍只是
必要条件；(16.323) 的完整平方配方进一步证明这些局部 character
都是同一 principal-square identity 的投影，尚未取得与 source
allocation 相反的独立 character。
companion 还满足
\[
\mathscr C_{23}
=U_{23}^2+23V_{23}^2+5^{3\lambda}Q_0^2XY,
\quad
\mathscr C_{23}\equiv U_{23}^2\pmod{5^{2m}},
\quad
\mathscr C_{23}\equiv1\pmod8.
\]
因此纯 \(2,5\)-进局部非平方路线同样已降级。
进一步与 canonical \(Z\) 联立产生两个严格正 shifted factors
\[
\mathscr V_-=5^\lambda fc_-^2X-\mathscr E_{23},
\qquad
\mathscr V_+=5^\lambda qc_+^2Y-\mathscr E_{23}.
\]
它们的 \(q,f\) 同侧接触由
\(\mathscr L_{23}=9T/2+a_3\) 控制，共同因子由
\(\gcd(TK-9T-2a_3,Z)\) 控制。消去 \(Z\) 后证明 \(qf\) 的所有
未饱和接触赋值为偶数，所以 denominator odd excess 只剩
\[
p^e\Vert qf,\qquad p^e\mid\mathscr L_{23}
\]
的完整 prime-power saturation。
同时 \(q\equiv3,f\equiv1\pmod4\) 把 orientation 分成固定 \(3\)
balanced transfer 与 denominator \(q\) carrier；在前一支中
\(\mathscr V_\pm\) 恰共享一份 \(3\)，且
\(3\nmid\widehat{\mathcal T}_2\)。
剩余 saturation 已进一步接回真实缺口 \(H\)：
\[
\mathscr G_q=5^{M-1}(a_3-90T)+a_3H,\qquad
\mathscr G_f=\mathscr G_q-18\cdot2^{m+1}c5^d,
\]
候选必须满足完整 \(p^e\Vert q\) 整除 \(\mathscr G_q\)，或完整
\(p^e\Vert f\) 整除 \(\mathscr G_f\)。两 target 位于约
\(-89\cdot5^{M-1}T\) 的同一窄 significand band；尚缺无界
prime-power gcd/resultant 排除。
generic \(q\)-saturation 还由 rational-root 四次式放大为
\[
p^e\mid(6D+C),\quad
p^{2e}\mid\bigl(D(3T+2a_3)-TC\bigr),
\]
或 \(p^e\mid((K-3)D+C)\)。按
\(n_p=v_p(c_Qq)=v_p(c_Q)+e\) 精确计价后，middle branch 的
正规商恰有深度 \(e+2v_p(c_Q)\)，third branch 吸收完整 \(n_p\)。
对真正接触 \(\mathscr S_0\) 的 \(q\)-carrier，又有
\[
\mathscr S_0=T(K^2-26)-(2K-9)(2a_3+9T),
\qquad K^2\equiv26\pmod p.
\]
故第一 valuation branch 完全排除，无界 exceptional set 缩成固定
素数 \(11,23\)。尚未排除这两个固定素数的无限 Hensel lift，也尚未
从 middle/third residual unit character 得到最终矛盾。
在 \(p\nmid c_Q\) 的 generic 层，\(f\)-侧 saturation 则满足互补的非零局部型
\[
K^2-26\equiv
\left(\frac{2c_Q}{2^m5^\lambda g}\right)^2N_0\not\equiv0\pmod p,
\]
\(p\mid c_Q\) 时它退化回 \(K^2\equiv26\)，恰为已隔离的 overlap；
而 \(q\)-侧根另有
\(J_{101}^2\equiv101N_0-26\pmod p\) 的 prefix Gaussian bridge。
这些是新的严格必要条件，仍未合成为空性证明。
canonical factor allocation 又强迫每个 \(q\)-carrier 满足
\(N\equiv DK\pmod p\)，从而 generic middle branch 完全删除。
对 \(p\ne11,23\)，唯一剩余 rational-root branch 精确满足
\(v_p(KD-N)=v_p(c_Qq)\)；\(11\) 与 \(23\) 分别只剩一条固定的
双因子预算和右侧增深预算。
整数层进一步有
\[
q\mid DK-N,\qquad
2c_u(DK-N)/q=c_+^2Y+5^\lambda c_-^2X.
\]
在 saturation 内，\(q/f\) 两侧的截断赋值已分别降为纯 prefix
resultants \(K^2-26\) 与
\(\Psi_f=b_2^2(K^2-26)-Q^2N_0>0\)。此外
\((DK-N)/q\) 的每个非 \(3\) inert prime 都以相同深度整除
\(H_0\)，并满足 \((N_0/r)=-1\)。这三个明确通道尚未全部排除。
同时 \(Q_\Delta\ge5K\)，故 CRT 商不是可由固定有限层排除的小参数。

当前数学核心已经转为证明这个覆盖所有 `eta` 的定向因子系统与
source 双 Hensel / prefix defect 不相容，或从中构造保持十进制
coefficient plane 的下降；尚未得到该最终矛盾。

---

## 37.2 DD

原先的双 resonance 顶部

\[
10S_{12}+11
\le n_3\le
11S_{12}+3
\]

已经排除；其下方原本可能只发生五进 resonance 的整个中高层

\[
d_3=\max(s_1,s_2,d_3),
\qquad
n_3\ge9S_{12}+2
\]

也已由二进主导项与球面差分排除。继续把五进入口以上的
primitive recovery 代回 \(F_-\) 后，整个 \(\Delta_5>0\) 支也被排除；再保留 resonance 正规形中的完整前缀赋值并恢复 \(F_-\) 上界的精确常数后，先得到中间上界

\[
\boxed{
n_3\le8S_{12}.
}
\]

但 DD 仍未全局关闭：\(d_3\) 非 dominant 扇区与五进 resonance 阈值下的 dominant 扇区仍可随 \(S_{12}\) 无界增长。后一区域的上层

\[
n_3\ge
(5+2\log_5 10)S_{12}
+\log_5 10
\]

已进一步只剩唯一五进 resonance 正规形；\(\Delta_5<0\) 与
\(\Delta_5>0\) 均已排除。

入口以上唯一可随 \(S\) 无界的二进主导 \(t_2\ge2\) 子锥还满足加权界

\[
n_3
<8S+6+\log_{10}2-\log_{10}\Xi,
\qquad
\Xi\ge2.
\]

此前可能达到的整数层 \(n_3=8S+5\) 已进一步按三个二进位置全部排除；其中 \(t_2=1\) 只退化到

\[
(S,m_3)=(4,17),(5,21),
\]

并由两处 resonance 的整数高度预算直接排除。

进一步保留加权 \(m_3\) 界中的 \(\Xi\) 后，入口以上的
\(t_2\ge2\) 子锥实际上整体满足

\[
n_3\le8S.
\]

因此新最高层 \(n_3=8S+4\) 只能来自 \(t_2=1\)。未粗化的
small-factor 比例把该层压成统一的极端位数形状，并只留下

\[
\begin{aligned}
(S,m_3)\in\{&
(3,13),(4,16),(5,19),(5,20),\\
&(6,23),(6,24),(7,27),(7,28),(8,31),(9,36)
\}.
\end{aligned}
\]

对这些尺寸继续保留
\(v_2(\kappa)=v_2(G)+1\)、\(v_5(\kappa)=k_5\) 的精确余因子后，
combined-height 只留下 225 个赋值元组；每个元组要求一个显式短区间
包含指定奇数倍的 \(2^h\)，而有限整数证书验证所有区间均为空。因此
\[
n_3=8S_{12}+4
\]
已经严格排除。该有限证书只关闭这个先经符号推导有界化的层，不覆盖
更低的无界区域。

把同一余因子方法改用一般界 \(G<10^S\) 后，不再需要极端位数形状。
层 \(n_3=8S+3\) 与 \(n_3=8S+2\) 分别被压成 32、59 个尺寸及
2677、14095 个赋值元组；对应的一般余因子区间证书仍无幸存者。因此

\[
n_3=8S_{12}+3,\qquad n_3=8S_{12}+2
\]

也已严格排除；在这一阶段界为 \(n_3\le8S_{12}+1\)。这些有限证书只覆盖
已经由符号不等式给出 \(S\) 上界的两个明确层。

对新最高层 \(n_3=8S_{12}+1\)，\(S\ge4\) 的入口以上部分也已
排除：一般余因子证书在 86 个尺寸、48808 个赋值元组中只留下
\((S,m_3)=(5,16)\)；它进一步固定
\((b_1,b_2)=(768,97)\)、\((s_1,s_2)=(-2,4)\)，并使 near-square
判别式满足 \(Y^2\equiv2\pmod3\)，矛盾。对入口另一侧的 \(S=2,3\)，
非 \(d_3\)-dominant 扇区先由改进界 \(n_3\le7S+3\) 压到唯一
\(S=2,m_3=15\) 取等锥，并被统一尾整除直接排除。dominant 部分的
denominator-tail 核分别有 618、39710 个元组；二进位置与强制
resonance、五进三分支和全部有界前缀把它们压到 114、27 个
tail-prefix 组合，squarefree gap 最终只剩 2、8 个统一判别式。
有限证书以精确整数平方根验证十个判别式均非平方。因此整个
\(n_3=8S_{12}+1\) 层已排除，并在这一阶段给出全局相对界
\[
\boxed{n_3\le8S_{12}.}
\]

这一有限证书只覆盖两个已由 \(S=2,3\) 固定的入口边界，不覆盖
\(n_3\le8S\) 的无界区域。

在新的等号层 \(n_3=8S\) 上，第 27.17 节已经进一步处理入口上的
\(S\ge11\) 部分。非 \(b_3\) 二进主导位置被严格排除；\(t_2=1\)
被压成 70 个尺寸和 51828 个赋值行，并由精确模计数证明余因子幸存数
为零。\(t_2\ge2\) 则被严格压成

\[
m_3=3S,\qquad d_3=5S,
\]

统一极端前缀位数形状，以及

\[
\kappa=10^{2S}c,
\qquad c\in\{1,2,3,4,5,6,7,8\},
\qquad 10^{S-3}\mid b_3.
\]

第 27.18 节又恢复

\[
F_-=10^{2S}\rho,
\qquad0<\rho<20000,
\]

并从 \(F_-\)、primitive recovery 与拼接 gap 的两个
\(\mu/\nu\) 表达式导出

\[
\frac{c10^{2S}+2G}{\gcd(c10^{2S},G)}\mid\rho Q.
\]

八核的固定 \(2,5\)-赋值给出
\(\gcd(c10^{2S},G)/c\le128\)，所以该整除要求
\(10^S<2560000\)，与 \(S\ge11\) 矛盾。故八个无界核已经全部
关闭，并有

\[
n_3=8S\Longrightarrow S\le10,
\qquad
S\ge11\Longrightarrow n_3\le8S-1.
\]

在这一中间阶段，全局统一界仍是 \(n_3\le8S\)：这里只把等号层压到
有限 \(S\)-列表，并未自动得到完整有限候选盒；而 \(n_3<8S\) 仍可
随 \(S\) 无界增长。

在该小切片中，第 27.19–27.20 节又关闭了
\(4\le S\le10\) 的 \(b_3\)-二进主导、唯一五进正规形：
\(t_2=1\) 由 56 个尺寸、97693 个赋值行、113 个余因子对与唯一
模 3 尾核的有限证书排除；\(t_2\ge2\) 在 \(S\ge7\) 由无界
大除数矛盾排除，在 \(S=4,5,6\) 由真实分母块有限证书排除。

第 27.21 节随后关闭了这些剩余状态。对 \(S\ge4\)，dominant 位数
下界在 \(5\mid b_3\) 时自动恢复 \(e_5=q_5\)，从而五进
resonance、\(\Delta_5<0\) 与 \(\Delta_5>0\) 分别由唯一正规形、
单因子高度和 primitive recovery 排除。\(5\nmid b_3\) 时，尾权只
可能为 \(2\cdot5^{3S}\)；\(S\ge7\) 直接违反尾高度，\(S=4,5,6\)
则要求一个超过真实 \(G\) 上界的二进剩余类。因此

\[
n_3=8S\Longrightarrow S\in\{2,3\},
\qquad
S\ge4\Longrightarrow n_3\le8S-1.
\]

第 27.22 节没有把这两个固定 \(S\) 直接当成完整有限盒。它先证明
non-dominant 扇区强迫 \(m_3\ge14,21\)，再用 denominator-tail
整除核在 \(m_3=10,17\) 后为空来排除，完全不截断无界 prefix
surplus。dominant 扇区才由 \(s_1+s_2\le2\) 有限化；1527、72092 个
tail rows 最终产生 703、38633 个非负统一判别式，精确整数平方根
检查全部非平方。因此当前严格相对界是

\[
\boxed{n_3\le8S_{12}-1.}
\]

第 27.23 节又把 denominator-tail 界统一加强为 \(m_3\le6S+2\)，
故 non-dominant 扇区现在满足 \(n_3\le7S+2\)。在最高允许层
\(n_3=8S-1\)，\(S=2,3\) 的 non-dominant 尾核也直接为空，所以
整层全部 dominant。五进入口以上的 \(S\ge18\) 只剩 resonance；
其中 \(t_2\ge2\) 的 28 个常数核被统一大除数排除，\(t_2=1\) 的
45 个尺寸、15525 个 valuation rows 则由精确 floor-sum 余因子证书
排除。于是

\[
\boxed{
n_3=8S-1\Longrightarrow
d_3=\max(s_1,s_2,d_3),\quad S\le17.
}
\]

第 27.24 节又对其中 \(S=2,3\) 作了完整有限核验。2665、126669 个
dominant tail rows 最终只需检查 24396、1582338 个非负统一判别式，
精确整数平方根证书全部非平方。因此当前最高层只剩

\[
\boxed{n_3=8S-1\Longrightarrow4\le S\le17.}
\]

第 27.25–27.28 节建立了一个不要求 resonance 或五进入口的通用
\(F_-\) 大除数，并逐尾长关闭下一个尺寸。对 \(S=4,n_3=31\)，
最低四个尾长 \(m_3=11,12,13,14\) 的 squarefree gap 分别只允许
1、3、7、13 个有序位数形状；二进位置、两素数三状态、精确二次区间
枚举与统一判别式证书最终没有平方。余下 \(m_3=15,\ldots,21\)
由固定全量计数的 C++ 流式精确证书排除；\(m_3=22,\ldots,26\)
的 primitive denominator-tail 核为空。因此当前严格结论已加强为

\[
\boxed{
S=4,\quad n_3=31
\Longrightarrow
\text{无 DD 候选},
\qquad
n_3=8S-1\Longrightarrow5\le S\le17.
}
\]

这仍不是 DD 空性，因为最高层的 \(5\le S\le17\) 与更低层都尚未
关闭，后者还可随 \(S\) 无界增长。

第 27.29–27.32 节又处理下一个尺寸的高尾与最低三个尾层。在
\(S=5,n_3=39\) 中，
\(m_3=22,\ldots,26\) 的完整 128 位流式前缀证书没有平方判别式，
\(m_3=27,\ldots,32\) 的 primitive tail 核为空；\(m_3=14\) 的唯一
位数形状则由 75 条 primitive-tail 小核与完整两素数状态证书排除；
\(m_3=15,16\) 的三个与七个严格位数形状也由完整多精度判别式证书排除。
故该尺寸当前只剩

\[
\boxed{17\le m_3\le21,\qquad18\le d_3\le22.}
\]

这同样没有改变 DD 更低层的无界性。当前在最高层应先继续关闭
\(S=5\) 的其余五个尾长，再推进 \(6\le S\le17\)，并同时在更低层
寻找可送入

\[
(\mathcal R-r_3)(\mathcal R+r_3)
=
\frac{\mathcal N_{12}}{G^2}
\]

的唯一主导项；目标仍是绝对高度界或直接矛盾。

---

## 37.3 \(A_1\)

有效尾长已经受

\[
\ell\le3(m_1+m_2)+1
\]

控制。

真正最危险的是 saturated \(L=1\) 中可能继续无界的 decimal shift

\[
\boxed{
g.
}
\]

Gaussian descent 在这里完全失效。

需要寻找一个新的 coefficient-plane invariant 或直接的 decimal-shift 高度界。

---

# 38. 推荐的全局攻关顺序

## 第一优先级：关闭五进 resonance 阈值以下的 DD

第 27 节已经关闭双 resonance 顶部及其下方整个单五进 resonance 带，
并把当前最高层 \(n_3=8S-1\) 压成 \(5\le S\le17\) 的 dominant
有限盒。
下一步需同时面对这个有限盒，以及

\[
n_3\le8S_{12}-1
\]

内更低的两个无界区域：non-dominant 扇区
\(n_3\le7S+2\)，以及尚未达到五进 resonance 强制阈值的 dominant
扇区；后一区域仍可能自发发生 resonance。

建议把全部力量放在

\[
\mathcal N_{12}
=
X_0^2+\varepsilon^2
\]

的 near-square 结构与

\[
\kappa(
\kappa K_{C,D}
-
2GQ^2\mathcal N_{12}
)
=
W^2
\]

之间。

具体应尝试：

1. 从最高层的 \(5\le S\le17\) 继续使用精确二次区间、两素数状态、
   通用 \(F_-\) 大除数与统一判别式，避免直接枚举不可行的十进制
   全盒；
2. 对五进入口以下的 resonance、\(\Delta_5>0\) 与 \(\Delta_5<0\) 分别做 \(\kappa\) 相对 \(G\) 的超距分类；入口以上只保留 resonance；
3. 把每一类中 \(\mathcal R-r_3\) 与 \(2r_3\) 的赋值差写成显式线性式，寻找像第 27.5 节那样唯一主导的球面因子；
4. 对 \(n_3\le8S-2\) 中仍可无界增长的真实块继续保留
   \(Q,G,\mathcal N_{12}\) 与 short
   numerator block，给出
   \[
   |\varepsilon|/X_0
   \]
   的指数级上界；
5. 把判别核围绕 \(\mathcal N_{12}=X_0^2\) 展开，并寻找最近的候选整数平方中心 \(W_0^2\)；
6. 证明真实值与 \(W_0^2\) 的非零偏差小于相邻平方间距；
7. 如果最终只得到
   \[
   S_{12}\le S_0,
   \]
   则用有限证书关闭剩余层。

near-square 路线仍可用来给 \(E\) 或 \(F_-\) 提供绝对值上界，但不应再以已排除的 resonance 带为目标。新的主线是用

\[
\frac{\mu}{\nu}
=
\frac{E\kappa^2}{10^{m_3}Q^2(\kappa+G)}
\]

控制非 resonance 时 \(F_-\) 与 \(F_+\) 的赋值差，并每次与

\[
\kappa^3(\kappa+2G)<10^{8S_{12}+4}
\]

的统一高度上界重新比较。

---

## 第二优先级：\(A_2\) 的 resultant / Hensel 接触

对

\[
\Phi(x,z)
=
(99x-4)z-2x-4
\]

和

\[
\Psi_{a_1}(y,z)
=
400a_1(z+1)^2
-y(99z-2)^2
\]

计算

\[
\operatorname{Res}_z(\Phi,\Psi_{a_1}).
\]

由于 \(\Phi\) 对 \(z\) 线性，可以直接代入

\[
z=\frac{2x+4}{99x-4}
\]

得到显式的

\[
\Theta_{a_1}(x,y).
\]

合法 source odd excess 要求某个 inert prime 同时满足

\[
p^{2h}\mid\Phi,
\qquad
p^h\mid\Psi_{a_1}.
\]

预期可转化为

\[
p^h
\mid
\Theta_{a_1}(x,y).
\]

下一步应研究：

- \(\Theta_{a_1}\) 的因子分解；
- repeated-root/discriminant；
- 与固定 core \(a_1\) 的 gcd；
- 是否只有有限小素数允许高阶 Hensel 接触；
- \(p^{2h}\) 与十进制区间长度之间的 rational reconstruction 矛盾。

如果能证明所有高阶接触都来自固定有限素数集，\(A_2\) 就可能进一步压成有限状态。

---

## 第三优先级：\(A_1\) saturated 的 coefficient-plane invariant

这里不应继续尝试 Gaussian flip。

更合理的方向是找一个直接依赖

\[
10^g
\]

与前两块系数的整数对象，例如：

- determinant；
- cross-ratio 型有理不变量；
- 二次型 discriminant；
- 两个线性平面之间的格指数；
- 对 \(2,5\)-进高度同时敏感的 resultant。

目标是证明当 \(g\) 变大时，该对象一方面必须被 \(10^g\) 深度整除，另一方面绝对值增长速度又小于 \(10^g\)，从而出现

\[
0<|X|<10^g
\quad\text{且}\quad
10^g\mid X
\]

的直接矛盾。

这会比在 saturated 支中继续寻找“下降”自然得多。

---

# 39. 最终主定理需要的最小新成果集合

目前不需要重新发明前面所有局部代数。

一个完整证明最少需要以下三类新结果。

### Lemma DD — 中低层的统一高度界

双 resonance 顶部已排除。剩余需证明的是：对单 resonance 和非 resonance 区域建立

\[
S_{12}\le S_0,
\]

或者直接得到与 gap-valuation 恒等式不相容的赋值/高度矛盾。

### Lemma A2 — deep-even uniform obstruction

证明

\[
m_2\ge11
\]

时 source Hensel / Gaussian ellipse / decimal window 无法兼容，或者得到统一 \(m_2\) 上界。

### Lemma A1 — saturated decimal-shift bound

证明 saturated \(L=1\) 中

\[
g\le g_0(m_1,m_2)
\]

并最终与现有 tail bound 合并成全局有限性，或者直接产生矛盾。

若三条都得到统一有限上界，最后的有限区域可以由严格整数证书完全关闭。

---

<!-- end-history-status -->

<a id="history-dependency"></a>

> 整合来源：`dependency-map.md`（2026-10-01 归并前正文；不是当前状态）。

## 2026-09-06 A1 joint-surplus 接续

[top-layer.md](branches/a1-only/top-layer.md) 的 residue kernel、half-gap shell
与原始 contact/sphere 恒等式，推出
[joint-surplus 正余量恒等式](branches/a1-only/top-layer-r1-joint-halfgap-collapse.md#joint-surplus-stable-region)：
\[
0<\mathcal K-T\delta-\tfrac12 10^{N-4g}\psi^2<2\cdot10^{N-2k},
\qquad \mathcal K\in\mathbf Z,
\quad N=\max(r+g+1,s).
\]
再由 `k+s>=2g+2,k+r>=g+1,N<=4g,N<=2k-1` 得 `0<K<4/5`，排除整片
无界稳定区。这条依赖链绕过 minimal-diagonal 有限证书与旧 `r=1`
漏条件版本；区域之外及其他分支仍为待证。

## 2026-08-13 DD 接续依赖

下列网络覆盖本文件后文的 DD 旧基线；完整公式与证明边界见
[DD 主干 §27.33](branches/double-deficit/core.md#2733-2026-08-13-后续合并进展)。

\[
\text{reduced tail }(\kappa,G)=\gamma(u,v)
+F_-Q(\kappa+G)=E\kappa(\kappa+2G)
\Longrightarrow
u(u+2v)\mid F_-Q
\]

\[
\Downarrow\qquad
n_3<\frac{31}{4}S_{12}+\frac{6581}{960},
\qquad
n_3=8S_{12}-1\text{ 为空}
\]

\[
10^{m_3}\mid\kappa^2(\kappa+2G)
+\frac{Q^2}{11}<\kappa<10Q^2
+\text{fixed-target Schmidt Subspace Theorem}
\Longrightarrow
\limsup\frac{m_3}{S_{12}}\le5
\]

\[
\text{unique }2/5\text{-resonant S-unit funnel}
+\text{tail slope collapse}
\Longrightarrow
\limsup_{DD}\frac{n_3}{S_{12}}
\le6.308883577618\ldots
\]

\[
\text{frontier rigidity}
+\text{primitive determinant ladder}
+\text{carrier tetrahedron/projective circle}
+R_2\text{ residue transfer}
\Longrightarrow
\boxed{\text{唯一剩余 moving core }(C_L,\Pi)}
\]

最后一个方框是剩余对象而非矛盾；它不能推出 DD 已关闭。

> 迁移说明：以下正文由原始总稿机械拆分，公式和证明状态不作数学改写。
# 42. 关键公式依赖图

可以把当前全部证明压缩成下面的逻辑网络：

\[
\boxed{
\text{exact lift}
}
\]

\[
\Downarrow
\]

\[
\boxed{
\text{positive weighted average}
}
\]

\[
\Downarrow
\]

\[
\boxed{
A_2\ \cup\ DD\ \cup\ A_1
}
\]

同时

\[
\boxed{
\text{exact lift}
}
\]

\[
\Downarrow
\]

\[
\boxed{
y_1^2+y_2^2+y_3^2=H^2,
\quad
q\alpha=H\beta
}
\]

\[
\Downarrow
\]

\[
\boxed{
\gcd(q,y_i)=q/b_i
}
\]

\[
\Downarrow
\]

\[
\boxed{
\text{denominator prime graph}
}
\]

三个分支分别做第三尾正规化：

\[
\boxed{
(\delta_3,L,\tau)
}
\]

\[
\Downarrow
\]

\[
\boxed{
QG<\kappa\le10QG
}
\]

\[
\Downarrow
\]

\[
\boxed{
\kappa(
\kappa K_{C,D}
-2GD^2\mathcal N_{12}
)
=W^2
}
\]

以及

\[
\boxed{
10^\ell\mid\kappa^2(\kappa+2G)
}
\]

\[
\Downarrow
\]

\[
\boxed{
\ell\le6S_{12}+3
}
\]

随后：

\[
A_2
\Longrightarrow
\boxed{
\text{deep-even}
+
\text{source split}
+
\text{odd inert excess}
+
\text{double Hensel}
}
\]

并且在最危险 endpoint core 中：

\[
\text{endpoint shell}
+
\rho^2\text{ high-2 slot}
\Longrightarrow
\boxed{
\eta=-1,0\text{ 排除},
\quad
\eta=1\text{ 压成五型}
}
\]

但

\[
\boxed{
\text{粗 slot 有真实区间交点}
}
\Longrightarrow
\boxed{
\text{后续必须加入 prefix/source/CRT 条件}
}
\]

\[
\eta=1\text{ 五型}
+
\text{exact high/low factor}
\Longrightarrow
\boxed{
\text{模 }515,795,775,53\text{ 的有限相位}
}
\]

但真正覆盖无界层的接口是

\[
\text{任意 }\eta\text{ 的 reflection high-2}
+
c_Q=c_-c_+\text{ square-side allocation}
\Longrightarrow
\boxed{
5^dc_-\mid \frac{k_hg}{2}-a_3,
\quad
c_+\mid \frac{k_hg}{2}+a_3
}
\]

并进一步推出

\[
\boxed{
gr_-\equiv\varepsilon a_2c_+
\pmod{5^{\lambda-d}},
\qquad
\lambda-d\ge\lambda/2
}
\]

再与 source Hensel 和 `v_5(N_0)=lambda-2d` 合并：

\[
\boxed{
r_-\equiv
\varepsilon\iota\,9\cdot2^{M+m}c_+c_u
\pmod{5^{\lambda-2d}},
\quad
\iota^2\equiv-1
}
\]

\[
\Downarrow
\]

\[
\boxed{
r_-^2+(9\cdot2^{M+m}c_+c_u)^2
=k_h5^{\lambda-2d}X,
\quad
\gcd(r_-,9\cdot2^{M+m}c_+c_u)\mid9
}
\]

共同 Gaussian `5`-depth 归一化后：

\[
\boxed{
v_5\!\left(
\operatorname{Im}(\mathcal R_5\overline{\mathcal A_5})
\right)=d
}
\]

\[
\boxed{
r_+^2+(9\cdot2^{M+m}c_uc_-5^d)^2=k_hY
}
\]

并有精确 Gaussian composition

\[
\boxed{
\mathcal R_5\overline{\mathcal A_5}
=X\left(
\varepsilon r_+-i\,9\cdot2^{M+m}c_uc_-5^d
\right)
}
\]

\[
\Downarrow\quad(\mathbb Z[i]\text{ 唯一分解})
\]

\[
\boxed{
N(\alpha_X)=X/3^{v_3(X)},
\quad
\alpha_X\mid\mathcal A_5,\mathcal R_5
}
\]

\[
\boxed{
v_3(X)+v_3(Y)\le4,
\qquad
v_3(k_h)\le4
}
\]

奇 `3`-defect 的进一步分类：

\[
\boxed{
v_3(k_h)\text{ odd}
\Longrightarrow
\begin{cases}
v_3(a_3)=1,\ v_3(k_h)=1,\ v_3(a_2)\ge2,\\
\text{or}\\
v_3(a_2)=1,\ v_3(a_3)\ge2,\ v_3(k_h)\in\{1,3\}
\end{cases}
}
\]

\[
\boxed{
v_3(H)=v_3(\alpha)=1,
\qquad
v_3(\beta)=0
}
\]

平衡转移公共奇偶性 `delta`：

\[
\boxed{
N(\alpha_X^\sharp)=3^\delta X,
\quad
\alpha_X^\sharp\mid\mathcal A_5,\mathcal R_5
}
\]

\[
\boxed{
N(\mathcal B_5)=Y/3^\delta,
\quad
N(\mathcal G_5)=k_h/3^\delta,
\quad
\varepsilon r_+-iR_1
=3^\delta\mathcal G_5\overline{\mathcal B_5}
}
\]

消去共同 divisor 后的 source Hensel kernel：

\[
\boxed{
\pi_\iota^d\bar\pi_\iota^{\lambda-d}
\mid
c_u\mathcal G_5
-\varepsilon c_+\omega\mathcal B_5
}
\]

\[
\boxed{
5^\lambda
\mid
N(c_u\mathcal G_5
-\varepsilon c_+\omega\mathcal B_5)
}
\]

而且该同余提升为精确商：

\[
\boxed{
c_u\mathcal G_5-\varepsilon c_+\omega\mathcal B_5
=\pi_\iota^d\bar\pi_\iota^{\lambda-d}\mathcal W_5,
\qquad
v_{\pi_\iota}(\mathcal W_5)=0
}
\]

`theta` 同伴与上式只差一个已含完整 `5^lambda` 的项，故不是独立
obstruction。原 decimal plane 另外给出

\[
\boxed{
5^\lambda C
=g(a_3+3\cdot10^m)
+\varepsilon a_2c_Q5^d
-g^2k_h/2,
\qquad
0<C<\mathfrak L_0/1000
}
\]

同一个精确商还有统一 Archimedean 方向：

\[
\boxed{
4<\tan\arg(-\varepsilon\mathcal S_5)<5,
\qquad
\operatorname{sgn}
\left(
\arg(-\varepsilon\mathcal S_5)-\arg(a_2+iC_0)
\right)=\varepsilon
}
\]

约掉共同 `X` 后的有向面积为

\[
\boxed{
\operatorname{Im}
\left(
\mathcal W_5\bar\pi_\iota^{\nu_5}
\overline{\mathcal B_5}
\right)
=-\frac{c_uR_1}{3^\delta5^d}
}
\]

精确商再乘回共同 `5`-orientation：

\[
\boxed{
5^{\lambda-d}\mathcal W_5
+\varepsilon c_+\omega
\pi_\iota^{\nu_5}\mathcal B_5
=c_u\pi_\iota^{\nu_5}\mathcal G_5,
\qquad
\left|c_u\pi_\iota^{\nu_5}\mathcal G_5\right|
<5^{\lambda-d}/5
}
\]

因此右端是模 \(5^{\lambda-d}\mathbf Z[i]\) 的唯一中心 Gaussian
代表；剩余目标是把其 norm / area 与 `C` 代表联立排除。

进一步比较中心误差与主向量，得到

\[
\frac{
|c_u\pi_\iota^{\nu_5}\mathcal G_5|
}{
c_+\omega|\pi_\iota^{\nu_5}\mathcal B_5|
}
<\frac1{7680}.
\]

所以 \(\mathcal W_5\) 是逐坐标唯一最近整数商，并且

\[
\boxed{
0<\varepsilon
\left(
\tan\arg(-\varepsilon\mathcal S_5)-\frac{C_0}{a_2}
\right)
<\frac7{2000}
}
\]

即 Gaussian 商被压到真实 decimal prefix slope 的确定单侧窄条带；
下一步须将这个确定商与 `C` 自然代表联立，而不是继续增加粗角窗。

把 quotient slope 精确展开，并用

\[
C_0\mathcal U=\frac92wa_2,
\qquad
\mathcal K C_0=9\cdot2^Mc_Qq+\frac92w
\]

消去两项 decimal contribution，可进一步得到

\[
\boxed{
0<\varepsilon
\left(
\tan\arg(-\varepsilon\mathcal S_5)-\frac{C_0}{a_2}
\right)
<\frac1{a_2}
}
\]

以及

\[
\varepsilon=+1:\ 
C_0=\lfloor a_2\tan\phi_S\rfloor,
\qquad
\varepsilon=-1:\ 
C_0=\lceil a_2\tan\phi_S\rceil.
\]

所以提升后 quotient \(\mathcal S_5=\alpha_X^\sharp\mathcal W_5\) 的
方向唯一解码原 prefix 系数。由于它仍含共同 Gaussian factor，这尚未
给出裸 quotient 的 absolute argument；后者以及完整尺度、
\(a_2\) 与 `C` 仍待恢复。

方向条带的有向面积还满足

\[
\boxed{
\frac35<\frac{\Delta_S}{X_S}<\frac45,
\qquad
X_S=\Delta_S+E_S,
\qquad
\frac14\Delta_S<E_S<\frac23\Delta_S
}
\]

故出现商恰为 `1` 的正 Euclidean step；其 Gaussian norm 与 decimal
plane 协变性是下一条明确的下降缺口。

该实线性 step 的 determinant 实为 \(-\varepsilon a_2\)，因此不保持
Gaussian norm。真正的 quotient-pair Euclidean step 是

\[
Q_E=\operatorname{nint}
\left(\frac{c_+\omega}{5^{\lambda-d}}\right),
\qquad
\mathcal R_E=-\varepsilon\mathcal W_5-Q_E\mathcal V_5,
\]

并严格满足

\[
\boxed{
0<N(\mathcal R_E)<\frac14N(\mathcal V_5),
\qquad
v_{\pi_\iota}(\mathcal R_E)=0
}.
\]

下一依赖边是证明 \(\mathcal R_E\) 的 decimal-plane / Hensel covariance；
若不能建立，该 Gaussian norm descent 仍不能迭代成 A2 descent。

同时

\[
\mathfrak K_5\mathcal R_E
=r_E\mathcal B_5-\varepsilon c_u\mathcal G_5,
\qquad
r_E\equiv c_-^{-1}\theta\pmod{5^{\lambda-d}},
\]

且 \(r_E\) 是中心区间内唯一的 `5`-进单位代表。取 norm：

\[
\boxed{
5^\lambda N(\mathcal R_E)
=
\frac{Yr_E^2-2c_ur_+r_E+c_u^2k_h}{3^\delta},
\qquad
\operatorname{disc}=-4c_u^2R_1^2.
}
\]

故二维 quotient kernel 最终依赖到唯一 scalar representative 的一维
正定二次核；剩余边是排除其长 orientation 或建立 decimal child。

Hensel slot 的真实 decimal lift 为

\[
g\varrho=5^{\lambda+1}H-c_Qc_u,
\qquad
z_E=\frac{gr_E-c_+c_u}{5^{\lambda-d}},
\]

其中

\[
-g/2<z_E<g/2,
\qquad
c_-z_E\equiv-5^{d+1}H\pmod g.
\]

代入标量核：

\[
\boxed{
3^\delta g^2N(\mathcal R_E)
=5^{\nu_5}Yz_E^2
-2\varepsilon c_ua_2c_-z_E+c_u^2c_-^2X,
\quad
\operatorname{disc}=-4c_u^2c_-^2C_0^2.
}
\]

相应 Gaussian 向量可约去完整 \(g\)，且

\[
\frac{U_E+i\varepsilon V_E}{g}
=3^\delta\bar\pi_\iota^{\nu_5}
\mathcal R_E\overline{\mathcal B_5}.
\]

这条边把 `H` 与 prefix vector 接入 quotient composition；下一依赖仍是
decimal-child covariance 或与 `C` 代表的直接矛盾。

顶部代表与第二层代表继续合并为

\[
c_uC+\varepsilon a_2c_-z_E=g\chi_E,
\]

但完整 `g`-约分产生的 canonical Gaussian child 斜率严格落在
\((0,1/3999)\)（乘 unit 后落在 \((3999,\infty)\)），因此不能回到
A2 prefix window \((9/2,5)\)。这关闭的是同型下降路线，不是原候选。

独立的 rational-root 边则变为

\[
\boxed{
\Xi_C=\frac{F(3)}{2^{2M+2}5^{\nu_5}C}
\in\mathbf Z_{>0},
\quad
\gcd(\Xi_C,10)=1,
\quad
\Xi_C\equiv q^2c_+^2Y(3T+a_3)^2\pmod D.
}
\]

其相邻平移同时给出

\[
\boxed{
D-C\mid F(2),\qquad D+C\mid F(4),\qquad
\gcd(D-C,D+C)=1,
}
\]

并产生正奇 `5`-进单位 `Xi_-,Xi_+`。三个 cofactor 均满足

\[
\Xi_\bullet\equiv Y(qc_+a_3)^2\pmod{2^m5^d}.
\]

mixed bridge 还给出

\[
\gcd(c_uH,g)=1,\qquad
\operatorname{sgn}\chi_E=\operatorname{sgn}(\varepsilon z_E),
\qquad
\left|
\frac{g\chi_E}{\varepsilon a_2c_-z_E}-1
\right|<\frac3{50000}.
\]

且对 \(p^e\Vert g\)，

\[
\min\{v_p(\Xi_C),e\}
=\min\{2v_p(3T+a_3),e\};
\]

唯一需保留的零因子分支是 \(3T+a_3\) 的饱和通道。

非饱和奇素通道继续消去全部中心变量后：

\[
\boxed{
\left(\frac{\Xi_C}{p}\right)
=\left(\frac{-\varepsilon a_25^{M+d}}p\right),
\qquad
p\mid g,\quad p\nmid3T+a_3.
}
\]

二阶提升审计：

\[
\Xi_C\equiv
Y(qc_+(3T+a_3))^2(1-3DC^{-1})\pmod{g^2},
\]

\[
\boxed{
1-3DC^{-1}\text{ 在 }g^2\text{ 的每个 prime-power 分量上为平方}.
}
\]

故 quadratic-character 加深不再是一条独立依赖边。

三点 secant cubic 的 non-character 边：

\[
\Delta_-=\frac{\Xi_C-\Xi_-}{2^m5^d},
\qquad
\Delta_+=\frac{\Xi_+-\Xi_C}{2^m5^d},
\]

\[
\boxed{
1<\frac{\Delta_-}{\Delta_+}<2,\qquad
v_2(\Delta_-)=v_2(\Delta_+)=1,
}
\]

\[
\boxed{
\Delta_--\Delta_+
=2^{m+1}5^dc_u^2
\{g((20P-9)T-a_3)-H_0\},
}
\]

\[
v_2(\Delta_--\Delta_+)=m+1,\qquad
v_5(\Delta_--\Delta_+)=d.
\]

中心二阶差分继续给出

\[
\mathcal T_2=(D+C)\Delta_++(D-C)\Delta_-,
\]

从而 \(\Delta_+\) 落入模 \(D^2-C^2\) 的唯一显式 CRT 类。新的开放量为
\[
Q_\Delta=\left\lfloor\Delta_+/(D^2-C^2)\right\rfloor.
\]

中心二阶差分先给出 once-normalized
\(\widetilde{\mathcal T}_2\)，且
\(v_5(\widetilde{\mathcal T}_2)=d\)。真正的 \(2,5\)-primitive
additive cofactor 是

\[
\widehat{\mathcal T}_2
=\mathcal T_2/(2^{m+1}5^{2d}),
\]

并满足：

\[
\boxed{
\widehat{\mathcal T}_2
\equiv-5^{\lambda-d}(c_uC)^2\pmod g,
\qquad
\widehat{\mathcal T}_2\equiv3\pmod4,
\qquad
\gcd(\widehat{\mathcal T}_2,10c_ug)=1.
}
\]

因此它含有外部 \(3\bmod4\) 素数到奇次；待证边是
\[
5^d\widehat{\mathcal T}_2
=5^{\epsilon_5}Z_\nu^2+\mathscr J_\Delta,
\qquad
\mathscr J_\Delta\equiv2\pmod4.
\]

这与旧 odd inert excess 是同一机制；待证边改为排除
\(\mathscr J_\Delta\) 的 denominator-prefix / source / spontaneous
三类 prime 来源。

显式审计：
\[
\widehat{\mathcal T}_2
=2^mc_u^2g^2\mathscr S_0
-(c_Qq)^2 5^{2\lambda-d}XY.
\]
当前 norm difference 没有精确 orientation / inner-product identity；
canonical square 代入后只恢复上述 odd inert excess。

prime-source 接触边：
\[
\gcd(\widehat{\mathcal T}_2,Q_0XY)
=\gcd(\mathscr S_0,Q_0XY),
\qquad
\gcd(\widehat{\mathcal T}_2,f)
=\gcd(\mathscr R_f,f).
\]
非 \(3\) inert prime 不进入 \(XY,c_u,g\)；固定 \(3\) 的一阶接触由
\(3\mid Q_0\) 与 \(a_2a_3\bmod3\) 的 (16.310) 分类。剩余边是排除
\((q,\mathscr S_0)\)、\((f,\mathscr R_f)\)、source
\(\mathfrak n\) 与 endpoint-external 通道。

curvature character 边：
\[
\operatorname{disc}_K(\mathscr S_0)=8\mathscr R_{23},
\qquad
\operatorname{disc}_K(\mathscr R_f)=8A_f\mathscr R_{23,f}.
\]
其中 \(\mathscr R_{23}\) 是判别数 \(-23\) 的二元型；simple-root
\(q\)-contact 给 (16.316)，double-root 给 (16.318)，
\(f\)-contact 给 (16.320)。剩余依赖是把这些 \(23\)-分裂条件与
source / factor-allocation character 联立成矛盾。

全局配方审计边：
\[
\left[c_ug(TK-9T-2a_3)\right]^2
=\mathscr C_{23}+5^m\widehat{\mathcal T}_2.
\]
所以前述 curvature character 都是 (16.323) 的 principal-square
投影；必须另取 source/prefix 的独立 character，不能重复收费。

cross-field companion：
\[
\mathscr C_{23}
=U_{23}^2+23V_{23}^2+5^{3\lambda}Q_0^2XY,
\]
且它模 \(5^{2m}\) 为 principal square、模 \(8\) 为 \(1\)。因此
\(2,5\)-进局部非平方边已降级；剩余边只能来自 odd-prime
orientation 或实数 gap。

canonical shifted-factor 边：
\[
\mathscr V_-=5^\lambda fc_-^2X-\mathscr E_{23},
\qquad
\mathscr V_+=5^\lambda qc_+^2Y-\mathscr E_{23},
\]
\[
\gcd(\mathscr V_-,f)=\gcd(\mathscr L_{23},f),
\quad
\gcd(\mathscr V_+,q)=\gcd(\mathscr L_{23},q),
\quad
\gcd(\mathscr V_-,\mathscr V_+)
=\gcd(TK-9T-2a_3,Z).
\]
消去 \(Z\) 的 \(\mathscr D_Z\) 满足
\[
\gcd(\mathscr D_Z,qf)=\gcd(\mathscr L_{23}^2,qf),
\]
故未饱和 denominator contact 全为偶赋值，剩余依赖缩成
\(p^e\Vert qf,\ p^e\mid\mathscr L_{23}\) 的 saturation。

模 \(4\) orientation 边：
\[
q\equiv3,\quad f\equiv1,\quad
X\equiv Y\equiv-Z\pmod4.
\]
\(Z\equiv1\) 对应固定 \(3\) balanced transfer，shifted pair 恰共享
一份 \(3\) 且 \(3\nmid\widehat{\mathcal T}_2\)；
\(Z\equiv3\) 对应 denominator \(q\) carrier。

saturation Hensel-target 边：
\[
\mathscr G_q=5^{M-1}(a_3-90T)+a_3H,
\qquad
\mathscr G_f=\mathscr G_q-18\cdot2^{m+1}c5^d.
\]
剩余 denominator 候选必须满足
\[
p^e\Vert q,\ p^e\mid\mathscr G_q
\quad\text{或}\quad
p^e\Vert f,\ p^e\mid\mathscr G_f.
\]
下一依赖是用 \(C\) 自然代表/source phase 对这两个完整
prime-power gcd 作无界排除。

\(q\)-saturation amplification：令
\(a_p=v_p(c_Q)\)、\(n_p=a_p+e\)。rational-root 等式给出完整
prime-power budget；middle branch 满足
\[
v_p(gs_p-5^\lambda r_p)=e+2a_p,
\]
third branch 在 generic 层满足
\(v_p(KD-N)=n_p\)。若同时是 \(q\)-侧 additive-cofactor carrier，
则
\[
\mathscr S_0=T(K^2-26)-(2K-9)(2a_3+9T),
\qquad K^2\equiv26\pmod p.
\]
这排除第一 valuation branch，并把结构例外压到固定素数
\(11,23\)。下一依赖是排除这两个固定 prime 的无限 Hensel lift，
并关闭 middle/third 的精确 residual-unit character。
在 \(p\nmid c_Q\) 的 generic 层，\(f\)-侧 saturation 不落在同一个零点，而满足
\[
K^2-26\equiv
\left(\frac{2c_Q}{2^m5^\lambda g}\right)^2N_0\not\equiv0\pmod p.
\]
\(p\mid c_Q\) 时该式退化回零点，正是显式 overlap。
\(q\)-侧另有 prefix bridge
\(J_{101}^2\equiv101N_0-26\pmod p\)；下一 character/resultant
必须同时使用这些 Gaussian-prefix 数据。
canonical factor allocation 还直接给出
\[
p\mid q\Longrightarrow N\equiv DK\pmod p.
\]
因此 generic middle branch 被删除，\(p\ne11,23\) 时唯一剩
\(v_p(KD-N)=v_p(c_Qq)\)；固定 \(11\) 是 middle/third overlap，
固定 \(23\) 是 right rational-root factor 的额外增深。
整数层还有
\[
q\mid DK-N,\qquad
2c_u(DK-N)/q=c_+^2Y+5^\lambda c_-^2X.
\]
在 saturation 内，两侧的截断赋值分别只读取
\[
K^2-26,\qquad
\Psi_f=b_2^2(K^2-26)-Q^2N_0>0.
\]
而 \((DK-N)/q\) 的非 \(3\) inert prime 满足
\(v_r((DK-N)/q)=v_r(H_0)\) 与 \((N_0/r)=-1\)。
下一依赖因而是两个纯 prefix gcd 加一个明确 sphere-height channel。

\[
Q_\Delta\ge5K,
\]

故 CRT 商路线仍含一个无界大商。

因此当前新增依赖边是

\[
\boxed{
(z_E,\chi_E)\text{ 中心核}
+
(\Xi_-,\Xi_C,\Xi_+)\text{ 三点平方类}
\Longrightarrow \text{待证矛盾}.
}
\]

所以后续主线是统一定向因子系统与 source 双 Hensel / prefix defect
的矛盾，具体即排除这个 `C` 的唯一自然代表或建立合法降高，而不是
继续固定 `eta` 枚举。

\[
DD
\Longrightarrow
\boxed{
\text{surplus simplex}
+
\text{near-square}
+
2/5\text{ resonance}
+
\text{near-}S\text{-unit}
}
\]

\[
\text{DD gap valuation}
+
F_-\text{ small-factor height}
+
2/5\text{-adic position split}
\Longrightarrow
\boxed{
\Delta_5>0
\text{ 在五进入口以上为空}
}
\Longrightarrow
\boxed{
n_3\le8S_{12}+6
}
\]

\[
\text{resonance 全赋值保留}
+
F_-<10^{4S+2m_3-n_3+4+\log_{10}2}
+
\text{模 }3\text{ 锁}
\Longrightarrow
\boxed{
n_3\le8S_{12}+5
}
\]

\[
n_3=8S_{12}+5
+
\text{三个二进位置穷尽}
\Longrightarrow
\boxed{
\text{最高整数层为空}
}
\Longrightarrow
\boxed{
n_3\le8S_{12}+4
}
\]

\[
\text{入口以上 resonance}
+
b_3\text{ 二进主导},\ t_2\ge2
+
\text{加权 }m_3\text{ 界}
\Longrightarrow
\boxed{
n_3\le8S_{12}
\text{（该子锥）}
}
\]

\[
n_3=8S_{12}+4
+
\text{其余二进位置排除}
+
t_2=1\text{ 的未粗化 small-factor 界}
\Longrightarrow
\boxed{
\text{十个 }(S,m_3)\text{ 尺寸}
+
\text{统一极端位数形状}
}
\]

\[
\text{十尺寸核}
+
\text{225 个赋值元组}
+
v_2(\kappa+2G)\text{ 的余因子区间证书}
\Longrightarrow
\boxed{
n_3=8S_{12}+4
\text{ 为空}
}
\Longrightarrow
\boxed{
n_3\le8S_{12}+3
}
\]

\[
n_3\in\{8S_{12}+3,8S_{12}+2\}
+
\text{一般 }G<10^S\text{ 余因子区间}
+
\text{16772 个赋值元组有限证书}
\Longrightarrow
\boxed{
\text{两层均为空}
}
\Longrightarrow
\boxed{
n_3\le8S_{12}+1
}
\]

\[
n_3=8S_{12}+1,\ S\ge4
+
\text{48808 个赋值元组}
+
\text{唯一余因子与模 }3\text{ 判别式矛盾}
\Longrightarrow
\boxed{
\text{该层只剩 }S=2,3
}
\]

\[
\text{非 dominant 的 }n_3\le7S+3
+
S=2,3\text{ 的统一尾权有限核}
+
\text{二/五进必要条件与十个判别式}
\Longrightarrow
\boxed{
n_3=8S_{12}+1
\text{ 整层为空}
}
\Longrightarrow
\boxed{
n_3\le8S_{12}
}
\]

最后这个界仍是相对线性界，不是 DD 的 prefix-uniform 绝对高度界；
\(S=2,3\) 的步骤是明确有界的有限证书，不覆盖更低无界层。

在新的等号层还有进一步分解：

\[
n_3=8S_{12},\ S\ge11
+
\text{五进入口与二进位置强制}
\Longrightarrow
\boxed{
b_3\text{ 二进主导},\quad t_2\ge1
}
\]

\[
t_2=1
+
\text{70 个尺寸与 51828 个赋值行}
+
\text{精确模余因子计数}
\Longrightarrow
\boxed{
S\ge11\text{ 的 }t_2=1\text{ 边界为空}
}
\]

\[
t_2\ge2
+
\text{加权 }m_3\text{ 界}
+
\text{squarefree gap 取等}
\Longrightarrow
\boxed{
m_3=3S,\ d_3=5S,\
\kappa=10^{2S}c,\ 1\le c\le8,\
10^{S-3}\mid b_3
}
\]

后一个方框是八个无界常数核族，不是有限候选。它们与
在这一中间节点，\(2\le S\le10\) 仍只是入口下的有限 \(S\)-列表，
并非完整有限候选盒，所以单凭这里还不能推出
\(n_3\le8S_{12}-1\)。

随后八核还满足

\[
F_-=10^{2S}\rho,
\quad0<\rho<20000
+
\text{primitive recovery 与 gap 的两个 }\mu/\nu\text{ 式}
\Longrightarrow
\boxed{
\frac{c10^{2S}+2G}{\gcd(c10^{2S},G)}\mid\rho Q
}
\]

\[
\frac{\gcd(c10^{2S},G)}c\le128
+
Q<10^S
\Longrightarrow
\boxed{
n_3=8S_{12}\Longrightarrow S\le10
}
\]

所以八个无界核现已关闭；在这一中间节点仍待处理的是
\(2\le S\le10\) 的等号层有限 \(S\)-列表与 \(n_3<8S\) 的无界
区域。此时统一界仍为 \(n_3\le8S\)，但对 \(S\ge11\) 已有更强的
\(n_3\le8S-1\)。

对小切片中的唯一五进正规形还有：

\[
4\le S\le10,\ t_2=1
+
\text{同步 }F_-\text{ 因子界}
+
\text{余因子与真实分母证书}
\Longrightarrow
\boxed{
\text{唯一尾核模 }3\text{ 非平方}
}
\]

\[
t_2\ge2,\ S\ge7
+
\text{大除数无界矛盾}
\quad\text{或}\quad
S\in\{4,5,6\}
+
\text{真实分母有限证书}
\Longrightarrow
\boxed{
\text{该正规形在 }4\le S\le10\text{ 全空}
}
\]

这个方框只指
\(e_5=q_5,k_5>g_5,h_5=f_5=g_5\) 的唯一五进正规形；普通入口下
resonance、\(5\nmid b_3\) 与 \(\Delta_5^\pm\) 不在其覆盖范围。

最后对全部剩余五进状态：

\[
S\ge4,\ n_3=8S,\ 5\mid b_3
+
\text{位数 gap 锁 }e_5=q_5
+
\text{三种五进状态穷尽}
\Longrightarrow
\boxed{
5\mid b_3\text{ 的等号层为空}
}
\]

\[
5\nmid b_3
+
\text{尾权 }\kappa=2\cdot5^{3S}
+
\text{二进 resonance 剩余类}
\Longrightarrow
\boxed{
5\nmid b_3\text{ 的等号层为空}
}
\]

\[
\Longrightarrow
\boxed{
n_3=8S_{12}\Longrightarrow S_{12}\in\{2,3\},
\qquad
S_{12}\ge4\Longrightarrow n_3\le8S_{12}-1
}
\]

最后两个尺寸按 dominant 性质分开：

\[
S\in\{2,3\},\ n_3=8S,
\ \text{non-dominant}
+
m_3\ge7S
+
\text{primitive denominator-tail 核}
\Longrightarrow
\boxed{\text{该扇区为空}}
\]

这里尾核分别在 \(m_3=10,17\) 后为空，而 non-dominant 分别要求
\(m_3\ge14,21\)，所以没有截断无界 prefix surplus。

\[
S\in\{2,3\},\ n_3=8S,
\ \text{dominant}
+
n_1+n_2\le S+2
+
\text{两素数三状态与 squarefree gap}
+
\text{703、38633 个判别式}
\Longrightarrow
\boxed{\text{该扇区为空}}
\]

\[
\Longrightarrow
\boxed{
n_3=8S_{12}\text{ 整层为空},
\qquad
n_3\le8S_{12}-1
}
\]

最后一步只有 dominant 子扇区使用明确有界的 numerator 有限证书；
更低的 \(n_3\le8S-1\) 无界区域仍为 `待证`。

再把第 25 节的取等层补齐到全部小尺寸：

\[
S\ge5\text{ 的 }2,5\text{-单位间距}
+
S=2,3\text{ 的完整尾表}
+
S=4,m_3=27\text{ 的零尾核}
\Longrightarrow
\boxed{m_3\le6S+2}
\]

\[
m_3\le6S+2
+
\text{non-dominant 时 }d_3\le S
\Longrightarrow
\boxed{n_3\le7S+2\text{（non-dominant）}}
\]

所以 \(n_3=8S-1\) 对所有 \(S\) 都进入 dominant 扇区。在
\(S\ge18\) 的五进入口以上还有

\[
t_2\ge2
+
m_3=3S-1+j,\quad j\in\{0,1,2\}
+
\kappa=\frac{c10^{2S}}2,\quad1\le c<20
+
\text{19、9、0 个常数核}
\Longrightarrow
\boxed{\text{大除数矛盾}}
\]

\[
t_2=1
+
\text{45 个尺寸与 15525 个 valuation rows}
+
\text{精确 floor-sum 余因子证书}
\Longrightarrow
\boxed{S\ge18\text{ 的该支为空}}
\]

\[
\Longrightarrow
\boxed{
n_3=8S_{12}-1
\Longrightarrow
d_3=\max(s_1,s_2,d_3),\quad S_{12}\le17
}
\]

这个方框只证明最高允许层已成为有限原问题切片；该有限盒尚未核验
为空，\(n_3\le8S-2\) 的无界区域也仍为 `待证`。

对这个有限盒的两个最小尺寸：

\[
S\in\{2,3\},\quad n_3=8S-1
+
\text{2665、126669 个 dominant tail rows}
+
\text{两素数三状态与无溢出 squarefree gap}
+
\text{24396、1582338 个统一判别式}
\Longrightarrow
\boxed{\text{两个尺寸均为空}}
\]

\[
\Longrightarrow
\boxed{n_3=8S_{12}-1\Longrightarrow4\le S_{12}\le17}
\]

这里的空性是明确有界的有限证书；在下面继续处理 \(S=4\) 之前，
\(4\le S\le17\) 尚未核验。

同一最高层还有新的通用过滤与首个逐尾长证书：

\[
F_-=\frac{2(\kappa+2G)\mu^2}{G_0}
+
10^{m_3}QG_0=2\kappa\mu\nu
+
\frac{\mu}{\nu}
=\frac{E\kappa^2}{10^{m_3}Q^2(\kappa+G)}
\Longrightarrow
\boxed{
\frac{\mathfrak L_F}{\gcd(\mathfrak L_F,Q)}\mid F_-
}
\]

其中

\[
\mathfrak L_F=
\frac{\kappa(\kappa+2G)}
{\gcd(\kappa(\kappa+2G),\kappa+G)}.
\]

这个大除数不要求 resonance。进一步，最低四层给出

\[
S=4,\quad n_3=31,\quad m_3\in\{11,12,13,14\}
+
\text{squarefree-gap 位数核}
+
\text{精确二次区间与两素数三状态}
+
\text{694825、10987773、714489、99342 个大整数判别式}
\Longrightarrow
\boxed{m_3\ge15\text{（该 }S=4\text{ 切片）}}
\]

再由

\[
m_3\in\{15,\ldots,21\}
+
\text{流式精确两素数剩余树与统一判别式}
+
\text{固定全量计数中零个平方}
\Longrightarrow
\boxed{15\le m_3\le21\text{ 为空}}
\]

以及

\[
m_3\in\{22,\ldots,26\}
+
\text{primitive denominator-tail divisor tree}
\Longrightarrow
\boxed{\text{tail 核为空}},
\]

最终得到

\[
\boxed{S=4,\ n_3=31\text{ 为空}}
\Longrightarrow
\boxed{n_3=8S-1\Longrightarrow5\le S\le17}.
\]

这里仍是明确有界的有限证书；\(5\le S\le17\) 与更低无界层尚未
关闭。

下一个尺寸的高尾依赖链为

\[
S=5,\quad n_3=39
+
22\le m_3\le26
+
\text{128 位两素数剩余树与多精度统一判别式}
\Longrightarrow
\boxed{22\le m_3\le26\text{ 为空}},
\]

以及

\[
27\le m_3\le32
+
\text{primitive denominator-tail divisor tree}
\Longrightarrow
\boxed{\text{tail 核为空}}.
\]

再有最低层依赖链

\[
S=5,\quad n_3=39,\quad m_3=14
+
\text{唯一位数形状}
+
\text{四角、valuation box、}L_F\text{ 与 denominator-unit box}
+
\text{75 条 primitive tails 的完整两素数状态}
\Longrightarrow
\boxed{m_3=14\text{ 为空}}.
\]

再接上下一层的完整有限链

\[
S=5,\quad n_3=39,\quad m_3=15
+
\text{三个严格位数形状}
+
\text{四类 numerator-free 必要过滤}
+
\text{完整两素数状态与多精度判别式}
\Longrightarrow
\boxed{m_3=15\text{ 为空}}.
\]

同理，下一层的七个严格位数形状给出

\[
S=5,\quad n_3=39,\quad m_3=16
+
\text{完整两素数状态与多精度判别式}
\Longrightarrow
\boxed{m_3=16\text{ 为空}}.
\]

所以

\[
\boxed{
S=5,\ n_3=39
\Longrightarrow
17\le m_3\le21,
\quad18\le d_3\le22.
}
\]

这个结论不排除其余五个尾层，也不改变 DD 更低层的无界性。

\[
A_1
\Longrightarrow
\boxed{
\text{thin annulus}
+
\text{slope lock}
+
\text{saturated tail bound}
}
\]

最终都汇入同一个尚未完全解决的问题：

\[
\boxed{
\text{如何对无界前缀得到 prefix-uniform contradiction?}
}
\]

---

<!-- end-history-dependency -->

<a id="history-conclusion"></a>

> 整合来源：`conclusion.md`（2026-10-01 归并前正文；不是当前状态）。

# 当前研究结论

本文件对应原总稿 §43。它只总结当前严格边界和三个分支的剩余问题，不把研究路线或有限证书包装成主定理证明。

## 2026-08-13 DD 更新

DD 的当前统一整数相对界已经从下文的历史状态更新为

\[
\boxed{n_3\le8S_{12}-2}.
\]

此外有解析锥

\[
n_3<\frac{31}{4}S_{12}+\frac{6581}{960},
\]

并且在调用经典 Schmidt Subspace Theorem 后得到阈值非有效的渐近界

\[
\limsup\frac{m_3}{S_{12}}\le5,
\qquad
\limsup_{DD}\frac{n_3}{S_{12}}
\le6.308883577618\ldots.
\]

这些结果仍没有给出有效绝对高度界，也没有关闭 DD。假想 frontier sequence 的剩余指数级自由度已集中到 moving pair-max Gaussian core `(C_L,Pi)`；更一般的结构表述仍需关闭 projective/common-scale allocation 与单侧 moving tail factor的兼容性。完整接续正文及失效路线审计见
[DD 主干 §27.33](branches/double-deficit/core.md#2733-2026-08-13-后续合并进展)。

下文保留 2026-08-10 原总稿机械拆分出的历史结论，用于追溯前一阶段推导；涉及 DD 的较旧数字由本节覆盖。

> 迁移说明：以下正文由原始总稿机械拆分，公式和证明状态不作数学改写。
# 43. 研究结论

这道题目前已经不再是“一个巨大的、无结构的十进制拼接丢番图方程”。

它已经被压缩成三个相当具体的终端问题。

\(A_2\) 的难点是：

\[
\boxed{
\text{高阶 source Hensel 接触能否与真实十进制窗口长期共存？}
}
\]

DD 的难点是：

\[
\boxed{
\text{所有强制五进 resonance 的高层消失后，
阈值以下的 resonance/non-resonance 锥能否仍随前缀高度无界增长？}
}
\]

\(A_1\) 的难点是：

\[
\boxed{
\text{在 Gaussian descent 完全失效的 saturated 平面中，
decimal shift }g\text{ 能否无界？}
}
\]

现阶段最值得优先攻击 DD。

其优先级来自这样一个事实：第 27 节已经首次把局部 resonance 数据转成了 prefix-uniform 的全局高度矛盾。原顶部的结构是

\[
\text{极端不对称}
+
\text{短 numerator block}
+
\text{near-square}
+
\text{双 Hensel resonance}
+
\text{near-}2,5\text{-smooth}.
\]

这个最顶层及其下方的单五进 resonance 带现已全部排除，并先得到中间相对界

\[
n_3\le8S_{12}.
\]

其中五进入口以上的两个 non-resonance 状态已经全部排除：

\[
\Delta_5<0
\quad\text{与}\quad
\Delta_5>0
\quad\text{均为空}.
\]

入口以上唯一剩余的 resonance 支还带有加权赋值惩罚。原先可能达到的最高整数层
\(n_3=8S_{12}+5\) 已经排除：无界的 \(t_2\ge2\) 子锥与
\(3\mid m_3\) 的高度上界冲突，其余二进位置则最终只留下

\[
(S,m_3)=(4,17),(5,21),
\]

并在两处都得到 \(\kappa>10QG\) 的整数矛盾。

继续保留加权 \(m_3\) 界后，入口以上的 \(t_2\ge2\) 无界子锥已经整体
降到 \(n_3\le8S_{12}\)。所以当前最高层 \(n_3=8S_{12}+4\) 只可能
来自 \(t_2=1\)，并且被严格压成十个 \((S,m_3)\) 尺寸；所有尺寸还
共同强迫一个 denominator 长度为 \(1\)、另一个为 \(S-1\) 的极端
前缀位数形状。随后精确余因子证书穷尽 225 个允许赋值元组：每个元组
都要求一个显式短区间包含指定奇数倍的 \(2^h\)，但所有区间均为空。
因此 \(n_3=8S_{12}+4\) 已排除，并得到上述新界。

同一证书随后改用不依赖极端位数形状的一般界 \(G<10^S\)。层
\(n_3=8S_{12}+3\) 与 \(n_3=8S_{12}+2\) 分别只留下 32、59 个
尺寸和 2677、14095 个允许赋值元组；对应余因子区间仍全部为空。
因此这两个层也已排除，并在这一阶段把相对界降到上述
\(n_3\le8S_{12}+1\)（这是关闭下一层之前的中间状态）。

对新最高层 \(n_3=8S_{12}+1\)，入口以上的全部 \(S\ge4\) 也已经
排除。86 个尺寸和 48808 个赋值元组只留下
\((S,m_3)=(5,16)\) 的一个余因子；它固定
\((b_1,b_2)=(768,97)\) 与 \((s_1,s_2)=(-2,4)\)，随后
near-square 判别式满足 \(Y^2\equiv2\pmod3\)。第 27.15 节因此只
留下 \(S=2,3\) 的入口边界。

这两个边界现也已由独立有限证书关闭。严格的非 dominant 改进界
\(n_3\le7S+3\) 先排除 \(S=3\)，并把 \(S=2\) 压到
\(m_3=15\) 的取等锥；统一尾整除在该锥没有余因子。dominant 部分
分别产生 618、39710 个 denominator-tail 元组，二进位置、强制
resonance 与五进三分支把它们压到 114、27 个 tail-prefix 组合；
squarefree gap 只留下 2、8 个统一判别式，而精确整数平方根检查
验证十个均非平方。因此整层 \(n_3=8S_{12}+1\) 已排除，并得到开头
所列的中间界 \(n_3\le8S_{12}\)。

在新边界 \(n_3=8S_{12}\) 上，入口以上的结构也已经继续收缩。
当 \(S\ge11\) 时，非 \(b_3\) 二进主导位置全部排除；\(t_2=1\)
只留下 70 个有理尺寸和 51828 个必要赋值行。精确 floor-sum 模计数
先与 1000 个随机小盒的直接枚举对照，再验证所有余因子区间均为空，
所以这一子锥已经由有限证书关闭。

同一边界的 \(t_2\ge2\) 支仍是无界问题，但已经得到严格正规形：

\[
m_3=3S,\qquad d_3=5S,
\]

前两块除交换外只能有一个 denominator 长度为 1、numerator 长度为
\(S+1\)，另一个 denominator 长度为 \(S-1\)、numerator 长度为
1，并且

\[
\kappa=10^{2S}c,
\qquad c\in\{1,2,3,4,5,6,7,8\},
\qquad 10^{S-3}\mid b_3.
\]

这不是八个有限候选，而是八个前缀族；不过第 27.18 节又从

\[
F_-=10^{2S}\rho,
\qquad0<\rho<20000
\]

和两个精确 \(\mu/\nu\) 公式推出

\[
\frac{c10^{2S}+2G}{\gcd(c10^{2S},G)}\mid\rho Q.
\]

八核固定赋值把 gcd 商统一限制为
\(\gcd(c10^{2S},G)/c\le128\)。因此左边的 \(10^{2S}\) 增长与
右边的 \(10^S\) 高度发生严格矛盾，八个无界族全部关闭。当前得到

\[
n_3=8S_{12}\Longrightarrow S_{12}\le10,
\qquad
S_{12}\ge11\Longrightarrow n_3\le8S_{12}-1.
\]

在这一中间阶段，整个 \(8S\) 层只被压到 \(2\le S\le10\) 的有限
\(S\)-列表；这并不自动给出完整有限候选盒，所以当时还不能降低统一
相对界。

这个小切片中的入口上同型五进正规形也已进一步排除。对
\(t_2=1\)，56 个尺寸的 97693 个赋值行经同步 \(F_-\) 因子界、
精确余因子和真实 denominator factorization 只剩
\((b_1,b_2)=(768,97)\) 的一个尾核；near-square 判别式仍满足
\(Y^2\equiv2\pmod3\)。对 \(t_2\ge2\)，\(S\ge7\) 已由同一个
无界大除数矛盾排除，\(S=4,5,6\) 的真实分母有限证书也没有幸存者。
因此

\[
4\le S\le10,\quad n_3=8S,
\]

中的 \(b_3\)-二进主导唯一五进正规形全空。这里必须保留限定：普通
入口下 resonance、\(5\nmid b_3\)、\(\Delta_5^\pm\) 和部分其他
二进位置仍未处理。

第 27.21 节又把这些限定内的状态全部处理完毕。对 \(S\ge4\)，若
\(5\mid b_3\)，位数下界恢复 \(e_5=q_5\)，此后 resonance、
\(\Delta_5<0\)、\(\Delta_5>0\) 依次由唯一正规形、单因子高度与
primitive recovery 排除。若 \(5\nmid b_3\)，尾权只能退化为
\(2\cdot5^{3S}\)：大 \(S\) 直接违反尾高度，\(S=4,5,6\) 又与三个
精确二进剩余类矛盾。因此当前等号层结论加强为

\[
n_3=8S_{12}\Longrightarrow S_{12}\in\{2,3\},
\qquad
S_{12}\ge4\Longrightarrow n_3\le8S_{12}-1.
\]

第 27.22 节随后专门处理 \(S=2,3\)，但没有把固定 \(S\) 直接误作
完整有限盒。non-dominant 扇区分别强迫 \(m_3\ge14,21\)，而统一
denominator-tail 整除核在 \(m_3=10,17\) 后已经为空，所以可能无界的
prefix surplus 无需枚举。dominant 扇区才由
\(n_1+n_2\le S+2\) 真正有限化；1527、72092 个 tail rows 经二进
位置、两素数三状态、既约性与 squarefree gap 后，留下 703、38633
个非负统一判别式，精确整数平方根检查全部非平方。因此整个等号层
已经关闭，当前严格界为

\[
\boxed{n_3\le8S_{12}-1.}
\]

但这仍然不是 DD 全局空性；有限证书只覆盖严格有限化的 dominant
小尺寸，non-dominant 小尺寸由不含 numerator 枚举的尾整除排除，
其余大 \(S\) 等号层由无界论证关闭。更低的 \(n_3\le8S-1\) 区域
仍可随 \(S\) 无界，需要对自发 resonance 与两条 non-resonance 支
分别建立同样的主导项或高度矛盾。这一 gap-valuation / dominant-term /
height 思维也有可能被移植到 \(A_2\) 和 \(A_1\) 的剩余核中。

第 27.23 节又在这个界上取得了两项严格进展。首先，第 25 节原有的
\(S\ge5\) 取等排除，与 \(S=2,3\) 的完整尾表及
\(S=4,m_3=27\) 的零尾核合并，给出全局

\[
m_3\le6S+2,
\qquad
\text{non-dominant 时 }n_3\le7S+2.
\]

其次，最高允许层 \(n_3=8S-1\) 已全部进入 dominant 扇区。在
\(S\ge18\) 的五进入口以上，\(t_2\ge2\) 被压成 19、9、0 个
常数核，并由与第 27.18 节同型的大除数矛盾排除；\(t_2=1\) 则压成
45 个尺寸、15525 个 valuation rows，并由精确 floor-sum 余因子证书
排除。因此

\[
\boxed{
n_3=8S_{12}-1
\Longrightarrow
d_3=\max(s_1,s_2,d_3),\quad S_{12}\le17.
}
\]

这不是该层空性的证明，但第一次把当前最高允许层变成了同时限制
denominator 与 numerator 位数的完整有限原问题盒。下一步可以对这个
盒做分层证书；更低的 \(n_3\le8S-2\) 仍保留无界核心。

这个有限盒的两个最小尺寸现也已关闭。对 \(S=2,3\)，完整 dominant
tail 核分别有 2665、126669 行；两素数三状态、既约性与无溢出的
squarefree gap 把最终判别式数压到 24396、1582338，精确整数平方根
检查全部非平方。因此当前最高层进一步缩成

\[
\boxed{n_3=8S_{12}-1\Longrightarrow4\le S_{12}\le17.}
\]

对下一个尺寸 \(S=4\)，第 27.25–27.28 节先从 \(F_-\)、primitive recovery
与正拼接 gap 导出通用大除数

\[
\frac{\mathfrak L_F}{\gcd(\mathfrak L_F,Q)}\mid F_-,
\qquad
\mathfrak L_F=
\frac{\kappa(\kappa+2G)}
{\gcd(\kappa(\kappa+2G),\kappa+G)},
\]

它不要求 resonance。随后 squarefree gap 与四个完整有限证书排除
\(m_3=11,12,13,14\)：四层分别只剩
694825、10987773、714489、99342 个大整数判别式需要精确平方根
检查，全部非平方。余下 \(m_3=15,\ldots,21\) 的流式精确证书也没有
平方判别式，而 \(m_3=22,\ldots,26\) 的 primitive denominator-tail
核为空。因此

\[
\boxed{
S=4,\quad n_3=31
\Longrightarrow
\text{无 DD 候选},
\qquad
n_3=8S-1\Longrightarrow5\le S\le17.
}
\]

这里的 \(S=4\) 空性是明确有界的有限证书，不是 \(8S-1\) 整层空性，
更不是 DD 的全局空性。

对 \(S=5,n_3=39\)，第 27.29 节又以相同的精确流式引擎排除
\(m_3=22,\ldots,26\)，并证明 \(m_3=27,\ldots,32\) 的 primitive
denominator-tail 核为空。第 27.30 节再由 denominator-unit valuation
box 与完整两素数状态证书排除唯一最低层 \(m_3=14\)；第 27.31–27.32
节再以三个和七个严格位数形状的完整多精度判别式证书排除
\(m_3=15,16\)。因此这个尺寸
当前严格缩为

\[
\boxed{17\le m_3\le21,\qquad18\le d_3\le22.}
\]

这仍是明确有界的分层进展；\(S=5\) 尚未关闭，最高层还有
\(6\le S\le17\)，更低层仍可随 \(S\) 无界增长。

在那之前，严格的最终状态仍然是：

\[
\boxed{
\text{主不存在性命题高度受限、结构非常刚性，但尚未完成证明。}
}
\]

<!-- end-history-conclusion -->
