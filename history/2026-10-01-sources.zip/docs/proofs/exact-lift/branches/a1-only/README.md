# `A_1`-only 分支

本文件是 A1 的规范导航入口。A1 当前仍为 **待证**。历史 fixed-layer 与 central-denominator 证书曾把 minimal-diagonal 前沿压到 `k=g>=32` 的 deep denominator；后续已有 minimal-diagonal / top-layer 子域的闭合记录，各项范围和依赖以对应专题为准，不能据此把整个 A1 标记为空。

## 最高层 `d=2` 的当前关闭范围

[任意双 surplus 的统一稳定区](top-layer-r1-joint-halfgap-collapse.md#joint-surplus-stable-region)
从原 contact/excess 恒等式构造整数，已严格关闭最高层 `d=2,g>=1`
中 `N=max(r+g+1,s)` 满足

\[
k+s\ge2g+2,\quad k+r\ge g+1,\quad N\le4g,\quad N\le2k
\]
的无界区域，包括 `r,s>=2`。特别地整个矩形
`k>=2g+1,1<=r<=3g-1,1<=s<=4g` 为空；结论来自完整不等式证明，
不是有限枚举。2026-09-30 的 [§10.8 推广](top-layer-r1-joint-halfgap-collapse.md#joint-surplus-curvature-wall-extension)
把原 `N<=2k-1` 推进到 `N<=2k`，并新增关闭矩形
`k>=2g,1<=r<=3g-1,2<=s<=4g`。同轮审计给旧 `r=1` 定理补上 `k>=g`，未补此条件的
旧范围标为 **失效/降级（证明缺条件）**。
首个 amplified-radius 壳层 `k>=2g+2,N=4g+1` 的
`rho/H>=28/125` 子支也由 [§10.9](top-layer-r1-joint-halfgap-collapse.md#joint-surplus-first-radius-shell-upper-tail-collapse)
严格关闭，低 significand 走廊仍待证。
[§10.10](top-layer-r1-joint-halfgap-collapse.md#joint-surplus-first-contact-wall-collapse)
还在 `k+r=g` 的首个 contact 放大边界关闭
`k+s>=2g+2,N<=2k,1/10<=rho/H<=529/1000` 的无界子域，
并由 [5-adic 深度证明](top-layer-r1-joint-halfgap-collapse.md#joint-surplus-contact-endpoint-5adic-depth)
关闭 `v5(b3)<=s-r-1` 的无界子支；更深的第三分母仍待证。
最新开放区见 [post-minimal-surplus frontier](top-layer-post-minimal-surplus-frontier.md)。

## 全局四层与低层的当前进展

[分母 kernel 与原整数 recovery](top-layer.md#lower-layer-decimal-denominator-kernel)
严格关闭 `d=-1,tau2<=tau1`（特别是第二分母为十进制幂），以及
`0<=g<=1`、三个分母都满足 `v2(bi)=v5(bi)`、前两个分母深度不等
的无界子域。三个分母的 `10`-unit 因子在这些结论中均无界。
一般 `g` 的同一状态在第二分母正深度下只余 (LK11) 等深 word corridor。
等深、正首深度的 unit product 在 `g=0` 只余 `11/19 mod20`；
一般 unit 因子的 `g=1,delta=2` 边界只余 `1/9 mod20`，仍待证。

对于纯等前缀 `b1=b2=10^e`，(LK19G) 关闭所有 `g>=0,d=2`
（第三分母任意），(LK17) 关闭 `g=0` 的明确 `d=1` 深 `k` 区域。
曾提出的一般 `g` 的 (LK17G) 推广因遗漏 `10^(-g)` 已标为失效/降级。
在第三分母 balanced 的子域，完整 `j|10^(e+1)+1` 加原 recovery
已经关闭 `g=0` 的全部奇数 `e`、`e=0`，以及 `e=2,4`；其中后两项
是完整明示有限证书。`g=1` 的首 strict 边界 `delta=2` 也已关闭，
进而关闭其全部正奇数 `e` 与 `e=2`。
当前纯等前缀余核包括 `g=0` 偶数 `e>=6`，以及 `g=1` 偶数
`e>=4,delta>=3`；更一般的 unit 因子、其他 `g` 与非 balanced 分母
仍待证，不能由这些子域结论关闭完整 A1。

## 规范主线与账本

先读 [`core.md`](core.md)、[`rational-contact.md`](rational-contact.md)、[`top-layer.md`](top-layer.md)、[`diagonal.md`](diagonal.md)。细粒度来源归并在 [`boundary-and-tail-ledger.md`](boundary-and-tail-ledger.md)、[`central-denominator-ledger.md`](central-denominator-ledger.md)、[`deep-denominator-ledger.md`](deep-denominator-ledger.md)、[`finite-layer-certificates-ledger.md`](finite-layer-certificates-ledger.md)。

`global-*`、`deep-*`、`top-layer-*` 与 `w1-*` 文件是前一轮多分支整合后仍含独有推导的 standalone continuation，因此保留并在下方完整索引。文件名中的 `closure/collapse` 只作用于其显式 hypotheses。

## 全局 / minimal-diagonal continuation

- [`decimal-height-synchronization.md`](decimal-height-synchronization.md)
- [`global-squarefree-terminal.md`](global-squarefree-terminal.md)
- [`global-terminal-bridge.md`](global-terminal-bridge.md)
- [`minimal-diagonal-closure.md`](minimal-diagonal-closure.md)
- [`deep-hl-local-signature-count-correction.md`](deep-hl-local-signature-count-correction.md)

## Double-deep 2-high / W2 continuation

- [`deep-2high-coefficient-source-minima.md`](deep-2high-coefficient-source-minima.md)
- [`deep-2high-contact-shell-coupling.md`](deep-2high-contact-shell-coupling.md)
- [`deep-2high-contact-shell-full-sign.md`](deep-2high-contact-shell-full-sign.md)
- [`deep-2high-decimal-height-collapse.md`](deep-2high-decimal-height-collapse.md)
- [`deep-2high-dual-slot-inverse-lock.md`](deep-2high-dual-slot-inverse-lock.md)
- [`deep-2high-dual-slot-shell.md`](deep-2high-dual-slot-shell.md)
- [`deep-2high-normalized-complement-shell.md`](deep-2high-normalized-complement-shell.md)
- [`deep-w2-coefficient-source-conflict.md`](deep-w2-coefficient-source-conflict.md)
- [`deep-w2-periodic-source-envelope.md`](deep-w2-periodic-source-envelope.md)
- [`deep-w2-periodic-source-matching.md`](deep-w2-periodic-source-matching.md)

## Single-deep continuation

- [`deep-single2-decimal-height-collapse.md`](deep-single2-decimal-height-collapse.md)
- [`deep-single5-decimal-height-collapse.md`](deep-single5-decimal-height-collapse.md)
- [`deep-single5-lowedge-small-supply-collapse.md`](deep-single5-lowedge-small-supply-collapse.md)
- [`deep-single5-lowedge-sphere-lock.md`](deep-single5-lowedge-sphere-lock.md)
- [`deep-single5-topedge-2resonance-certificate.md`](deep-single5-topedge-2resonance-certificate.md)
- [`deep-single5-topedge-common-quotient.md`](deep-single5-topedge-common-quotient.md)
- [`deep-single5-topedge-contact-descaling.md`](deep-single5-topedge-contact-descaling.md)
- [`deep-single5-topedge-decimal-factor-pair.md`](deep-single5-topedge-decimal-factor-pair.md)
- [`deep-single5-topedge-finite-height.md`](deep-single5-topedge-finite-height.md)
- [`deep-single5-topedge-fullsign-lock.md`](deep-single5-topedge-fullsign-lock.md)
- [`deep-single5-topedge-geB-phase-certificate.md`](deep-single5-topedge-geB-phase-certificate.md)
- [`deep-single5-topedge-high5-phase-certificate.md`](deep-single5-topedge-high5-phase-certificate.md)
- [`deep-single5-topedge-odd-cancellation.md`](deep-single5-topedge-odd-cancellation.md)
- [`deep-single5-topedge-oriented-root-factors.md`](deep-single5-topedge-oriented-root-factors.md)
- [`deep-single5-topedge-rational-phase-shell.md`](deep-single5-topedge-rational-phase-shell.md)
- [`deep-single5-topedge-real-sign-orientation.md`](deep-single5-topedge-real-sign-orientation.md)
- [`deep-single5-topedge-root-selection.md`](deep-single5-topedge-root-selection.md)
- [`deep-single5-topedge-strictlow-phase-certificate.md`](deep-single5-topedge-strictlow-phase-certificate.md)
- [`deep-single5-topedge-supply-compression.md`](deep-single5-topedge-supply-compression.md)
- [`deep-single5-topedge-u2-collapse.md`](deep-single5-topedge-u2-collapse.md)
- [`deep-single5-topedge-ultrathin-gap.md`](deep-single5-topedge-ultrathin-gap.md)

## Top-layer continuation

- [`top-layer-final-corridor-certificate.md`](top-layer-final-corridor-certificate.md)
- [`top-layer-final-corridor-reduction.md`](top-layer-final-corridor-reduction.md)
- [`top-layer-inner-wedge-digit-lock.md`](top-layer-inner-wedge-digit-lock.md)
- [`top-layer-inner-wedge-mixed-collapse.md`](top-layer-inner-wedge-mixed-collapse.md)
- [`top-layer-inner-wedge-pure2-collapse.md`](top-layer-inner-wedge-pure2-collapse.md)
- [`top-layer-inner-wedge-pure5-collapse.md`](top-layer-inner-wedge-pure5-collapse.md)
- [`top-layer-inner-wedge-stable-closure.md`](top-layer-inner-wedge-stable-closure.md)
- [`top-layer-inner-wedge-uniform-phase.md`](top-layer-inner-wedge-uniform-phase.md)
- [`top-layer-k2g-closure.md`](top-layer-k2g-closure.md)
- [`top-layer-k2g-gap-smallL-collapse.md`](top-layer-k2g-gap-smallL-collapse.md)
- [`top-layer-k2g-prime-shape-collapse.md`](top-layer-k2g-prime-shape-collapse.md)
- [`top-layer-k2g-pure5-finite-collapse.md`](top-layer-k2g-pure5-finite-collapse.md)
- [`top-layer-k2g-pure5-odd-orientation.md`](top-layer-k2g-pure5-odd-orientation.md)
- [`top-layer-k2g-pure5-positive-root-orientation.md`](top-layer-k2g-pure5-positive-root-orientation.md)
- [`top-layer-k2g-pure5-real-phase-shell.md`](top-layer-k2g-pure5-real-phase-shell.md)
- [`top-layer-k2gm1-closure.md`](top-layer-k2gm1-closure.md)
- [`top-layer-k2gm1-mixed-collapse.md`](top-layer-k2gm1-mixed-collapse.md)
- [`top-layer-k2gm1-pure2-collapse.md`](top-layer-k2gm1-pure2-collapse.md)
- [`top-layer-k2gm1-pure5-collapse.md`](top-layer-k2gm1-pure5-collapse.md)
- [`top-layer-k2gm2-closure.md`](top-layer-k2gm2-closure.md)
- [`top-layer-k2gm2-mixed-collapse.md`](top-layer-k2gm2-mixed-collapse.md)
- [`top-layer-k2gm2-pure2-collapse.md`](top-layer-k2gm2-pure2-collapse.md)
- [`top-layer-k2gm2-pure5-collapse.md`](top-layer-k2gm2-pure5-collapse.md)
- [`top-layer-k2gm2-tail-center.md`](top-layer-k2gm2-tail-center.md)
- [`top-layer-k2gminus1-tail-center.md`](top-layer-k2gminus1-tail-center.md)
- [`top-layer-minimal-offdiagonal-J-compression.md`](top-layer-minimal-offdiagonal-J-compression.md)
- [`top-layer-minimal-offdiagonal-far-collapse.md`](top-layer-minimal-offdiagonal-far-collapse.md)
- [`top-layer-minimal-surplus-closure.md`](top-layer-minimal-surplus-closure.md)
- [`top-layer-post-minimal-surplus-frontier.md`](top-layer-post-minimal-surplus-frontier.md)
- [`top-layer-r1-joint-halfgap-collapse.md`](top-layer-r1-joint-halfgap-collapse.md)
- [`top-layer-s1-far-lowr-collapse.md`](top-layer-s1-far-lowr-collapse.md)
- [`top-layer-s1-far-radius-phase.md`](top-layer-s1-far-radius-phase.md)
- [`top-layer-uniform-offdiagonal-tail-center.md`](top-layer-uniform-offdiagonal-tail-center.md)

## W1 continuation

- [`w1-fixed-pair-descent.md`](w1-fixed-pair-descent.md)
- [`w1-global-complement-minimum.md`](w1-global-complement-minimum.md)

## 当前边界

A1 的历史 saturated `L=1` 支已经退出前沿。`k>=32` deep-denominator 是较早 minimal-diagonal 前沿；当前阅读时以对应后续 standalone continuation 的显式范围为准；任何有限 certificate、fixed pair descent 或 minimal-diagonal closure 都不能自动覆盖 moving-prefix / 非 minimal-diagonal 的完整 A1。
