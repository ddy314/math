# A1 `d=2` frontier after minimal-surplus closure

> 日期：2026-08-22。
>
> 本文件只记录已证明的 sector exhaustion 与当前开放区；不引入新局部证明。

> 2026-09-06 更新：§3 补上旧 `r=1` 证明遗漏的 `k>=g`；§4 接入
> 任意双 surplus 的统一稳定区。新增证明在对应专题 §10，本页只同步范围。

## 1. minimal surplus is closed

`top-layer-minimal-surplus-closure.md` 已证明
\[
\boxed{d=2,\ r=s=1\Longrightarrow\varnothing.}
\]

因此对 `g>=1` 的最高层，`top-layer.md` 已有 `r,s>=1`，当前只需研究
\[
\boxed{r+s\ge3.}
\]

---

## 2. `s=1` edge

`top-layer-s1-far-lowr-collapse.md` 与 `top-layer-s1-far-radius-phase.md` 给出：

### closed strip
\[
\boxed{
 k\ge2g+1,
 \qquad
 1\le r\le3g-1
 \Longrightarrow\varnothing.
}
\]

### radius phase in the next strip
若
\[
k\ge2g+1,
\qquad
3g\le r\le2k-g-2,
\]
则定义
\[
U_1=(5-z)10^{r+g}+10^g+J,
\qquad
\psi=10^{g-1}r_3,
\]
有
\[
\boxed{
0<
J+1-\rho10^{g-k}
-5\cdot10^{r-3g}\psi^2
<1/25.
}
\]

因此 `s=1` 剩余必须属于：

1. `k<=2g` 的 near-contact 区；或
2. `k>=2g+1,r>=3g` 的 squared-tail phase 区；其中
3. `r>=2k-g-1` 时 curvature 也进入 leading scale。

---

## 3. `r=1` edge

`top-layer-r1-joint-halfgap-collapse.md` 定义
\[
A=U_1/10^{g+2},
\qquad
B=U_2/10^s,
\qquad
N=\max(g+2,s),
\]
以及 joint integer
\[
K
=10^N(A+B-51/100)+10^{N-g-2}.
\]

已证明若
\[
 k+s\ge2g+2,
 \qquad k\ge g,
 \qquad
 N\le4g,
 \qquad
 N\le2k-2,
\]
则
\[
\boxed{r=1\Longrightarrow\varnothing.}
\]

所以 `r=1,s>=2` 的任何剩余 candidate 必须突破至少一面：
\[
\boxed{
 k+s<2g+2
\quad\text{or}\quad k<g
\quad\text{or}\quad
N>4g
\quad\text{or}\quad
N>2k-2.
}
\]

这里 `k<g` 也必须作为独立的 contact amplification 保留。其余三者对应：

1. denominator-contact amplified；
2. squared-tail amplified；
3. curvature amplified。

---

## 4. 任意双 surplus 的统一稳定区

[joint-surplus 定理](top-layer-r1-joint-halfgap-collapse.md#joint-surplus-stable-region)
直接使用 residue、half-gap 与原始 contact/sphere 恒等式，证明对
`d=2,g>=1,r,s>=1`，令 `N=max(r+g+1,s)`，则
\[
\boxed{
k+s\ge2g+2,\quad k+r\ge g+1,\quad
N\le4g,\quad N\le2k
\Longrightarrow\varnothing.
}
\]
**状态：已严格完成，覆盖无界区域。** 它不依赖 §1 的 minimal-surplus
闭合链，也不依赖原 §3 漏条件的版本。2026-09-30 的
[§10.8 推广](top-layer-r1-joint-halfgap-collapse.md#joint-surplus-curvature-wall-extension)
用 joint half-gap 的凸余量界及真实第三块耦合，把原 `N<=2k-1`
推进到 `N<=2k`。

特别地整个二维矩形
\[
\boxed{
k\ge2g+1,\qquad1\le r\le3g-1,\qquad1\le s\le4g
}
\]
已经排除，包括此前两条边界之外的 `r,s>=2`。
因此在 `k>=2g+1` 区域，任何候选都必须满足
\[
\boxed{r\ge3g\quad\text{或}\quad s\ge4g+1.}
\]

此外整个 `k>=2g,1<=r<=3g-1,2<=s<=4g` 矩形也已关闭。
证明中的正整数满足
\[
0<\mathcal K-T\delta-\tfrac12 10^{N-4g}\psi^2
<\tfrac{47}{100}10^{N-2k}.
\]
真实第三块使 contact 与 radius 两项的总和严格小于 `51/100`，
四个范围条件因而把总和压到 `49/50` 以下。
这是严格的整数矛盾，不是“区间窄所以无解”的唯一性推断。
突破范围后的 amplified phases，以及 `g=0,d=-1,0,1` 仍待处理。

首个 squared-tail 壳层 `k>=2g+2,N=4g+1` 还有严格必要条件
\[
\mathcal K\in\{1,2,3,4,5\},\qquad0<\mathcal K-5\psi^2<1047/100000,
\quad\psi=10^{g-1}a_3/b_3.
\]
[§10.9](top-layer-r1-joint-halfgap-collapse.md#joint-surplus-first-radius-shell-upper-tail-collapse)
已进一步严格关闭该壳层的 `rho/H>=28/125` 子支；剩余必须
`1/10<=rho/H<28/125`，且五个 `K` 各有更强的 rational significand 上界。
其中 `K=5` 只余 `rho/H<20003/200000`、`eta>99985/100000`、`n3>=4`
的 endpoint corridor。下一步可把这些耦合窗口送入真实第三块的
exact decimal recovery；整个壳层尚未关闭，不能把固定窗口数理解成有限候选总数。

## 5. 首个 contact 放大边界的新关闭子域

[§10.10](top-layer-r1-joint-halfgap-collapse.md#joint-surplus-first-contact-wall-collapse)
已严格证明：保留 `k+s>=2g+2,N<=2k`，允许
`k+r=g`，并限制真实第三块 `1/10<=rho/H<=529/1000`，则整个子域为空。
这些条件自动保证 `g>=3r+2,k>=4,N=s,N-4g<=-12`。
此时 contact 指数为零，原稳定区的 `T delta<1/10` 已不可用；
新证明先用 `T delta<=rho/H` 与同一真实尾的 radius 耦合，
随后利用范围蕴含将 radius 压到 `5*10^-13` 以下，得到正整数 `K<1`。

特别地任意 `r>=1,g>=3r+2,k=g-r,g+r+2<=s<=2g-2r` 均有
`N=s<=2k`，在上述 significand 范围已经关闭。首个 contact 边界的
`rho/H>529/1000` 或 `N>2k` 仍待证。
保留 `N<=2k` 时基础 endpoint kernel 还强迫 `y=0`、`T delta=rho/H`
精确成立，剩余整数只能 `K=1` 且 `z=1 mod10`；具体上端点窗口见
该专题 (JS24)。同一端点还接入公共模 `9` 分母过滤，但已有通过 phase、
位数、既约和模 `9/27` 的局部允许点；完整平方等式仍不成立。
新增 [5-adic 深度证明](top-layer-r1-joint-halfgap-collapse.md#joint-surplus-contact-endpoint-5adic-depth)
已严格排除 `v5(b3)<=nu=s-r-1` 的整个无界子支，且剩余必须
`nu+1<=v5(b3)<=nu+m3`。上界等号的 resonance 仍保留必要 unit 条件。
先前模 `9/27` 点也被此新条件排除；这些仍是必要条件，不是整个 contact
边界的关闭。完整 word/sphere gap 进一步给无界必要形状：非 beta-resonance
下 `d5=v5(b3)-nu<g` 必须 `n3=2d5`，`d5>g` 必须 `m3=3d5`，
`d5=g` 必须 `n3<=2g` 并满足精确 cancellation 深度；上界
beta-resonance 则保留相反的 `H_sph+y3` 赋值。独立剩余方程见
(JS25)--(JS29)。
令 `d2=v2(b3)-nu,d5=v5(b3)-nu`。真实第二素数归约见
[2-adic 深度证明](top-layer-r1-joint-halfgap-collapse.md#joint-surplus-contact-endpoint-2adic-depth)。
当前独立剩余系统为：

| 分支范围 | 仍可能满足的必要形状 | 证明定位 |
| --- | --- | --- |
| `(2S):v2(w)<nu`，非 `2-near-beta`、非 `5-beta` | `d2,d5<=g,max(d2,d5)=g`，且满足有界相对 gap | (JS30)--(JS34) |
| `(2S)`、`5-beta:d5=m3` | `13<=g<26r+6,g<d2<11g/6,m3=3d2-1`；`r<=12` 时 `g<=317`，盒内未枚举 | (JS38)--(JS40) |
| `(2S)`、`2-near-beta:d2=m3-1` | `5-low:g<=24r-4`；`5-balanced:g<=24r+4`；`5-high:d5<6g`，并满足加法 word 与 prefix divisor | (JS41)--(JS42) |
| 非 `(2S)`，记 `t=v2(w)-nu>=0` | `r>=13` 与真实第一分母质量；double-low 仅余 `t=0,d2=d5`；regular high/high 中 `t=0` 需 `d2=d5`，`t>0` 需 `t=1 mod3` | (JS35)--(JS37)、(JS43) |

`(2S)` 对 `r<=12` 自动成立。表中的相对盒没有给整个分支的绝对前缀上界；
非 `(2S)` 的完整 `5-beta` 仍须 (JS38)--(JS39) 的三项 cancellation。
这些必要形状须与 (JS24)--(JS29)、原 integer recovery 同时满足；
完整首 contact 边界仍待证。

## 6. structural picture

当前两条一-surplus edges 已经表现出完全相同的三尺度结构：

- contact phase；
- third-radius square phase；
- curvature / prefix phase。

minimal-surplus closure 对应三者都在 sub-unit 范围，从而 integer phase 无法存在；surplus 增大后，开放区恰好从某一个 source 被放大到整数 leading digits 的位置开始。

因此下一步不应恢复到原始 `(a1,b1,a2,b2)` 大整数枚举，而应继续提取 amplified source 的 leading-digit integer，并尝试证明它形成 surplus descent 或与 global decimal recovery 冲突。

<a id="lower-layer-current-kernels"></a>

## 7. 全局四层与低层：当前分母归约及原整数系统

[全局四层专题 §11](top-layer.md#lower-layer-decimal-denominator-kernel)
的完整推导、当前覆盖表与核对命令承载以下无界排除：

1. `d=-1,tau2<=tau1`，其中 `taui=bi/10^(mi-1)`；特别是最低层的
   第二分母为十进制幂时整个子域为空。
2. `0<=g<=1,v2(bi)=v5(bi)` 且前两个分母深度不等。三个分母可写成
   `10^ei ui,(ui,10)=1`，三个 unit 因子均没有高度上界。真正 sphere/word
   强迫第三分母在 `2/5` 上都唯一最深，再给同一个 `H-a3` 不兼容的
   两素数深度。一般 `g>=0,c>b+g` 的同一 state 也被关闭，
   其中 `b=e2,c=e3`。若 `b>=1`，一般 `g` 的全部非等深 word 状态
   也已关闭；剩余必须 `c-b=g,n3<=2[c-max(e1,e2)]-2`。

pure-decimal 三分母的较窄子域已由公共模九条件完整关闭；这里第二项
还覆盖 `(1,1,4) mod9` 等公共模九允许类。等深、正首深度支的真实
source 三分裂为 `delta>g:m3=3delta`、`delta<g:n3=2delta`、
`delta=g:n3<=2g-1`。`g=1,delta=1` 已由 (LK14) 排除。
一般 unit 因子的 `g=1,delta=2` 只能 `product=1/9 mod20`，仍开放；
`delta>=3` 才是 `11/19 mod20`。遗漏前一边界的一阶 word 项的旧扩张
已经撤回，不能据此关闭整个等深 state。

对于纯等前缀 `b1=b2=10^e`，第三单位因子还必须
`j|Q0=10^(e+1)+1`。目前的完整覆盖如下：

| 明确子域 | 当前结论与依据 |
| --- | --- |
| `g>=0,d=2,e>=0`，第三分母任意 | (LK19G) 的原 contact 比较严格为空 |
| `g=0,d=1,e>=1,2k>=e+2`，第三分母任意 | (LK17) 严格为空 |
| `g=0`、奇数 `e>=1`、第三分母 balanced | (LK15)--(LK16) 的整除与模四冲突严格为空 |
| `g=0,e=2,4`、第三分母 balanced | (LK21)--(LK22) 两份完整有限证书；分别 `219101`、`262115848` 合法 `J`，无原 root |
| `g=1,e>=1,delta=2`、第三分母 balanced | (LK23) 严格归约到唯一末端并完整核验；`d0 k<=7,d1 k<=9`、`30923` 合法 `J`，唯一平方投影不满足原 recovery |
| `g=0,e=0`、第三分母 balanced | (LK24) 无界五进深度排除接完整末端；`161` 个 `J`，无平方 discriminant |

因此在 `g=0` 的纯等前缀 balanced-tail 中，只余偶数 `e>=6`、
`e/2+1<=delta<=e`、`digits(j)=2delta-e`、`j|Q0`、`j=11/19 mod20`。
仅需 `d=0,1`，分别有 `k<=3delta+1`、`k<=e/2`，但 `e` 没有绝对上界。
在 `g=1` 的同类 state 中，正奇数 `e` 与 `e=2` 都已关闭；
一般偶数 `e>=4,delta>=3` 仍无界。`g>=1,e=0`、一般首分母 unit
因子、非 balanced 分母及最低层 `tau2>tau1` 仍是独立开放范围。
原 numerator recovery 与 quadratic 在 (LK18)--(LK20)，actual norm 投影
仍有满足整除/模九/模二十的允许点；允许的投影不是原 exact lift 解。
一般 `g` 的 d1 角点推广 (LK17G) 因遗漏 `P` 第二项的 `10^(-g)`
标为失效/降级；当前仅保留 `g=0` 的 (LK17)，不据此扩大任何关闭范围。
