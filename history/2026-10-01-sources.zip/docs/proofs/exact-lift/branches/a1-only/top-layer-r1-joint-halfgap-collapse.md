# A1 最高层：joint-surplus 稳定区与放大边界

本文的当前范围是最高层 `d=2,g>=1,r,s>=1`。
完整 A1 仍待证；本专题严格关闭稳定区和边界子域，并保留原整数恢复系统。
旧 `r=1` 证明在 §1--§9，任意双 surplus 的主证明在 §10。

| 当前命题范围 | 状态与定位 |
| --- | --- |
| `k+s>=2g+2,k+r>=g+1,N=max(r+g+1,s)<=min(4g,2k)` | 已严格完成：整片为空；(JS13)--(JS14)、[§10.8](#joint-surplus-curvature-wall-extension) |
| `k>=2g+2,N=4g+1,u=rho/10^g>=28/125` | 已严格完成：首个 radius 壳层的上段为空；[§10.9](#joint-surplus-first-radius-shell-upper-tail-collapse) |
| `k+r=g,k+s>=2g+2,N<=2k,u<=529/1000` | 已严格完成：首个 contact 边界的下段为空；[§10.10](#joint-surplus-first-contact-wall-collapse) |
| 上一 contact 边界中 `u>529/1000` | 待证：先归约到 `y=0,K=1,z=1 mod10`，再按真实 `2/5` 深度分支；(JS24)--(JS43) |
| 首 radius 壳层的低 `u`、更深 contact/radius 放大区 | 待证；phase 窗口与允许同余类不能替代 sphere/word |

`r,s` 是两个 surplus，`u` 是真实第三分母 significand。
下文各明确关闭范围均由原 contact、word 与 sphere 推导；有限回归脚本
只核对恒等式和有界样例。当前剩余清单也见
[post-minimal-surplus frontier](top-layer-post-minimal-surplus-frontier.md)。

> 2026-09-06 审计与推广：旧 §7.1 在 `N=s` 时还需要 `k>=g`，
> 原未加此条件的关闭范围标为 **失效/降级（证明缺条件，并非已找到反例）**。
> 下文 (1) 与 §9 已补齐。新增 [§10](#joint-surplus-stable-region) 从
> `top-layer.md` 的原始 contact/excess 恒等式独立推导任意 `r,s>=1`
> 的统一稳定区，不依赖旧的漏条件结论。

> 日期：2026-08-22。
>
> 依赖：`top-layer.md` 的 residue kernel、half-gap sharpening 与 positive-excess decomposition。
>
> 范围：
> \[
> d=2,\qquad r=1,\qquad s\ge2,\qquad g\ge1.
> \]

状态：**严格关闭一个 prefix-uniform 稳定区。** 本文把两个 coprime residues 合并成一个 joint half-gap integer，并证明在 third-contact / squared-tail / curvature 三个尺度都尚未越界时不存在候选。

最终：若
\[
\boxed{
 k+s\ge2g+2,
 \qquad k\ge g,
 \qquad
 N:=\max(g+2,s)\le4g,
 \qquad
 N\le2k-2,
}
\tag{1}
\]
则
\[
\boxed{
 d=2,\ r=1,\ s\ge2
 \Longrightarrow\text{empty}.
}
\tag{2}

---

## 1. decimal residue coordinates

令
\[
\varepsilon:=10^{-2k},
\qquad
H:=10^g.
\]
在 `r=1` 中写
\[
W:=w/10.
\]
一般 second residue 写
\[
Y:=10^{k+g+1-s}y,
\qquad
Z:=z/10^s.
\]

residue kernel 给
\[
A:=\frac{U_1}{10^{g+2}}=X+W,
\qquad
B:=\frac{U_2}{10^s}=Y+Z,
\tag{3}
\]
以及
\[
\boxed{
 p:=\phi_1=\frac{A}{1-\varepsilon W},
 \qquad
 q:=\phi_2=\frac{B}{1+\varepsilon Y}.
}
\tag{4}

half-gap shell 给
\[
\boxed{
\frac12<p+q<\frac{267}{500}<0.534.
}
\tag{5}
特别地
\[
0<p,q<0.534.
\tag{6}

由 `A=X+W>=W` 与 (4)：
\[
\boxed{0<W<p<0.534.}
\tag{7}

同理 `B=Y+Z>=Y`，由 (4)：
\[
Y\le q(1+\varepsilon Y).
\]
本文的 (1) 强迫 `k>=2`，故 `epsilon<=10^-4`。因此
\[
\boxed{0\le Y<0.535.}
\tag{8}

---

## 2. joint half-gap integer

令
\[
\boxed{N:=\max(g+2,s).}
\]
因为 `A` 的十进制分母整除 `10^(g+2)`，`B` 的十进制分母整除 `10^s`，所以
\[
\boxed{
\mathcal J
:=10^N\left(A+B-\frac{51}{100}\right)
\in\mathbf Z.
}
\tag{9}

又 `N>=g+2`，定义
\[
\boxed{
K:=\mathcal J+10^{N-g-2}\in\mathbf Z.
}
\tag{10}

记
\[
S:=2(p+q)-1>0,
\qquad
T:=10^{N-2}.
\]
由 (4)：
\[
A+B
=p+q+\varepsilon(Yq-Wp).
\]
所以
\[
100(A+B-51/100)
=50S-1+100\varepsilon(Yq-Wp).
\]
结合 (9)-(10)：
\[
\boxed{
\frac KT
=50S-\left(1-\frac1H\right)
+100\varepsilon(Yq-Wp).
}
\tag{11}

这是一般 `s` 的 joint 版本；当 `s=1`、`N=g+2` 时退化为此前单 residue `J` identity。

---

## 3. contact phase

rational-contact definitions 给
\[
\lambda=\frac{b_2}{Q},
\qquad
\theta=\frac{\rho}{HQ},
\]
故
\[
\boxed{
\frac\theta\lambda=\frac\rho{Hb_2}.
}
\tag{12}
定义
\[
\boxed{
\delta:=\frac\rho{Hb_2}.
}
\tag{13}

在 `r=1`，由
\[
b_1=10^{2k+1}(1-\varepsilon W),
\]
\[
b_2=10^{m_2-1}(1+\varepsilon Y),
\]
直接得到
\[
\boxed{
100\frac\lambda\varepsilon
=
\frac{1+\varepsilon Y}
{1-\varepsilon W+\frac\varepsilon{100}(1+\varepsilon Y)}.
}
\tag{14}
由 (7)-(8)、`epsilon<=10^-4`：
\[
\left|100\frac\lambda\varepsilon-1\right|<1.1\varepsilon.
\tag{15}

positive-excess contact bracket 为
\[
(1+\varepsilon p)-H^{-1}(1-\varepsilon q)
+\delta(\widehat R-\zeta).
\tag{16}

由 (1) 的 `k+s>=2g+2` 与 `rho<H`、`b2>=10^(k-g+s-1)`：
\[
0<\delta<10^{g-k-s+1}\le10^{-g-1}\le10^{-2}.
\tag{17}

又
\[
1-\varepsilon q<\widehat R<1+\varepsilon p
\]
以及 third-radius bound 给出的 `delta*zeta<epsilon/H`，所以 (16) 与
\[
B_0:=1-H^{-1}+\delta
\]
之差绝对值小于 `0.6 epsilon`。

再由
\[
\left|\frac{1+\varepsilon p+\widehat R}{2}-1\right|<0.534\varepsilon,
\]
和 (15)，可安全得到
\[
\boxed{
B_0-3\varepsilon
<50S_{\rm contact}
<B_0+3\varepsilon.
}
\tag{18}

---

## 4. curvature pays the only negative decimal correction

由 (5) 可证明统一不等式
\[
\boxed{
2p+q^2-3p^2>0.21.
}
\tag{19}
证明：

- 若 `p>=1/2`，则 `p<0.534`，故
  \[
  2p-3p^2>2(0.534)-3(0.534)^2>0.21;
  \]
- 若 `p<1/2`，由 `p+q>1/2` 有 `q>1/2-p`，所以
  \[
  2p+q^2-3p^2
  >\frac14+p-2p^2\ge\frac14.
  \]

由 (7)：
\[
-100\varepsilon Wp>-100\varepsilon p^2.
\]
所以 curvature source 与该负项合并后：
\[
\begin{aligned}
&50\varepsilon(2p+q^2-p^2)
-100\varepsilon Wp\\
&\qquad>
50\varepsilon(2p+q^2-3p^2)
>10.5\varepsilon.
\end{aligned}
\tag{20}

`+100 epsilon Yq`、third-radius source 与 `epsilon^2p^2` 均非负。因此 (18),(20) 与 (11) 给
\[
\boxed{
\frac KT>\delta+50S_{\rm rad}>0.
}
\tag{21}
特别地
\[
\boxed{K\in\mathbf Z_{>0}.}
\tag{22}

---

## 5. exact squared-tail phase

沿用
\[
\psi:=10^{g-1}r_3,
\qquad0<\psi<1.
\]
positive-excess 中
\[
S_{\rm rad}=rac{r_3^2}{10^{2g+2}}.
\]
因此
\[
\boxed{
50T S_{\rm rad}
=5\cdot10^{N-4g-1}\psi^2.
}
\tag{23}

---

## 6. uniform upper remainder

上界时从 (11) 丢掉负项 `-100 epsilon Wp`。由 (18)：contact error `<3 epsilon`。

又由 (6),(8)：
\[
2p+q^2-p^2<1.354,
\]
\[
100Yq<28.6,
\qquad
50\varepsilon p^2<0.002\quad(\varepsilon\le10^{-4}).
\]
所以除 contact center 与 exact radius phase 外，normalized remainder 安全小于
\[
\boxed{101\varepsilon.}
\tag{24}

结合 (21),(23)：
\[
\boxed{
0<
K-T\delta
-5\cdot10^{N-4g-1}\psi^2
<101T\varepsilon.
}
\tag{25}

---

## 7. the three stable scales are all below one

现在使用 (1)。

### 7.1 denominator-contact phase

若 `N=s>=g+2`，则由 `b2>=10^(k-g+s-1)`：
\[
T\delta
<10^{s-2}\frac{10^g}{10^g10^{k-g+s-1}}
=10^{g-k-1}\le\frac1{10}.
\]

若 `N=g+2>s`，则
\[
T\delta=H\delta=\frac\rho{b_2}
<10^{2g-k-s+1}\le\frac1{10}
\]
由 `k+s>=2g+2`。

所以统一有
\[
\boxed{0<T\delta<1/10.}
\tag{26}

### 7.2 squared-tail phase

由 `N<=4g` 与 `psi<1`：
\[
\boxed{
0<5\cdot10^{N-4g-1}\psi^2<\frac12.
}
\tag{27}

### 7.3 curvature remainder

由 `N<=2k-2`：
\[
101T\varepsilon
=101\cdot10^{N-2-2k}
\le0.0101<0.012.
\tag{28}

---

## 8. integer contradiction

由 (25)--(28)：
\[
0<K<\frac1{10}+\frac12+0.012<1.
\]
但 (22) 给 `K` 为正整数。矛盾。

这证明 (2)。

---

## 9. new `r=1` frontier

本文之后，`r=1,s>=2` 若仍有 candidate，至少必须突破以下三道稳定墙之一：
\[
\boxed{
 k+s<2g+2
\quad\text{or}\quad k<g
\quad\text{or}\quad
\max(g+2,s)>4g
\quad\text{or}\quad
\max(g+2,s)>2k-2.
}
\]
这里前三类尺度之外还须保留 `k<g` 的 contact amplification；不能从
其余三条旧假设推出 `k>=g`。例如 `(g,k,s)=(10,8,14)` 满足旧 (1)，
但 `N=s` 时原 §7.1 的上界为 `10^(g-k-1)=10`，不是 `1/10`。
更强地，`rho>=10^(g-1)` 且 `b2=10^(m2-1)(1+epsilon Y)` 给出
`T delta>=1/(1+epsilon Y)`，故不能使用旧的小量估计。
这只是旧估计的反例，不是 exact-lift 解。

剩余状态的尺度含义是：

1. denominator-contact 不再小的 near-diagonal corridor；
2. squared-tail amplified region `s>4g`；
3. curvature amplified region `s>2k-2`。

这与 `s=1` 边的 `r~3g` / `r~2k-g` 三尺度分裂完全对应。

---

<a id="joint-surplus-stable-region"></a>

## 10. 任意双 surplus 的统一稳定区（2026-09-06）

**状态：已严格完成。** 这是覆盖无界参数区域的条件空性定理，
不是 A1 全局空性，也不依赖有限枚举。

依赖仅为 [top-layer.md](top-layer.md) 中 §5 的 coprime-residue
kernel、§7 的严格 half-gap shell 与 §8 的 positive-excess decomposition。
本节重新给出所用恒等式和全部误差界。

### 10.1 命题与新增覆盖

考虑 A1 的最高层 `d=s1-g=2`，令
\[
g,k,r,s\in\mathbf Z_{\ge1},\qquad
m_1=2k+r,\quad m_2=k-g+s\ge1,
\qquad N=\max(r+g+1,s).
\]
若
\[
\boxed{
k+s\ge2g+2,\qquad k+r\ge g+1,\qquad
N\le4g,\qquad N\le2k-1,
}
\tag{JS1}
\]
则不存在这样的 exact-lift 候选。

这同时允许 `r>=2,s>=2`。例如对每个 `g>=1,k>=2g+1`，整个矩形
\[
\boxed{1\le r\le3g-1,\qquad1\le s\le4g}
\tag{JS2}
\]
均为空：此时四条 (JS1) 自动成立。特别地
`g=1,k>=3,r=2,2<=s<=4` 已超出此前分别处理 `r=1` 或 `s=1` 的边界。
这里没有限制 `k` 或 `g` 的绝对上界。

### 10.2 精确的 joint integer

沿用端点整数
\[
\begin{aligned}
b_1&=10^{2k+r}-w,&a_1&=10^{2k+r+g+1}+x,\\
b_2&=10^{k-g+s-1}+y,&a_2&=10^{2k+s}-z,
\end{aligned}
\]
其中 `w,z>=1,x,y>=0`。记
\[
\begin{gathered}
\varepsilon=10^{-2k},\quad H=10^g,\quad t=10^{-r-1},\\
U_1=x+10^{g+1}w,\quad U_2=z+10^{k+g+1}y,\\
A=U_1/10^{r+g+1},\quad B=U_2/10^s,\\
W=w/10^r,\quad Y=10^{k+g+1-s}y,\\
p=A/(1-\varepsilon W),\quad q=B/(1+\varepsilon Y).
\end{gathered}
\]
half-gap shell 给出
\[
\tfrac12<p+q<267/500,
\quad 0<W<p<0.534,\quad 0<q<0.534.
\tag{JS3}
\]
由于 `Y<=B=q(1+epsilon Y)`，且 (JS1) 强迫 `k>=2`，有
\[
0\le Y<0.535,\qquad 0<\varepsilon\le10^{-4},\qquad0<t\le1/100.
\tag{JS4}
\]
定义
\[
\boxed{
\mathcal K=10^N\left(A+B-\frac12-t+\frac tH\right)\in\mathbf Z,
\qquad T=10^{N-r-1}.
}
\tag{JS5}
\]
整数性来自 `N>=r+g+1` 和 `N>=s`；具体为
\[
\mathcal K=10^{N-r-g-1}(U_1+1)+10^{N-s}U_2
-10^N/2-10^{N-r-1}.
\]

### 10.3 从原 contact 恒等式估计主项

记 `rho=b3/10^n3`，所以
\[
H/10\le\rho<H,\qquad \rho r_3=a_3/10^{n_3}<1.
\]
令
\[
M=10^{k+g+1},\quad \widehat R=\mathcal R/M,\quad
\zeta=r_3/M,\quad \psi=10^{g-1}r_3\in(0,1),
\]
以及
\[
\lambda=b_2/Q,\quad\theta=\rho/(HQ),\quad
\delta=\theta/\lambda=\rho/(Hb_2).
\]
由 (JS1) 的第一条，
\[
0<\delta<10^{g-k-s+1}\le10^{-g-1}\le1/100.
\tag{JS6}
\]
carrier 和球面给 `1-epsilon q<Rhat<1+epsilon p`。此外
\[
\delta\zeta<\frac1{Hb_2M}
\le\varepsilon10^{-g-s}<\varepsilon/H.
\tag{JS7}
\]
定义
\[
\Lambda=\frac{\lambda}{t\varepsilon}
=\frac{1+\varepsilon Y}{1-\varepsilon W+t\varepsilon(1+\varepsilon Y)},
\quad F=\frac{1+\varepsilon p+\widehat R}{2},
\]
\[
\mathcal B=(1+\varepsilon p)-H^{-1}(1-\varepsilon q)
+\delta(\widehat R-\zeta),\qquad B_0=1-H^{-1}+\delta.
\]
则原 contact contribution **精确**为
\[
S_{\rm contact}=2t\Lambda\mathcal B F.
\tag{JS8}
\]
由 (JS3)--(JS7)，
\[
|\Lambda-1|<1.1\varepsilon,\quad
|F-1|<0.534\varepsilon,\quad
|\mathcal B-B_0|<0.7\varepsilon,\quad0<B_0<1.01.
\]
第三个界可直接由
`0.534(1+0.1+0.01)+0.1=0.69274<0.7` 得到。
对第一个界，分子差除以 `epsilon` 的绝对值不超过
`0.535+0.534+0.01(1+10^-4*0.535)`，分母大于
`1-10^-4*0.534`，商小于 `1.1`。
望远镜展开乘积，得到安全的统一界
\[
\boxed{|\Lambda\mathcal B F-B_0|<4\varepsilon.}
\tag{JS9}
\]
例如除以 `epsilon` 后的上界是
\[
1.1(1.01+0.7\cdot10^{-4})(1+0.534\cdot10^{-4})
+0.7(1+0.534\cdot10^{-4})+1.01\cdot0.534<4.
\]

### 10.4 两个主相位之外的余量严格为正

原 positive-excess 恒等式为
\[
2(p+q)-1=S_{\rm contact}+S_{\rm rad}
+\varepsilon f+\varepsilon^2p^2,
\quad f=2p+q^2-p^2,
\]
其中
\[
S_{\rm rad}=\zeta^2/\varepsilon=10^{-4g}\psi^2.
\]
又 `A+B=p+q+epsilon(Yq-Wp)`。代入 (JS5) 得精确恒等式
\[
\boxed{
\begin{aligned}
\mathcal E
&:=\mathcal K-T\delta-\tfrac12 10^{N-4g}\psi^2\\
&=10^N\left[t(\Lambda\mathcal B F-B_0)
+\varepsilon\left(\frac f2+Yq-Wp\right)
+\frac{\varepsilon^2p^2}{2}\right].
\end{aligned}}
\tag{JS10}
\]
这是一次代入，不把各项当成独立方程。

由 (JS3) 有
\[
2p+q^2-3p^2>0.21.
\]
证明分为：`p>=1/2` 时 `2p-3p^2>0.212532`；`p<1/2` 时
`q>1/2-p`，故左侧大于 `1/4+p-2p^2>=1/4`。
再由 `W<p,Yq>=0`，得
\[
f/2+Yq-Wp>0.105.
\]
因此 (JS9) 中可能为负的项至多消耗 `4t<=0.04`，从而
\[
\mathcal E>\frac{13}{200}10^N\varepsilon>0.
\]
上界则丢掉 `-Wp` 与 `-p^2/2`，得到
\[
\frac{\mathcal E}{10^N\varepsilon}
<0.04+0.534+0.534^2/2+0.535\cdot0.534
+10^{-4}\cdot0.534^2/2<2.
\]
所以
\[
\boxed{
0<\mathcal K-T\delta-\tfrac12 10^{N-4g}\psi^2
<2\cdot10^{N-2k}.
}
\tag{JS11}
\]
在 `k>=2,k+s>=2g+2` 下，(JS11) 本身就成立；后两条稳定性条件
只在下一步将各项压到单位以下时使用。

### 10.5 完成整数矛盾

不分支地写 contact 上界：
\[
T\delta<10^{N-r-k+g-s}.
\]
由于 `N=max(r+g+1,s)`，指数恰为
\[
\max(2g+1-k-s,\ g-r-k).
\]
故 (JS1) 的前两条 **同时**保证 `0<T delta<1/10`。
这也准确定位了旧 `r=1` 证明漏掉的条件。
另两条给
\[
\tfrac12 10^{N-4g}\psi^2<\tfrac12,\qquad
2\cdot10^{N-2k}\le\tfrac15.
\]
于是 (JS11) 强迫
\[
\boxed{0<\mathcal K<\tfrac1{10}+\tfrac12+\tfrac15=\tfrac45<1,}
\]
与 (JS5) 的整数性矛盾。证毕。

### 10.6 剩余范围与验证

任何 `d=2,g>=1` 候选必须违反 (JS1) 至少一条。尤其 `k>=2g+1`
时必须有
\[
\boxed{r\ge3g\quad\text{或}\quad s\ge4g+1.}
\]
这里完整保留了两个 surplus 都可增长的内部区域；没有把最高层、
`g=0` 或其余 `d=-1,0,1` 宣布为空。新的目标应是 (JS11) 中被放大的
contact/radius 项能否与真实第三块的十进制恢复兼容。

核对命令：
```bash
uv run python scripts/exact-lift/a1-only/research-checks/top-layer/check_a1_joint_surplus_stable_region.py
```
脚本检查精确代数、全部统一有理常数，并在明确有限的位数网格核对
区域蕴含及漏条件示例；无界覆盖来自上面的证明，不来自网格枚举。
2026-09-06 运行通过：符号恒等式为零，contact 误差系数小于 `4`、
余量系数小于 `2`；`1<=g,k,r,s<=24` 网格中 69,417 个稳定参数元组
通过区域蕴含核对，其中 63,947 个有 `r,s>=2`。这些计数不是解的枚举。

### 10.7 首个放大壳层只剩五个 radius 窗口

**状态：已严格完成（必要条件，不是空性）。** 在
\[
k\ge2g+2,\qquad N=\max(r+g+1,s)=4g+1
\]
下，(JS11) 仍然成立，而且
\[
T\delta<1/100,\qquad
\mathcal E<2\cdot10^{N-2k}\le1/500.
\]
因此
\[
\boxed{
\mathcal K\in\{1,2,3,4,5\},\qquad
0<\mathcal K-5\psi^2<3/250,
}
\tag{JS12}
\]
即
\[
\frac{\mathcal K}{5}-\frac3{1250}<\psi^2<\frac{\mathcal K}{5}.
\]
证明只需将 `N=4g+1` 代入 (JS11)：contact 指数不超过 `-2`，
curvature 指数不超过 `-3`，再由 `0<psi<1` 与 `K` 的整数性收束。

这给出了一个具体的新接口：首个未关闭的 squared-tail 壳层不是任意
相位，而是上述五个固定窗口，且 `psi=10^(g-1)a3/b3` 必须来自真实既约
第三块。仍须把窗口与 exact decimal recovery 联立；仅有五个窗口不构成矛盾。


<a id="joint-surplus-curvature-wall-extension"></a>

### 10.8 真实第三块耦合把 curvature 稳定墙推进一格（2026-09-30）

**状态：已严格完成。** 本节严格扩大 (JS1) 的无界区域；仍只处理
`d=2,g>=1,r,s>=1`。依赖为 §10.2--10.4 的精确恒等式与误差界，
以及真实第三块的 `eta=a3/10^n3<1`、`rho>=10^(g-1)`。

现在只须
\[
\boxed{
k+s\ge2g+2,\qquad k+r\ge g+1,\qquad
N\le4g,\qquad N\le2k
}
\tag{JS13}
\]
就已经没有候选。这里最后一条比 (JS1) 放宽一格。
例如 `(g,k,r,s)=(1,2,2,2)` 满足 (JS13)，却不满足 (JS1)；
该例只是新增覆盖区域的参数，不是候选解。

#### 联合 half-gap 约束收紧余量

写 `C=267/500`、`e0=1/10000` 以及
\[
c_0:=\frac12+\frac1{1-e_0C}.
\]
由 `p+q<C` 与 `Y<=q/(1-epsilon q)`，
\[
\begin{aligned}
\frac f2+Yq-Wp+\frac{\varepsilon p^2}{2}
&<p-\frac{p^2}{2}+c_0q^2+\frac{e_0C^2}{2}\\
&\le p-\frac{p^2}{2}+c_0(C-p)^2+\frac{e_0C^2}{2}.
\end{aligned}
\]
右侧除最后常数外是 `p in [0,C]` 上的凸二次式，因为二次系数
`c0-1/2>0`。因此其最大值在两个端点之一：
\[
\max\left(c_0C^2,\ C-\frac{C^2}{2}\right).
\]
合并 (JS9) 的 `4t<=1/25`，全部有理常数满足
\[
\frac1{25}+\max\left(c_0C^2,\ C-\frac{C^2}{2}\right)
+\frac{e_0C^2}{2}<\frac{47}{100}.
\]
这一步使用 `p+q<C` 的联合约束；不能同时把 `p` 与 `q` 取为 `C`。
(JS10) 的正下界保持不变，故有更强的统一余量：
\[
\boxed{
0<\mathcal E<\frac{47}{100}10^{N-2k}.
}
\tag{JS14}
\]
此式在 `k>=2,k+s>=2g+2` 时已成立，不需要 (JS13) 的后两条。

#### contact 和 radius 来自同一个第三块

记
\[
u:=\rho/H\in[1/10,1),\qquad \eta:=a_3/10^{n_3}\in[1/10,1).
\]
真实尾部满足
\[
\boxed{\psi=\frac\eta{10u}<\frac1{10u}.}
\]
令 `E=max(2g+1-k-s,g-r-k)`。§10.5 的 contact 估计保留
`rho/H` 后实际上是
\[
T\delta\le u10^E\le\frac u{10},
\]
第一处允许等号是因为 `b2>=10^(k-g+s-1)`；不需要假设 `y>0`。
(JS13) 另给 radius 项不超过 `psi^2/2`。
于是两项不能同时独立地逼近 `1/10` 与 `1/2`，而是
\[
T\delta+\tfrac12 10^{N-4g}\psi^2
<\frac u{10}+\frac1{200u^2}\le\frac{51}{100}.
\tag{JS15}
\]
最后一个界对整个 `u in [1/10,1]` 直接由因式分解验证：
\[
\frac{51}{100}-\frac u{10}-\frac1{200u^2}
=\frac{(10u-1)(-2u^2+10u+1)}{200u^2}\ge0.
\]
后一因子在该区间严格正；前一个严格小于号来自 `eta<1`。

#### 整数矛盾与新边界

(JS13) 的 `N<=2k` 与 (JS14)--(JS15) 最终给
\[
\boxed{0<\mathcal K<\frac{51}{100}+\frac{47}{100}
=\frac{49}{50}<1.}
\]
与 (JS5) 矛盾，证明 (JS13)。

因此整个无界矩形现在扩大为
\[
\boxed{k\ge2g,\qquad 1\le r\le3g-1,\qquad 2\le s\le4g}
\tag{JS16}
\]
为空；在 `k>=2g+1` 时仍允许 `s=1`。这是实际扩大了关闭范围，
没有关闭 `N>4g` 的 amplified-radius 区，也没有处理全部近接触区域。
对于首个 radius 壳层 (JS12)，(JS14) 还把误差收紧为
\[
\boxed{0<\mathcal K-5\psi^2<\frac{1047}{100000}}
\qquad(k\ge2g+2,\ N=4g+1),
\]
仍是必要条件，不能据此声称该壳层为空。

核对使用同一个脚本：
```bash
UV_CACHE_DIR=/tmp/codex-math-uv-cache uv run --offline python scripts/exact-lift/a1-only/research-checks/top-layer/check_a1_joint_surplus_stable_region.py
```
脚本以精确有理数检查凸二次式的端点界和 (JS15) 的因式分解，
并只把有限位数网格用作区域回归核对。无界结论来自上面的推导。


<a id="joint-surplus-first-radius-shell-upper-tail-collapse"></a>

### 10.9 首个 radius 壳层的 upper-significand 子支关闭（2026-09-30）

**状态：已严格完成（条件空性及剩余走廊）。** 本节只考虑
\[
k\ge2g+2,\qquad N=4g+1,\qquad g\ge1.
\]
依赖 §10.7--10.8。令 `u=rho/H`、`eta=a3/10^n3`，则
\[
\mathcal K\in\{1,2,3,4,5\},\qquad
T\delta\le\frac u{100},\qquad
0<\mathcal E<\frac{47}{100000},\qquad
\psi=\frac\eta{10u}.
\]
所以对真实第三块有严格必要不等式
\[
\boxed{
\mathcal K
<\frac u{100}+\frac1{20u^2}+\frac{47}{100000}.
}
\tag{JS17}
\]

右边是 `u>0` 上的凸函数。在 `[c,1]` 上只须检查两个端点。
取 `c=28/125`，其两端精确上界为
\[
\frac{9792183}{9800000}<1,\qquad
\frac{6047}{100000}<1.
\]
故 (JS17) 与 `K>=1` 矛盾，得到整个子支
\[
\boxed{k\ge2g+2,\ N=4g+1,\ \rho/H\ge28/125
\Longrightarrow\varnothing.}
\tag{JS18}
\]
这覆盖无界 `g,k,r,s,n3`，不依赖有限枚举。

按 `K` 分别对同一个凸函数检查端点，还得到如下严格剩余走廊：

| `K` | 候选必需的 `u=rho/H` 上界 |
|---:|---:|
| 1 | `u<28/125` |
| 2 | `u<791/5000` |
| 3 | `u<323/2500` |
| 4 | `u<1119/10000` |
| 5 | `u<20003/200000` |

每行的有理端点代入 (JS17) 右侧严格小于相应的 `K`；
另一端 `u=1` 的值始终为 `6047/100000<K`。各行并非完整空性，
因为真实尾窗只要求 `u>=1/10`，仍与这些上界相交。

此外精确 `K=T delta+5psi^2+E` 给出
\[
\boxed{
20u^2\left(K-\frac u{100}-\frac{47}{100000}\right)
<\eta^2<20Ku^2.
}
\tag{JS19}
\]
例如 `K=5` 时，左边作为 `u in [1/10,1]` 的函数严格递增：
其导数为
`40u(5-47/100000)-(3/5)u^2>0`。
取 `u=1/10` 得
\[
\eta^2>\frac{499853}{500000}
>\left(\frac{99985}{100000}\right)^2.
\]
因此这个最末窗口已压为
\[
\boxed{
\frac1{10}\le u<\frac{20003}{200000},\qquad
\frac{99985}{100000}<\eta<1,\qquad n_3\ge4.
}
\tag{JS20}
\]
`n3>=4` 来自 `n3<=3` 时 `a3/10^n3<=999/1000`，而不是高度猜测。
这里没有尾长上界；(JS20) 仍是无界 endpoint corridor，不能声称
`K=5` 或首个 radius 壳层全部关闭。

核对命令与 §10.8 相同；脚本逐一以精确有理数验证端点、
`K=5` 的导数下界及 `eta` 的平方比较。有限位数网格仍仅是回归核对。


#### 必要 phase 系统的兼容点：不能只靠窗口完成关闭

**状态：失效/降级（仅用 phase 窗口加尾既约性关闭的路线不足）。**
取 `g=1,k=4,r=3,s=1,N=5,K=1`，真实既约第三块
\[
(a_3,b_3)=(5591,12511),\qquad
n_3=4,\quad m_3=5,
\]
给出 `u=12511/100000`、`eta=5591/10000`、`psi=5591/12511`。
`s=1` 的真实第二块可取 `b2=1000`，此时 `T delta=u/100`。
精确有理数核对满足
\[
\frac{13}{200000}
<1-\frac u{100}-5\psi^2
<\frac{47}{100000}.
\]
故连 §10.4 的严格余量下界、§10.8 的上界、真实尾位数及既约性
一起也不能排除这个 phase 兼容点。

还可取 `w=287,z=1,U1=40010,x=11310`，得到既约前两块
\[
(a_1,b_1)=(10^{13}+11310,10^{11}-287),\qquad
(a_2,b_2)=(10^9-1,1000),
\]
它们有正确的位数层和联合整数 `K=1`。
**这不是 exact-lift 解**：其拼接比值的平方严格不等于三个比值平方和，
脚本对此作精确分数核对。该点只用于表明尚缺的 full contact/sphere
等式不可被当前窄 phase 不等式替代。下一步必须把 (JS10) 的精确余量
与实际前两块联立，或增加独立的 denominator/decimal-recovery obstruction。


<a id="joint-surplus-first-contact-wall-collapse"></a>

### 10.10 首个 contact 放大边界：endpoint 归约与剩余系统

本节的统一假设为 `k+r=g,k+s>=2g+2,N<=2k`。
它自动给 `g>=3r+2,k>=4,N=s`；记 `nu=s-r-1`。
当前严格结果先关闭 `u<=529/1000`，余核必须 `u>529/1000`、
`y=0,K=1,z=1 mod10`。以下表格区分已排除区与必须继续恢复的系统。

| 深度分支 | 当前有效归约 | 仍须恢复的条件 |
| --- | --- | --- |
| 全部候选 | `nu+1<=v5(b3)<=nu+m3`，`max(v2(w),nu)<v2(b3)<nu+m3` | (JS24)--(JS29)、(JS35) 与原 word/sphere |
| `(2S):v2(w)<nu`；非 `2-near-beta`、非 `5-beta` | 仅 `d2,d5<=g,max(d2,d5)=g`，相对 gap 为 (JS34) | 精确 balanced cancellation 与整数恢复 |
| `(2S)`、`5-beta:d5=m3` | `13<=g<26r+6,g<d2<11g/6,m3=3d2-1` | (JS38)--(JS40) 的三项 cancellation；相对盒内未枚举 |
| `(2S)`、`2-near-beta:d2=m3-1` | `5-low:g<=24r-4`；`5-balanced:g<=24r+4`；`5-high:d5<6g` | (JS41)--(JS42) 的真实加法 word、prefix divisor 和 sphere |
| `v2(w)>=nu` | `r>=13`，并满足真实 `2^(g+1)<(267/500)10^r` | (JS35)--(JS37) 的三分裂；不沿用 (2S) 的 regular 排除 |
| `v2(w)=nu,d2=d5=d<g` | `1<=g-d<=3r` | (JS43) 的整数 gap；该相对 gap 内仍待证 |

这里 `d2=v2(b3)-nu,d5=v5(b3)-nu`。`5-beta` 的 `H_sph+y3` 深度
以及 `2-near-beta` 的 `v2(H_sph-y3)=1` 都由精确恒等式决定，
不能只凭模二同余选择符号。下面先保留简单区间证明作为中间步骤，再给加强范围、
完整 endpoint 方程和各条深度推导。

**状态：已严格完成。** 本节不要求 (JS13) 的 `k+r>=g+1`，
而覆盖此前稳定区之外的 `k+r=g` 接触边界。命题范围为
\[
\boxed{
\begin{gathered}
d=2,\quad g,k,r,s\ge1,\quad k\ge2,\quad k+r=g,\\
k+s\ge2g+2,\qquad
N=\max(r+g+1,s)\le\min(4g,2k),\\
\frac19\le u:=\rho/H\le\frac12.
\end{gathered}}
\tag{JS21}
\]
这些条件下不存在 exact-lift 候选。

依赖审计：§10.2--10.4 的整数构造、contact 误差与正余量下界，
以及 §10.8 的 (JS14)，只使用 `k>=2,k+s>=2g+2`。
原 `k+r>=g+1` 仅用于 §10.5 将 `T delta` 压到 `1/10` 以下，
因此本节可用新的 `T delta<=u` 上界替代；不是把旧定理的假设静默删去。
`m2=k-g+s=s-r>=1` 也由 `k+s>=2g+2` 自动保证。

在 (JS21) 下 contact 指数为
\[
E=\max(2g+1-k-s,g-r-k)=0,
\]
故 `T delta<=u`。仍由真实第三块的 `psi=eta/(10u)` 与 `eta<1`，
\[
T\delta+\tfrac12 10^{N-4g}\psi^2
<u+\frac1{200u^2}.
\]
这个凸函数在 `[1/9,1/2]` 上的最大值出现在端点，且
\[
\frac19+\frac{81}{200}=\frac{929}{1800}<\frac{13}{25},
\qquad
\frac12+\frac1{50}=\frac{13}{25}.
\]
因此结合 (JS14) 的 `N<=2k`，
\[
\boxed{0<\mathcal K<\frac{13}{25}+\frac{47}{100}
=\frac{99}{100}<1.}
\]
整数矛盾证明 (JS21)。

这确实覆盖非空的无界参数形状：对任意整数
\[
\boxed{
r\ge1,\qquad g\ge3r+2,\qquad k=g-r,\qquad
 g+r+2\le s\le2g-2r,
}
\tag{JS22}
\]
以及 `1/9<=rho/H<=1/2`，全部为空。
因为此时 `N=s`、`k+s>=2g+2`、`N<=2k<4g` 且 `k>=2`。
例如每个 `r>=1` 都可取 `g=3r+2,k=2r+2,s=4r+4`；
其 `k+r=g` 违反此前稳定区假设，故是新增覆盖。

contact 边界的 `u<1/9` 与 `u>1/2`、更深的 `k+r<g`，
以及其他 amplified source 区仍为 **待证**。
验证脚本用精确有理数检查两个端点和 `99/100` 的整数预算，
并在有限位数网格回归核对 (JS22) 的范围蕴含；无界覆盖来自本节证明。


#### 同一 contact 边界的范围蕴含给出更强关闭

上述位数条件之间还有额外耦合，故 (JS21) 的 `u` 范围并非最终界。
由 `k=g-r` 与 `k+s>=2g+2`，
\[
s\ge g+r+2>r+g+1,
\]
因此 `N=s`。再由 `N<=2k=2g-2r`，得到
\[
\boxed{g\ge3r+2,\qquad g+r\ge6,\qquad
N-4g\le-2(g+r)\le-12.}
\]
所以真实 radius 项实际上严格小于 `1/(2*10^12)`，不需要用
`1/(200u^2)` 的粗上界。

于是完整命题可加强为
\[
\boxed{
\begin{gathered}
d=2,\quad g,k,r,s\ge1,\quad k+r=g,\\
k+s\ge2g+2,\qquad N\le2k,\qquad
\frac1{10}\le\rho/H\le\frac{529}{1000}
\end{gathered}
\Longrightarrow\varnothing.
}
\tag{JS23}
\]
`k>=2` 与 `N<=4g` 都已由这些条件自动推出。
(JS14) 与 `T delta<=u` 给
\[
0<\mathcal K
<\frac{529}{1000}+\frac{47}{100}+\frac1{2\cdot10^{12}}<1,
\]
证明 (JS23)。

因此 (JS22) 所给无界参数族在整个 `1/10<=rho/H<=529/1000`
范围已经关闭，包含原 (JS21) 未覆盖的 `u<1/9`。
首个 contact 边界只需继续研究 `rho/H>529/1000` 或 `N>2k`；
更深 contact 放大区 `k+r<g` 仍待证。


#### 剩余 contact 边界已经是一个精确 endpoint corridor

**状态：已严格完成（必要条件）。** 仍只考虑 `k+r=g`、
`k+s>=2g+2`、`N<=2k`。上面的范围蕴含给
\[
N=s\le2g-2r\le k+g.
\]
因此 [top-layer.md](top-layer.md) §4 的短第二 surplus endpoint kernel
强迫 `y=0`，从而
\[
b_2=10^{k-g+s-1}=10^{s-r-1}=T,\qquad Y=0,
\qquad \boxed{T\delta=u.}
\]
这次 contact phase 并非仅有上界，而是精确等于 `rho/H`。
由 `0<u<1`、radius `<1/(2*10^12)` 与 (JS14)，
\[
0<K<1+\frac{47}{100}+\frac1{2\cdot10^{12}}<2,
\]
故整数 `K=1`。因此整个剩余系统必须满足
\[
\boxed{
K=1,\qquad
0<1-u-\tfrac12 10^{N-4g}\psi^2
<\frac{47}{100}10^{N-2k}.
}
\tag{JS24}
\]
特别地
\[
u>1-\frac{47}{100}10^{N-2k}-\frac1{2\cdot10^{12}}.
\]
当 `N<2k` 时，第三分母 significand 更贴近上端点。

联合整数式还给出一个独立的十进制尾数条件。由于
`s-r-g-1>=1`，(JS5) 中除 `U2=z` 外的每项都是 `10` 的倍数，故
\[
\boxed{z\equiv K\equiv1\pmod{10}.}
\]
这没有造成矛盾；应把 `K=1`、`Y=0`、(JS24) 和真实既约第三块
一起送入精确恢复。该 endpoint corridor 仍为 **待证**。


#### 公共模 9 条件不能自动关闭这个 endpoint corridor

**状态：已严格完成（局部过滤和不充分性审计）；完整空性仍待证。**
本段接入 [global-framework.md](../../global-framework.md#denominator-common-mod9)
的公共分母模 `9` 必要条件，不把该条件当作充分条件。

在 `y=0` 下 `b2=10^(s-r-1)=1 mod9`。若 `w=0 mod3`，则
`b1=1 mod3`。此时：

- 若 `3|b3`，原既约性使第三比值成为唯一具有负 `3`-adic 赋值的比值，
  球面强迫拼接分母被 `3` 整除；但 `beta=b1+b2+b3=2 mod3`，矛盾。
- 若 `b3=1 mod3`，公共模 `9` 条件要求
  `(1-w)^2+1+b3^2=0 mod9`，等价于
  \[
  \boxed{b_3\equiv w+4\pmod9.}
  \]
  `w=0,3,6 mod9` 分别只留下 `b3=4,7,1 mod9`。

从联合整数 `K=1` 另有
\[
z\equiv6-x-w\pmod9,\qquad
 a_1\equiv1+x,\quad a_2\equiv x+w+4\pmod9.
\]
因此在 `w=0 mod3` 时 `a1=a2 mod3`；这是新的联立条件，但不会
使所有模 `9` 或模 `27` 类为空。一个精确核对点为
\[
\begin{gathered}
g=5,\ k=4,\ r=1,\ s=N=8,\ x=0,\ w=3,\ z=20999991,\\
(a_1,b_1)=(10^{15},10^9-3),\quad
(a_2,b_2)=(10^{16}-20999991,10^6),\\
(a_3,b_3)=(1,599974),\quad n_3=1,\quad m_3=6.
\end{gathered}
\]
三块均既约，有联合整数 `K=1`，且 `u=599974/10^6>529/1000`。
它满足 (JS24) 的正余量上下界。分母模 `9` 类为 `(7,1,7)`，通过
公共模 `9` 条件；拼接比值在约去公共 `3` 因子后以及三个比值的
模 `27` 类分别为
\[
R\equiv0,\qquad (r_1,r_2,r_3)\equiv(13,25,4)\pmod{27},
\]
并有 `13^2+25^2+4^2=0 mod27`。
**该点不是 exact-lift 解**：脚本精确核对其完整平方等式非零。
它只证明当时的必要 phase / 位数 / 既约条件连同这一级模 `9/27`
过滤仍有允许类，不能据此把整个 corridor 宣布为空。该点
`v5(b3)=0`；它被下方新增的无界 `5`-深度条件排除，因此不是最新
全部必要条件的允许点。

消去 `z` 后，真正仍须关闭的独立精确方程可以写成
\[
\begin{aligned}
z&=1-10^{s-r-g-1}(x+10^{g+1}w+1)
  +5\cdot10^{s-1}+10^{s-r-1},\\
\alpha&=a_1 10^{2k+s+\ell}+a_2 10^\ell+a_3,\\
\beta&=b_1 10^{s-r+g+\ell}+b_2 10^{g+\ell}+b_3,
\end{aligned}
\]
以及
\[
\boxed{
\alpha^2(b_1b_2b_3)^2
=\beta^2\left[(a_1b_2b_3)^2+(a_2b_1b_3)^2+(a_3b_1b_2)^2\right].
}
\tag{JS25}
\]
这里 `ell=n3`、`k=g-r`，`a1,b1,a2,b2` 仍按原 endpoint 形状恢复，
还须同时保持各块的位数、正性、既约性和 (JS24)。
(JS25) 不可用较宽 phase 不等式代替；模 `9/27` 的局部允许类也不证明
(JS25) 在有理数上存在解。


<a id="joint-surplus-contact-endpoint-5adic-depth"></a>

#### 5-adic 深度的两个无界子支关闭（2026-09-30）

**状态：已严格完成（条件空性及高深度剩余范围）。**
仍只考虑 `k+r=g,k+s>=2g+2,N<=2k` 的首 contact endpoint。
为避免与第三尾长 `ell=n3` 混淆，第二分母的指数记为
\[
\nu:=s-r-1,\qquad b_2=10^\nu,\qquad
\nu\ge g+1\ge3r+3.
\]
任意完整候选必须满足
\[
\boxed{\nu+1\le e_3:=v_5(b_3)\le\nu+m_3.}
\tag{JS26}
\]
特别地，整个 `v5(b3)<=nu` 的无界子支已关闭；这没有关闭全部高深度尾部。

先证明第一分母更浅。由 `W<p<267/500`，
\[
1\le w<10^r<5^{3r+3}.
\]
最后一个严格界可直接写成 `5^(3r+3)/10^r=125*(25/2)^r>1`。
又 `k=g-r>=2r+2`，所以 `2k+r>=5r+4>3r+3`，故
\[
v_5(w)<3r+3\le\nu,\qquad v_5(w)<2k+r.
\]
对 `b1=10^(2k+r)-w` 使用不同赋值相减，得到
\[
\boxed{v_5(b_1)=v_5(w)<\nu.}
\]
前两分母拼接还精确满足
\[
Q=b_1 10^{s-r}+b_2=b_2(10b_1+1),\qquad v_5(Q)=\nu.
\]

令
\[
q_{\rm lcm}:=\operatorname{lcm}(b_1,b_2,b_3),\qquad
 y_i:=a_iq_{\rm lcm}/b_i\in\mathbf Z,
\]
完整候选的整数球面半径记为
\[
H_{\rm sph}:=q_{\rm lcm}\alpha/\beta\in\mathbf Z_{>0}.
\]
整数性来自 `H_sph^2=sum(y_i^2)`：整数的有理平方根必为整数。
因此同时有
\[
H_{\rm sph}^2=y_1^2+y_2^2+y_3^2,\qquad
\boxed{q_{\rm lcm}\alpha=H_{\rm sph}\beta.}
\]

若 `e3<nu`，则 `v5(q_lcm)=nu`，第二分母是唯一最深分母。
原既约性保证 `y2` 为 `5` 单位，`y1,y3` 被 `5` 整除，故
`H_sph` 为 `5` 单位。但
\[
\beta=Q10^{m_3}+b_3,
\qquad v_5(\beta)=e_3<\nu,
\]
所以 `q_lcm alpha` 的赋值至少为 `nu`，`H_sph beta` 的赋值却为
`e3`，矛盾。这关闭 `e3<nu`。

若 `e3=nu`，则 `b3` 被 `5` 整除，原既约性强迫 `a3` 为 `5` 单位。
由于 `alpha=C10^ell+a3`、`ell>=1`，`alpha` 也是 `5` 单位。
此时 `v5(q_lcm)=v5(beta)=nu`，拼接整数恒等式强迫 `H_sph` 为 `5` 单位。
然而 `y1=0 mod5`，`y2,y3` 都为 `5` 单位；两个非零平方模 `5` 的和
只能属于 `{0,2,3}`，不能等于 `H_sph^2 in {1,4}`。矛盾。
这独立关闭等深的无界子支 `e3=nu`，给出 (JS26) 的严格下界。

最后若 `e3>nu`，第三分母是唯一最深分母，故 `H_sph` 为 `5` 单位。
同时 `alpha` 为 `5` 单位，所以整数拼接恒等式要求
`v5(beta)=v5(q_lcm)=e3`。若 `e3>nu+m3`，则
`v5(beta)=nu+m3<e3`，矛盾。这给出上界 `e3<=nu+m3`。
**上界等号不能删去。** 在 `e3=nu+m3` 时令
\[
B:=b_3/5^{e_3},\qquad
A:=2^{\nu+m_3}(10b_1+1).
\]
二者都是 `5` 单位，`beta/5^e3=A+B`。球面模 `5` 给
`H_sph/y3=+1` 或 `-1`；拼接等式的 `+1` 分支会要求 `A=0 mod5`，
不可能，而 `-1` 分支允许必要条件
\[
\boxed{2B+A\equiv0\pmod5.}
\tag{JS27}
\]
这时 `A+B=-B mod5` 仍为单位，故本轮赋值论证没有关闭该 resonance。

先前的模 `9/27` 允许点 `(a3,b3)=(1,599974)` 有 `v5(b3)=0`，
被 (JS26) 排除。这只说明新 `5`-深度条件严格加强了独立过滤，
不证明高深度尾部为空。最新剩余核心应联立 (JS24)--(JS27)、
各块十进制恢复与完整平方方程 (JS25)。

验证脚本以精确整数检查指数范围、第一分母赋值关系、模 `5` 两单位
平方和的全部 16 个 residue pairs、以及等深上界的 `-1` 允许分支。
无界覆盖来自上述赋值证明，不来自参数枚举。


#### 完整 word 与 sphere 联立的 5-adic gap 形状

**状态：已严格完成（无界必要形状，非全局空性）。**
接续 (JS26)，写 `d5=e3-nu>=1`、`m3=n3+g`。
在非 beta-resonance 区 `e3<nu+m3`（即 `d5<m3`）中，候选必须落入
\[
\boxed{
\begin{array}{c|c}
d_5<g&n_3=2d_5\\
d_5>g&m_3=3d_5\\
d_5=g&n_3\le2g
\end{array}}
\tag{JS28}
\]
每一行以外的对应参数子支已经严格关闭；覆盖无界位数参数。

证明如下。第三分母最深时 `y3,H_sph` 都为 `5` 单位，而
\[
v_5(y_2)=d_5,\qquad v_5(y_1)>d_5.
\]
非 beta-resonance 时 `beta/b3=1 mod5`，并且 `alpha/a3=1 mod5`，
故 `H_sph/y3=1 mod5`。于是 `H_sph+y3` 为单位；球面差平方精确给
\[
\boxed{v_5(H_{\rm sph}-y_3)=2d_5.}
\]
这里右侧平方和中第二坐标更浅，故没有取消。

设 `A12=a1 10^n2+a2`，其为 `5` 单位。完整 word identity 与
`q_lcm a3=y3 b3` 相减得到
\[
\boxed{
(H_{\rm sph}-y_3)\beta
=q_{\rm lcm}A_{12}10^{n_3}-y_3Q10^{m_3}.
}
\tag{WG5}
\]
左端赋值为 `nu+3d5`，右端两项赋值分别为
`nu+d5+n3` 与 `nu+n3+g`。若 `d5<g`，第一项更浅，故
`nu+3d5=nu+d5+n3`，得到 `n3=2d5`；若 `d5>g`，第二项更浅，
故 `nu+3d5=nu+m3`，得到 `m3=3d5`。

若 `d5=g`，右端两项等深，故 `nu+3g>=nu+g+n3`，即 `n3<=2g`。
更精确地，令
\[
C_5:=q_{\rm lcm}/5^{e_3},\qquad Q_5:=Q/5^\nu,
\]
其单位差必须满足
\[
\boxed{
v_5\left(C_5A_{12}2^{n_3}-y_3Q_5 2^{m_3}\right)=2g-n_3.
}
\]
`n3<2g` 时必须有正深度 cancellation；`n3=2g` 时额外深度可以为零。
不能把等深本身当作已经发生非平凡消去。

上界 beta-resonance `e3=nu+m3` 必须单列。由 (JS27) 的负号分支，
`H_sph=-y3 mod5`，因此 `H_sph-y3` 为单位，球面反而给
\[
\boxed{v_5(H_{\rm sph}+y_3)=2m_3.}
\tag{JS29}
\]
对应的精确加法 word identity 是
\[
(H_{\rm sph}+y_3)\beta
=q_{\rm lcm}A_{12}10^{n_3}+y_3Q10^{m_3}+2q_{\rm lcm}a_3.
\]
它有三个项，不能混入 (WG5) 的两项不等深论证。
(JS28)--(JS29) 均保留了真实十进制 word，而不是只使用较宽的 phase 窗口；
各允许形状仍须满足 (JS24)--(JS27) 和完整恢复，尚未证明全部为空。


<a id="joint-surplus-contact-endpoint-2adic-depth"></a>

#### 较浅第一分母的 2-adic 深度与两个跨素数子支关闭

**状态：已严格完成（显式条件下的无界空性）；其他深度仍待证。**
在同一首 contact endpoint 中，还可独立利用 `2`-adic word 与 sphere。
第一分母总满足
\[
v_2(b_1)=v_2(w),
\]
因为 `w<10^r<2^(4r)`、`2k+r>=5r+4>4r`。
本段明确添加条件
\[
\boxed{v_2(w)<\nu.}
\tag{2S}
\]
对 `1<=r<=12`，它由已有位数范围自动保证：
\[
\frac{2^{3r+3}}{10^r}=8(4/5)^r
\ge\frac{2^{39}}{10^{12}}>\frac{267}{500},
\]
故 `w<(267/500)10^r<2^(3r+3)<=2^nu`。
`r>12` 时仍可使用 (2S)，但不能自动假设它成立。

在 (2S) 下，完整候选必须满足
\[
\boxed{\nu+2\le e_{3,2}:=v_2(b_3)<\nu+m_3.}
\tag{JS30}
\]
证明 `e3,2<nu` 的空性与上面的 `5`-adic unique-max 赋值论证相同。
若 `e3,2=nu`，`y1` 为偶数，`y2,y3` 为奇数，其平方和 `=2 mod4`，
不可能是整数平方。若 `e3,2=nu+1`，第三坐标最深，`H_sph,y3` 均奇，
`v2(y2)=1`、`v2(y1)>1`；球面差平方右端赋值恰为 `2`，但两个奇数
平方之差必被 `8` 整除。矛盾。因此 `e3,2>=nu+2`。

此时第三分母是唯一最深者，`H_sph` 与 `alpha` 均奇，整数 word 要求
`v2(beta)=e3,2`。若 `e3,2>nu+m3`，前缀分母项更浅，矛盾；若
`e3,2=nu+m3`，两个相同赋值的奇单位项相加使 `beta` 更深，也矛盾。
这次上界是严格的；它与允许负号 unit resonance 的 `5`-adic 上界不同。

联立 (JS26) 与 (JS30)，`b3` 至少被
`2^(nu+2)5^(nu+1)=20*10^nu` 整除。因此
\[
\boxed{m_3\ge\nu+2,\qquad n_3\ge\nu-g+2\ge3.}
\]
这个真实十进制高度下界在后面的 sign split 中不可遗漏。

令 `d2=e3,2-nu>=2`。因 `v2(y2)=d2<v2(y1)`，球面右端
`y1^2+y2^2` 的赋值恰为 `2d2`。仍使用完整两项 word identity (WG5)，
但这次其左端 `beta` 的赋值为 `nu+d2`；两项比较给：

- 若 `d2<g`，`v2(H_sph-y3)=n3>=3`；于是 `v2(H_sph+y3)=1`，
  得 `n3=2d2-1`。
- 若 `d2=g`，右端两项等深，故 `v2(H_sph-y3)>=n3>=3`；
  同理 `v2(H_sph+y3)=1`，得到 `n3<=2g-1`。
- 若 `d2>g`，`v2(H_sph-y3)=m3-d2>=1`。当 `m3-d2>=2`，
  另一个因子赋值为 `1`，得 `m3=3d2-1`；当 `m3-d2=1`，
  必须单列 near-beta 边界 `d2=m3-1`，此时正因子的赋值为 `2d2-1`。

因此严格必要形状为
\[
\boxed{
\begin{array}{c|c}
d_2<g&n_3=2d_2-1\\
d_2=g&n_3\le2g-1\\
d_2>g&m_3=3d_2-1\ \text{或}\ d_2=m_3-1
\end{array}}
\tag{JS31}
\]

把这与 (JS28) 的独立 `5`-adic 形状联立，立即得到两个无界子支关闭：
\[
\boxed{
\begin{aligned}
d_2<g,\ d_5<g&\Longrightarrow\varnothing,\\
g<d_2\le m_3-2,\quad g<d_5<m_3&\Longrightarrow\varnothing.
\end{aligned}}
\tag{JS32}
\]
第一行同时要求 `n3` 为奇数与偶数；第二行同时要求
`m3=2 mod3` 与 `m3=0 mod3`。证明依赖完整 word、sphere、真实位数
以及 (2S)，不来自有界枚举。

混合高低深度、`d2=g` 或 `d5=g`、`5`-adic beta-resonance `d5=m3`、
`2`-adic near-beta 边界 `d2=m3-1`，以及违反 (2S) 的第一分母深区，
都仍为 **待证**；(JS32) 不能被扩大为整个 contact endpoint 已关闭。


#### Regular 高深度（含 mixed）全部排除

**状态：已严格完成。** 在 (2S) 下，去掉两个须单列的边界
`d2=m3-1` 与 `d5=m3` 后，(JS28)、(JS31) 还能严格加强 (JS32)：
\[
\boxed{
d_2\ne m_3-1,\quad d_5<m_3
\quad\Longrightarrow\quad
 d_2\le g,\quad d_5\le g,\quad\max(d_2,d_5)=g.
}
\tag{JS33}
\]

若 regular `d2>g`，则 `m3=3d2-1>=3g+2`，即 `n3>=2g+2`。
这与 `d5<=g` 的 `n3<=2g` 冲突；而 `d5>g` 已由 regular double-high
的模 `3` 冲突排除。反向若 regular `d5>g`，则 `m3=3d5>3g`、
`n3>2g`，与 `d2<=g` 的 `n3<=2g-1` 冲突，其余再次由 double-high
排除。因此两个深度都不高于 `g`；double-low 又要求至少一侧等于 `g`。

这里 `H_sph-y3` 或 `H_sph+y3` 的赋值完全来自精确 word gap 与
sphere 差平方；没有用模 `2` 同余替代正负因子的实际赋值。
(JS33) 不适用于上面两个不同号边界。

#### Balanced regular 剩余压到有界相对 gap

**状态：已严格完成（条件空性和相对 gap 压缩）。**
仍加 (2S)，并处于 (JS33) 的 regular 部分。则剩余必须满足
\[
\boxed{
\begin{array}{c|c}
d_2=g,\ d_5<g&1\le g-d_5\le3r\\
d_5=g,\ d_2<g&1\le g-d_2\le3r-1\\
d_2=d_5=g&2g-3r\le n_3\le2g-1
\end{array}}
\tag{JS34}
\]
各行上界以外的无界子支已关闭；这些是相对参数界，不是所有前缀的
全局有限盒。

证明使用真实第三分母的十进制格点。令
\[
S:=N-2k=\nu+3r+1-2g\le0,
\]
并把 `u=b3/10^m3` 约为分母
\[
D=2^A5^B,\qquad
 A=(m_3-\nu-d_2)_+,\quad B=(m_3-\nu-d_5)_+.
\]
由于 `0<u<1`，`D(1-u)` 是正整数。若 `D=1`，已立即矛盾；以下
可假设 `D>1`。由 (JS24) 得
\[
0<D(1-u)<\tfrac12D10^{N-4g}\psi^2
+\frac{47}{100}D10^S.
\tag{DB}
\]

若 `d2=g,d5<g`，写 `Delta5=g-d5>=1`，由 `n3=2d5`：
\[
A=(2d_5-\nu)_+,\quad B=(g+d_5-\nu)_+,\quad B\ge A.
\]
于是
\[
S+A=\max(S,3r+1-2\Delta_5),\qquad
S+B=\max(S,3r+1-\Delta_5).
\]
若 `Delta5>=3r+1`，两者都不正，故 `D10^S<=1`。
同时 `B>0`（否则 `D=1`）并且 `D<=10^B`，所以
\[
\tfrac12D10^{N-4g}\psi^2
<\tfrac12 10^{r+1-2g-\Delta_5}
\le\frac1{2\cdot10^9}.
\]
代入 (DB) 得正整数 `<47/100+1/(2*10^9)<1`，矛盾。

若 `d5=g,d2<g`，写 `Delta2=g-d2>=1`，由 `n3=2d2-1`：
\[
A=(g+d_2-1-\nu)_+,\quad B=(2d_2-1-\nu)_+,\quad A\ge B,
\]
\[
S+A=\max(S,3r-\Delta_2),\qquad
S+B=\max(S,3r-2\Delta_2).
\]
若 `Delta2>=3r`，仍有 `D10^S<=1`；`A>0` 且 `D<=10^A` 给 radius
项 `<(1/2)10^(r-2g-Delta2)<=1/(2*10^9)`，同一整数矛盾完成第二行。

若 `d2=d5=g`，则 `D=10^(n3-nu)`，且 `n3>nu`（否则 `D=1`）。
写 `c=2g-n3>=1`，有
\[
D10^S=10^{3r+1-c},\qquad
\tfrac12D10^{N-4g}\psi^2
<\tfrac12 10^{r+1-2g-c}\le\frac1{2\cdot10^9}.
\]
`c>=3r+1` 时再次矛盾，给出第三行。
所有 radius 小量界只用 `g>=3r+2` 与各 gap 至少 `1`，不对 `g` 或
`n3` 设置绝对上界。

最新 regular core 是 (JS34) 三类相对 gap 加上真实 denominator
unit、精确 cancellation、(JS24)--(JS25)。两个不同号边界及不满足
(2S) 的区域仍必须分别处理。


#### 去掉 (2S) 后的第一分母 2-adic 三分裂

**状态：已严格完成（必要形状及子支空性）；不扩大 (JS33)--(JS34) 的范围。**
令 `e1=v2(w)=v2(b1)<4r`。已有范围保证
\[
\nu+m_3\ge(3r+3)+(g+1)\ge6r+6>e_1.
\]
因此 potential first-max beta-resonance `e3,2=nu+m3<=e1` 实际不可能。

完整候选必须满足
\[
\boxed{\max(e_1,\nu)<e_{3,2}<\nu+m_3.}
\tag{JS35}
\]
证明下界需要分开三种第一分母深度：`e1<nu` 已在 (JS30) 中处理。
`e1=nu` 且 `e3,2<=nu` 时，最大分母层有两个或三个奇坐标，球面模
`4` 的平方和分别为 `2` 或 `3`，不可能。`e1>nu,e3,2<e1` 时第一分母
唯一最深，`H_sph` 为奇数，而上面的 arch bound 保证
`v2(beta)=e3,2<e1`，与整数 word 相矛盾；`e3,2=e1` 时第一、第三坐标
同为奇数，又得到模 `4` 的 `2`。上界则和 (JS30) 一样来自第三坐标唯一
最深、`alpha` 为奇数及 beta 等深时两个奇单位相加。

现在写 `t=e1-nu`、`d2=e3,2-nu`，则 `v2(y1)=d2-t`、`v2(y2)=d2`。
球面右端实际赋值是
\[
V:=v_2(y_1^2+y_2^2)=
\begin{cases}
2d_2,&t<0,\\
2d_2+1,&t=0,\\
2(d_2-t),&t>0.
\end{cases}
\]
`t=0` 时两个归一奇数平方的和 `=2 mod4`，所以多出的 `1` 不能遗漏。
`t!=0` 时只有一个更浅坐标，其 gap 至少为 `2`；`t=0` 时 gap 可以为 `1`。
(JS26)、(JS35) 共同保证 `10^(nu+1)|b3`，故仍有真实高度 `n3>=nu-g+2>=3`。

完整两项 word 仍按 `d2` 与 `g` 比较，而球面按上述 `V` 分裂，得到
\[
\boxed{
\begin{array}{c|ccc}
&t<0&t=0&t>0\\ \hline
d_2<g&n_3=2d_2-1&n_3=2d_2&n_3=2(d_2-t)-1\\
d_2=g&n_3\le2g-1&n_3\le2g&n_3\le2(g-t)-1\\
d_2>g,\ d_2\le m_3-2&m_3=3d_2-1&m_3=3d_2&m_3=3d_2-2t-1
\end{array}}
\tag{JS36}
\]
若 `d2=m3-1`，则 `v2(H_sph-y3)=1`、`v2(H_sph+y3)=V-1`，仍单列
near-beta 边界。这些赋值来自实际整数正因子 `H_sph±y3` 与完整 word，
不是从模 `2` 同余臆定正负号。

与独立的 `5`-adic 形状联立，得到无 (2S) 的必要过滤：
\[
\boxed{
\begin{aligned}
d_2<g, d_5<g&\Longrightarrow t=0\ \text{且}\ d_2=d_5,\\
g<d_2\le m_3-2, g<d_5<m_3&\Longrightarrow
\begin{cases}
\varnothing,&t<0,\\
d_2=d_5,&t=0,\\
t\equiv1\pmod3,&t>0.
\end{cases}
\end{aligned}}
\tag{JS37}
\]
第一行在 `t!=0` 时仍因 `n3` 奇偶矛盾而关闭，但 `t=0` 的新 two-coordinate
balanced branch 不能删除。第二行的 `t>0` 来自
`3d2-2t-1=3d5`，只给必要同余；局部允许的 `t=1 mod3` 仍待证。
`e1=nu` 自动要求 `r>=13`，因为 `r<=12` 已证明 `e1<nu`。

#### 5-adic beta-resonance 的精确三项 cancellation 与相对高度

**状态：已严格完成（无界必要条件；高尾子支空性）。**
这段处理 `d5=m3`，不要求 (2S)。仍沿用 (JS27) 的 `A,B`，并令
`C5=q_lcm/5^(nu+m3)`。把正 gap word 除以 `5^(nu+m3)`，利用
`C5 a3=y3 B`，得到精确式
\[
(H_{\rm sph}+y_3)(A+B)
=C_5 A_{12}10^{n_3}+y_3(A+2B).
\]
左端深度为 `2m3`，第一项深度为 `n3<m3`，故必须
\[
\boxed{v_5(A+2B)=n_3,}
\tag{JS38}
\]
并且
\[
v_5\left(C_5A_{12}2^{n_3}
+y_3\frac{A+2B}{5^{n_3}}\right)=2m_3-n_3.
\]
这是比 (JS27) 的单层 unit congruence 更强的精确 cancellation。

真实位数给 `B<2^m3/5^nu`，而
`10b1+1<10^(2g)`、`nu<=2g-4`，故
\[
A+2B
<2^{m_3}\left(2^\nu10^{2g}+2/5^\nu\right)
<2^{m_3}400^g.
\]
由 (JS38) 的 `5^n3<=A+2B` 与 `n3=m3-g`，
\[
(5/2)^{m_3}<2000^g.
\]
因为 `(5/2)^9>2000`，得到完整的无界条件空性
\[
\boxed{d_5=m_3\Longrightarrow m_3<9g.}
\tag{JS39}
\]
`m3>=9g` 的整个 beta-resonance 高尾子支已关闭，`m3<9g` 仍是相对
高度范围；`g` 可无界增长，不能称为全局有限盒。

(JS38) 还要求
\[
B\equiv-2^{\nu+m_3-1}(10b_1+1)\pmod{5^{n_3}}.
\]
`nu>=g+1` 保证 `2^m3/5^nu<5^n3`，故每个固定前缀与固定 `m3` 的
允许区间中至多一个整数 `B`。这只是精确恢复的候选压缩，仍须联立
完整 sphere、既约性和另一素数的真实深度。

在 (2S) 下，5-beta 也不能与 2-near-beta `d2=m3-1` 同时出现，因为
真实分母质量要求 `10^nu<2^(m3-d2)=2`。若 `d2<=g`，2-word 形状给
`m3-d2<=2g-1`，但 `2^(2g-1)<10^(g+1)<=10^nu`，同样矛盾。
因此 (2S) 内若 5-beta 仍存，只能搭配 regular 2-high
`d2>g,m3=3d2-1`，并满足精确质量条件
\[
\boxed{2^{2d_2-1}>10^\nu.}
\]
该搭配还要遵守 (JS38)--(JS39)；本轮没有把它宣称为空。


#### (2S) 内 5-beta 的跨素数高度与 `g/r` 相对界

**状态：已严格完成（无界子支空性及相对盒）；有限盒内未枚举解。**
本段重新添加 (2S)，不能把结论扩到首分母的新增 balanced/deep 分支。
5-beta 只剩 regular 2-high，故 `m3=3d2-1,d2>g`。
(JS38) 中 `A` 的 `2` 深度为 `nu+m3`，`2B` 的 `2` 深度为
`nu+d2+1`；后者严格更浅。因此
\[
v_2(A+2B)=\nu+d_2+1,\qquad v_5(A+2B)=n_3.
\]
而 `10b1+1<=10^(2g)-9`，`2B/2^(nu+m3)<2/10^nu<9`，给出更紧
的真实 arch bound `A+2B<2^(nu+m3)10^(2g)`。所以
\[
\boxed{5^{3d_2-g-1}<2^{2d_2-2}10^{2g}.}
\tag{BP}
\]
这首先排除 `d2>=2g`；在 `d2=2g` 时左/右比为
`(4/5)(125/64)^g>1`，且该比随 `d2` 严格增加。

还可统一加强为
\[
\boxed{g<d_2<11g/6.}
\tag{BH}
\]
在 `d2=11g/6` 时左/右比为 `(4/5)(5^(5/2)/2^(17/3))^g`。
其底数大于 `1`（`5^15>2^34`），`g>=5` 的最小端点比也大于 `1`，
把 `g=5` 端点比提升到六次方正是 `5^69/2^158>1`。
这给出全部无界 `g` 的阈值证明，不来自枚举。

接回真实分母质量。令 `alpha_2=log10(2)`，则
\[
\nu<\alpha_2(2d_2-1),\qquad
\frac3{10}<\alpha_2<\frac{151}{500}.
\]
两个有理常数界分别由 `2^10>10^3`、`2^500<10^151` 精确验证。
结合 (BH) 与 `nu>=g+1` 得 `g>1953/161`，所以 **`g>=13`**。

这里 `u=b3/10^m3` 的既约分母为
\[
D=2^{2d_2-1-\nu};
\]
指数为正，另一素数已在分子中。写 `S=nu+3r+1-2g`，并令
\[
C:=\frac{11}{3}\frac{151}{500}\left(2-\frac{151}{500}\right)
=\frac{470063}{250000}<2.
\]
用严格质量界以及 (BH)，
\[
\begin{aligned}
\log_{10}(D10^S)
&=2\alpha_2d_2+(1-\alpha_2)\nu+3r+1-\alpha_2-2g\\
&<2\alpha_2(2-\alpha_2)d_2+3r+(1-\alpha_2)^2-2g\\
&<(C-2)g+3r+49/100.
\end{aligned}
\]
如果 `g>=26r+6`，最后一行至多
\[
-\frac{14181}{125000}r-\frac{28561}{125000}<0.
\]
同理 scaled radius 的十进制指数满足
\[
\log_{10}(D10^{N-4g})<(C-4)g+r+49/100
\le-\frac{6764181}{125000}r-\frac{1528561}{125000}<-9.
\]
因此乘 (JS24) 得到正整数
`0<D(1-u)<47/100+1/(2*10^9)<1`，矛盾。
最终 5-beta 在 (2S) 内必须满足
\[
\boxed{13\le g<26r+6,\qquad g<d_2<11g/6,
\qquad m_3=3d_2-1.}
\tag{JS40}
\]
当 `r<=12` 时确实得到 `g<=317`，但本轮没有枚举该有界形状中的
实际前缀、offset 或解；不能把这个相对高度归约宣称为 5-beta 已全部关闭。
高于 (JS40) 的整片无界参数已由精确格点矛盾关闭，盒内仍须用
(JS38)、唯一 `B` residue、原既约性与完整 sphere 继续审计。


#### 2-near-beta 的真实加法 word 与低/平衡 5 支相对盒

**状态：已严格完成（无界条件空性与恢复条件）；盒内仍待证。**
本段保留 (2S)，处理 `d2=m3-1`，且 `d5<m3`。
写
\[
b_3=2^{\nu+m_3-1}B_2,\qquad
 A_2=5^{\nu+m_3}(10b_1+1),\qquad
 C_2=q_{\rm lcm}/2^{\nu+m_3-1}.
\]
正 gap 的真实加法 word 给
\[
\boxed{
(H_{\rm sph}+y_3)(B_2+2A_2)
=C_2A_{12}10^{n_3}+2y_3(A_2+B_2).
}
\]
左端 `2` 深度为 `2m3-3`，第一项深度为 `n3=m3-g`，故
\[
\boxed{v_2(A_2+B_2)=n_3-1.}
\tag{JS41}
\]
不把模 `2` 同余当作 `H_sph±y3` 的符号；该深度来自 (JS31) 中真实
near-beta 因子的赋值。

此时 `u` 的既约分母只能为 `D=5^b`，其中
`b=m3-nu-d5>0`；若 `b<=0`，`u` 为整数，与 `0<u<1` 直接矛盾。
`u` 的分子至少被 `2^(nu-1)` 整除，所以质量条件为
\[
\boxed{2^{\nu-1}<5^b.}
\]
令 `h=2g-3r-1-nu>=0`，则 `S=-h`。

若 `d5<g`，写 `Delta=g-d5>=1`，由 `n3=2d5` 得
\[
b=3r+1+h-\Delta,\qquad
D10^S=2^{-h}5^{3r+1-\Delta}.
\]
scaled radius 小于 `(1/2)10^(r+1-2g-Delta)<=1/(2*10^9)`。
正整数 `D(1-u)` 先排除 `Delta>=3r+1`，所以 `Delta<=3r`。
再由 `47/100*2+1/(2*10^9)<1`，必有 `D10^S>2`，于是
\[
2^{h+1}<5^{3r+1-\Delta}<2^{3(3r+1-\Delta)},\qquad
h\le9r+1-3\Delta.
\]
结合质量 `2^(nu-1)<5^b<2^(3b)` 和 `nu=2g-3r-1-h`，
\[
2g<12r+5+4h-3\Delta\le48r+9-15\Delta\le48r-6.
\]
因此严格得到
\[
\boxed{d_2=m_3-1,\ d_5<g\Longrightarrow
1\le g-d_5\le3r,\qquad g\le24r-4.}
\tag{JS42a}
\]

若 `d5=g`，写 `c=2g-n3>=0`，则
\[
b=3r+1+h-c,\qquad D10^S=2^{-h}5^{3r+1-c}.
\]
scaled radius `<(1/2)10^(r+1-2g-c)<=1/(2*10^8)`。
同一正整数预算给 `c<=3r`、`h<=9r+1-3c`，质量再给
`2g<48r+9-15c<=48r+9`，故
\[
\boxed{d_2=m_3-1,\ d_5=g\Longrightarrow
2g-3r\le n_3\le2g,\qquad g\le24r+4.}
\tag{JS42b}
\]
两行给出真实高 `g` 子支的无界关闭，但 `r` 没有全局上界；即使
`r<=12` 把 `g` 压到绝对有界，本轮也没有枚举盒内解。

`d5>g` 的 5-regular-high 仍保留 `m3=3d5`、(JS41)、真实 denominator
unit 和完整恢复。一个独立的 prefix-source bound 来自
[rational-contact.md](rational-contact.md) 的 universal denominator funnel：
令 `j` 为 `b3` 的非 `2,5` 部分，则
\[
j\mid b_1(10b_1+1)^2,\qquad
u=2^{\nu-1}j/5^{2d_5-\nu}.
\]
用已证明的 `u>529/1000`，
\[
25^{d_5}<10^\nu j<10^{\nu+3(2g-r)+2}\le10^{8g-6r+1}.
\]
因为 `25^6>10^8`，完整候选必须 `d5<6g`，即 `m3<18g`。
这仍是相对尾高压缩，不是 5-regular-high 全部空性；最新剩余应联立
该 divisor condition、(JS41) 与原 sphere，而不能只使用 phase 窗口。

#### non-(2S) 的真实第一分母质量与 two-coordinate low balanced

**状态：已严格完成（必要恢复与无界子支空性）。**
若 `e1=v2(w)>=nu`，真实 `w` 的上界直接给
\[
\boxed{2^{g+1}\le2^\nu\le w<(267/500)10^r.}
\]
因此 `r>=13`；`g` 还须满足这个 exact power criterion，不能把首分母
更深的范围忽略。该条件可用于审计 `t=0` 和 `t>0` 的新增分支。

在 `e1=nu,d2=d5=d<g` 的 two-coordinate low balanced 中，
`n3=2d`，`u` 的既约分母为 `D=10^(g+d-nu)`；若指数不正则 `u` 为
整数而为空。写 `Delta=g-d`，有
\[
D10^S=10^{3r+1-\Delta},\qquad
\tfrac12 D10^{N-4g}\psi^2
<\tfrac12 10^{r+1-2g-\Delta}\le\frac1{2\cdot10^9}.
\]
因此 `Delta>=3r+1` 仍被正整数预算排除，得到
\[
\boxed{e_1=\nu,\ d_2=d_5=d<g
\Longrightarrow1\le g-d\le3r.}
\tag{JS43}
\]
这是去掉 (2S) 后的新恢复条件；该相对 gap 内仍待证，没有宣称该
two-coordinate balanced branch 已全局关闭。
