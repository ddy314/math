# A2 outer-pair / descendant-common 的 external `Q_4` root splitter

> **依赖：** `outer-descendant-additive-lock.md`、`outer-cofactor-reuse-gate.md`、`endpoint-lattice.md` §§16.27–16.36、`crt-descent-ledger.md` 中 universal descendant cubic / projective depth reader / terminal character。
>
> **严格状态：**shared outer/descendant 的 genuine external support 被 §§1–8 压到固定 `p_C=24303427940647`。2026-09-30 审计修正高阶 checker 的 transport 方向：实际四阶系数为 `26[27(X_d+Y_d)]^4-[55Y_d]^4`，strict terminal 必要条件是 `(26/p)=+1`。`p_C` 不兼容此条件；实际 `H2/H3/H4` 也均为单位。四对象共同深度恰为一层，且 deeper recycling 必须 exact triple saturation。third-parent parity 可保留，但旧 generic fixed-`3` depth `6/10` 已失效；spill supplier 可能回到 fixed `3`，因此 A2 仍为 `待证`。

---

## 1. additive lock 的三张 `K` sheet

沿用

\[
R_0(K,\zeta)=K^2-(18+4\zeta)K+18\zeta+55
\]

以及首一四次式

\[
\Phi_0(J)
=J(J+2\zeta)(K-J)^2-R_0(J+\zeta)^2.
\tag{1.1}
\]

若同一 genuine prime `p` 同时整除 `Xi_-`,`Xi_+` 且 `p|G_\Delta`，`outer-descendant-additive-lock.md` 已给

\[
\Phi_0(2)\equiv\Phi_0(4)\equiv0\pmod p.
\tag{1.2}
\]

记

\[
P_2:=\Phi_0(2),\qquad P_4:=\Phi_0(4),
\]

\[
H_{24}:=\frac{P_4-P_2}{4}
=4K\zeta^2+18K\zeta+26K-18\zeta^2-81\zeta-105.
\tag{1.3}
\]

exact resultant 为

\[
\boxed{
\operatorname{Res}_\zeta(P_2,H_{24})
=2(K-3)^2(2K-9)Q_4(K),}
\tag{1.4}
\]

其中

\[
\boxed{
Q_4(K)=676K^4-8004K^3+34801K^2-65868K+45964}
\tag{1.5}
\]

在 `Q[K]` 中不可约。

因此 non-`2` shared prime 必落在

\[
K=3,\qquad 2K-9=0,\qquad Q_4(K)=0
\tag{1.6}
\]

三类之一。

---

## 2. central factor 对 non-`3` prime 实际为空

把

\[
K=\frac92
\]

代回两个 outer equations：

\[
P_2=\frac{23\zeta^2+192\zeta+192}{4},
\]

\[
P_4=\frac{23\zeta^2+192\zeta+384}{4}.
\]

所以

\[
\boxed{P_4-P_2=48.}
\tag{2.1}
\]

故若 odd `p` 同时满足 `2K-9=0` 与 (1.2)，必有 `p|48`。在当前 non-`3` inert sector 不可能。

因此

\[
\boxed{2K-9=0\text{ 不是 genuine external shared-reuse branch}.}
\tag{2.2}
\]

---

## 3. `K=3` 是 root-collision sheet

在 `K=3`：

\[
P_2=-2(\zeta+3)(3\zeta^2+8\zeta+6),
\]

\[
P_4=-2(\zeta+3)(3\zeta^2+20\zeta+24).
\]

两式在 characteristic 非 `2,3` 的公共因子只有

\[
\boxed{\zeta+3.}
\tag{3.1}
\]

代入 `K=3,\zeta=-3`，完整 rational-root quartic 化为

\[
\boxed{
\Phi_0(r)=(r-4)(r-3)^2(r-2).}
\tag{3.2}
\]

所以 `K=3` 并非新的自由 external surface；真实 root 只能撞到 `2,3,4`，且 `r=3` 为双根。以下真正的 moving analysis只需处理 `Q_4=0`。

2026-09-30 补充 singular audit：把该点直接送入 universal descendant cubic，
精确得到

\[
\mathcal E_{63}(3,-3)=3^{10}\cdot5\cdot7^2\cdot41\cdot173.
\]

其中 non-`3` inert support 只有 fixed `7`；其余奇素数均为 split。
因此 `K=3` 在 genuinely external sector 为空。另对 §4 的 coefficient-singular
inert labels `23,31`，checker 穷尽其 `Q_4` roots 与真实 `zeta in F_p`，
均无同时满足 `P_2=P_4=E_63=0` 的点；它们也不会逃离 generic reader。

---

## 4. generic `Q_4` 上 `zeta` 只有一个线性 reader

对 `P_2,P_4` 关于 `zeta` 取 subresultant chain。最后一个正次数 subresultant 为

\[
64(2K-9)^2L_1(K,\zeta),
\]

其中

\[
\boxed{
\begin{aligned}
L_1={}&(18K^3-185K^2+612K-648)\zeta\\
&+26K^3-297K^2+1052K-1158.
\end{aligned}}
\tag{4.1}
\]

记 `zeta` 系数为 `A_1(K)`。其与 `Q_4` 的 resultant 为

\[
\boxed{
|\operatorname{Res}(Q_4,A_1)|
=2^{10}23^2 29^2 31^2.}
\tag{4.2}
\]

常数项的 resultant 为

\[
\boxed{
2^{15}\cdot13\cdot23\cdot29^2\cdot31^2.}
\tag{4.3}
\]

所以除 fixed `23,31`（以及 split `13,29`）外，generic `Q_4` root 上

\[
\boxed{\zeta=-B_1(K)/A_1(K)}
\tag{4.4}
\]

唯一确定。fixed `23/31` 在 checker 中保留为 coefficient-singular audit，不把它们混入 generic division。

---

## 5. `Q_4` 上第三个整数点自动成为 root

把 (4.4) 代入 `Phi_0(3)`，清分母后的 numerator 对 `Q_4(K)` 的余数严格为 `0`。因此：

\[
\boxed{Q_4=0,\ L_1=0\Longrightarrow \Phi_0(3)=0.}
\tag{5.1}
\]

而 `Phi_0(J)` 是首一四次式，其 `J^3` 系数给根和

\[
\sum r_i=2K-2\zeta.
\]

三个根已经是 `2,3,4`，故第四根必为

\[
\boxed{r_\star=2K-2\zeta-9.}
\tag{5.2}
\]

所以 generic `Q_4` shared-reuse 中，真实 rational root

\[
r=3-C/D
\]

只能满足

\[
\boxed{r\in\{2,3,4,r_\star\}\pmod p.}
\tag{5.3}
\]

这把原二维 modular freedom 压成四个 natural-root slots。

---

## 6. 真实根若等于第四根，则 genuine external 立即矛盾

若

\[
r=r_\star
\]

且与 `2,3,4` 均不同，则 `2,3,4` 全是 actual root 之外的三个整数根。因此同一 `p` 同时整除

\[
\Xi_-,\qquad\Xi_C,\qquad\Xi_+.
\tag{6.1}
\]

于是两个相邻 gap 都被 `p` 整除。`endpoint-lattice.md` §16.34 的 exact curvature identity为

\[
\Delta_--\Delta_+
=2^{m+1}5^dc_u^2B_\Delta,
\tag{6.2}
\]

其中

\[
B_\Delta=g((2K-9)T-a_3)-H_0.
\]

对 genuine external prime，`p∤2\cdot5c_u`，故 (6.1)–(6.2) 给

\[
\boxed{p\mid B_\Delta.}
\tag{6.3}
\]

另一方面 `p|G_\Delta` 给 `p|\widehat D_{63}`，而

\[
\widehat D_{63}
=c_u^2\left((2K-9)B_\Delta-\frac{63}{16}gTK^2\right).
\tag{6.4}
\]

若 `p` genuinely external，即

\[
p\nmid2\cdot3\cdot7\,c_ugTK,
\]

则 (6.3),(6.4) 强迫

\[
p\mid63,
\]

矛盾。因此：

\[
\boxed{r=r_\star\text{ 的 generic genuine external branch为空}.}
\tag{6.5}
\]

fixed `3,7` 与 coefficient-content cases仍由各自旧账本处理，不在这里重复收费。

---

## 7. `r=2` 与 `r=4` collision 没有 non-`3` inert support

若真实 root `r=2`，则

\[
p\mid D-C.
\]

而当前同一 prime还整除 `Xi_-`。因此 root `2` 在 mod `p` quartic 中必须至少为双根；在 (5.3) 中这意味着

\[
r_\star=2,
\qquad
\zeta=K-\frac{11}{2}.
\tag{7.1}
\]

将 (7.1) 代入 `P_2,P_4`，分别与 `Q_4` 对 `K` 求 resultant。任何共同 prime必须整除两个 resultants的 gcd，而 checker得到

\[
\boxed{
\gcd(R_2^{(2)},R_4^{(2)})
=2^{12}3^3\cdot137.}
\tag{7.2}
\]

其中

\[
137\equiv1\pmod4.
\]

所以 non-`3` inert prime不存在。

同理，若真实 root `r=4`，`p|D+C` 且 `p|Xi_+` 迫使

\[
r_\star=4,
\qquad
\zeta=K-\frac{13}{2}.
\tag{7.3}
\]

对应两个 resultants 的 gcd 为

\[
\boxed{
2^{24}3^3\cdot17,}
\tag{7.4}
\]

而 `17≡1 (mod4)`。因此：

\[
\boxed{r=2\text{ 或 }r=4\text{ 的 shared external inert branch全部为空}.}
\tag{7.5}
\]

这与旧 `floorfree-modulus-overlap` 中 `D-C,D+C` 两张 short carrier接口一致，但这里直接使用完整 additive-locked outer system，不需要额外高度估计。

---

## 8. 唯一剩余 root collision 是 `r=3`, 即 `p|C`

由 (5.3),(6.5),(7.5)，generic shared external prime只能满足

\[
\boxed{r=3\Longleftrightarrow p\mid C.}
\tag{8.1}
\]

现在把 `C=0` 代回 source identity

\[
H_0=g(3T+a_3)-5^\lambda C
\]
得到

\[
H_0\equiv g(3T+a_3)\pmod p.
\]

故

\[
B_\Delta
=g((2K-9)T-a_3)-H_0
\equiv2gT(K-6-\zeta).
\]

再代入 `p|\widehat D_{63}`，除去 genuine units `c_u,g,T`，得到新的线性 `zeta` gate

\[
\boxed{
K^2-64K\zeta-672K+288\zeta+1728=0.}
\tag{8.2}
\]

若 `2K-9` 为 unit，可写成

\[
\boxed{
\zeta=
\frac{K^2-672K+1728}{32(2K-9)}.}
\tag{8.3}
\]

把 (8.3) 分别代入 `P_2,P_4`，再各自与 `Q_4` 对 `K` 消元。两 resultant 的 gcd 完整分解为

\[
\boxed{
2^{18}\cdot7\cdot23^2\cdot24303427940647.}
\tag{8.4}
\]

记

\[
\boxed{p_C:=24303427940647.}
\tag{8.5}
\]

`p_C` 为素数且 `p_C≡3 (mod4)`。

`p=23` 对应 `2K-9=0` 的 central denominator，已由 §2 删除；`p=7` 落回 `K=3` fixed sheet。故 genuine external 中只剩

\[
\boxed{p=p_C.}
\tag{8.6}
\]

checker还给出真实 first-layer residue

\[
\boxed{
K_C=21805672591624,
\qquad
\zeta_C=9250192938088
\pmod{p_C},}
\tag{8.7}
\]

它确实同时满足 `Q_4,P_2,P_4,(8.2)`，并满足 universal descendant cubic `E_63=0`。所以这不是 resultant 的扩域伪根，不能在 first layer直接删除。

清掉 (8.3) 的 unit denominator 后，三个 pure-`K` 多项式在
`F_{p_C}[K]` 中的 monic common gcd 精确为
`K+2497755349023=K-K_C`。因此 (8.7) 是该 noncentral 四方程系统的
唯一真实 first-layer 点，后续局部排除无遗漏其它 `p_C` residue。

---

## 9. actual transport 方向审计与严格 terminal 条件

本节以 [`crt-descent-ledger.md` 的方向审计](crt-descent-ledger.md#transport-direction-audit)
为准。真实 root 与 ratio 满足
\[
J=J_0-F_\Delta/(2K-9),\qquad R=R_0-K^2\mathscr L_{\rm proj}.
\]
因此 actual transport 是 `Phi(J0,R0)-Phi(J0-F/U,R0-K²L)`。
旧 high-order checker 在 approximation 上用了加向；它给出的
`26[27(X_d+Y_d)]^4+[55Y_d]^4` 与 character `(26/p)=-1`
均为 **失效/降级**。旧本专题引用 `(-26/p)=-1` 虽恰匹配 actual
符号，却不能由旧 ledger 的加号四阶系数证明。本轮从 exact 原式重新建立
\[
\boxed{\mathcal H_4=26[27(X_d+Y_d)]^4-[55Y_d]^4,}
\]
故 strict-lower-block terminal overdepth 必须满足
\[
\boxed{\left(\frac{26}{p}\right)=+1,
\qquad\left(\frac{-26}{p}\right)=-1.}
\tag{9.4}
\]
而精确核对给 `p_C` 的 `(26/p_C)=-1`，所以该 **strict sector** 为空。
这不删除 lower block 恰为 `4h` 的 boundary cancellation。

此外 `ord_{p_C}(10)=p_C-1`，单纯 decimal orbit 仍不能排除 first-layer payment。

### 9.1 `已严格完成`：四对象在 `p_C` 上的共同深度恰为一层

在 §§4–8 的 genuine external `Q_4 / r=3` 子支，定义

\[
t_C:=\min\{v_{p_C}(\Xi_-),v_{p_C}(\Xi_+),
                 v_{p_C}(G_\Delta),v_{p_C}(C)\}.
\tag{9.5}
\]

上述 first-layer 假设已经保证 `t_C>=1`。若 `t_C>=2`，additive gcd
interface 将 coefficient lock 提升到模 `p_C^2`；`D`、`T`、`b_2`
均为单位，而 `p_C^2|C` 将真实 root 提升为 `r=3 mod p_C^2`。
因此 (8.2) 和两个 outer equations 都必须同时在模 `p_C^2` 上消失。

在 (8.7) 的 first-layer 点，`(P_2,P_4)` 关于 `(K,zeta)` 的 Jacobian
determinant 精确为

\[
\boxed{3212002394182\not\equiv0\pmod{p_C}.}
\tag{9.6}
\]

其唯一二阶 lift 写为
`K=K_C+p_C u,zeta=zeta_C+p_C v`，则

\[
\boxed{(u,v)=(17757405664989,19804620386067)\pmod{p_C}.}
\tag{9.7}
\]

直接代入 (8.2) 的左边 `F_{D,C=0}`，得到

\[
\boxed{
\frac{F_{D,C=0}}{p_C}
\equiv2979046557878\not\equiv0\pmod{p_C}.}
\tag{9.8}
\]

所以不存在三方程共同的二阶 lift，严格得到

\[
\boxed{t_C=1.}
\tag{9.9}
\]

也可由 (8.4) 中 `p_C` 的 resultant exponent 恰为 `1` 得到同一
截断。此结论不保证四个 individual valuations 全部为 `1`；它只保证
至少一个对象停止在第一层，不能据此删除 first-layer payment。

### 9.2 `已严格完成`：实际 parent ratio 排除 strict-lower-block terminal sector

采用 [`crt-descent-ledger.md` 的 balance-tail](crt-descent-ledger.md#source-spontaneous-crt-descendant-balance-tail)
和 finite quartic hierarchy 的记号

\[
X=5^\lambda\mathscr R_{63}^\star,
\qquad Y=g2^m\widehat{\mathscr D}_{63},
\qquad h=v_{p_C}(G_\Delta)\ge1.
\tag{9.10}
\]

在 (8.7) 的固定 residue，first-order 两个 coefficient gates 给出

\[
\boxed{
\mathcal G_<\equiv9320260449125,
\qquad
\mathcal G_>\equiv13624230293838
\pmod{p_C}.}
\tag{9.11}
\]

两者均为单位。因此 unequal parent depth 的两条 linear-tail recycling
路线上，唯一最低系数不会消失；若继续 same-prime recycling，必须进入
equal parent depth `v_{p_C}(X)=v_{p_C}(Y)=h`。写
`X=p_C^h X_0,Y=p_C^h Y_0`，first balance 使唯一 ratio 为

\[
\boxed{
\frac{X_0}{Y_0}
\equiv\chi_{geom}
:=-\frac{2\mathcal G_>}{81\mathcal G_<}
\equiv5130679962854\pmod{p_C}.}
\tag{9.12}
\]

把该实际 ratio 代入 quartic coefficient，而不只检查 character，得到

\[
\boxed{
\mathcal H_4(\chi_{geom},1)
=26[27(\chi_{geom}+1)]^4-55^4
\equiv16192417895792\not\equiv0\pmod{p_C}.}
\tag{9.13}
\]

故在该 first-recycling 子支上 `v_{p_C}(M^{(4)})=4h`。
若进一步满足 terminal-character theorem 的明确假设

\[
v_{p_C}(M^{(1)}+M^{(2)}+M^{(3)})>4h,
\tag{9.14}
\]

则最低层只有 quartic block，严格得到

\[
\boxed{v_{p_C}(M)=4h.}
\tag{9.15}
\]

于是 **(9.14) 下的** terminal overdepth `v_{p_C}(M)>4h` 被排除。
这是独立于旧反号论证的实际 coefficient 排除，适用于任意 `h>=1`。
若 lower block 的深度恰为 `4h`，它仍可与 quartic block 发生 normalized
cancellation；(9.13) 不排除这一 boundary regime，也不关闭全 A2。

### 9.3 `已严格完成`：`p_C` 若继续 terminal recycling，只能 exact triple saturation

同一 canonical reconstruction 还给出实际 parent ratio 上的其它
primitive homogeneous coefficients：

\[
\boxed{
\begin{array}{c|rrrr}
n&1&2&3&4\\\hline
\mathcal H_n(\chi_{geom},1)\bmod p_C
&0&2328839710684&18611479848870&16192417895792
\end{array}}
\tag{9.16}
\]

其中 `H_1` 的零点正是 first balance，后三项均为单位。采用
finite quartic hierarchy 的 ordinary tail depths

\[
\rho=v_{p_C}(B_{63}),\quad
\sigma=v_{p_C}(C_{63}^{(2)}),\quad
\tau=v_{p_C}(C_{63}^{(3)}).
\tag{9.17}
\]

则任意 same-prime common label 的 terminal overdepth 都必须满足

\[
\boxed{v_{p_C}(M)>4h\Longrightarrow\rho=\sigma=\tau=h.}
\tag{9.18}
\]

证明逐层使用 exact hierarchy 的最低赋值：`rho<h` 时已经停在
`h+rho<2h`；`rho>h` 时 quadratic block 的单位独占 `2h`。
因此越过 `2h` 只能 `rho=h`。进入该子支后，`sigma<h` 时停在
`2h+sigma<3h`，`sigma>h` 时 cubic 单位独占 `3h`；故越过 `3h`
只能 `sigma=h`。再以 quartic 单位重复一步，越过 `4h` 只能 `tau=h`。
各显示 rational scales 在 `p_C` 上都是单位，故无隐藏 content 修正。

所以该 fixed exception 无法使用 strict `P_110`、`P_148` 或 strict
quartic coefficient-zero sector 来继续；全部 deeper recycling 被压到
三个 exact baseline collisions。依赖
[`crt-descent-ledger.md` 的 third-order parity spill](crt-descent-ledger.md#source-spontaneous-crt-descendant-third-order-parity-spill)，
在 (9.18) 下第三阶 parent 的深度恰为 `4h`，是偶数。因此 `p_C` 对
该 parent 的 odd-inert parity 中性；第三阶 positive carrier 仍需
terminal recycling pool 之外的 supplier。这里不能直接说该 supplier
与所有其它 old/external pools 都不同。尤其正确 transport 已撤回旧 generic fixed-`3` depth `6/10`，故 fixed `3` 仍是可能补给；其全局排除仍为 `待证`。

---

## 10. 当前 frontier

危险 `Z=1` 中，同一 non-`3` inert prime若想同时支付 `Xi_-`,`Xi_+` 并复用 `G_\Delta`：

1. source-common old pool 已由 `outer-descendant-additive-lock.md` 删除；
2. central `2K-9` branch为空；
3. generic `Q_4` 的 fourth-root branch为空；
4. `r=2,4` natural-root collision为空；
5. `r=3` 只剩 fixed `p_C=24303427940647`；
6. `p_C` 与 actual strict terminal character不兼容；(9.5) 的共同深度恰为一层；
7. actual first-balance quartic coefficient 为单位，故 strict-lower-block
   terminal sector 被排除；其 quadratic/cubic coefficients 也均为单位，
   因而 deeper terminal recycling 只能进入 exact triple saturation；
8. 在该 exact branch 中 `p_C` 对第三阶 parent parity 中性，仍需
   terminal pool 外的 parity complement；其全局排除待证。

因此 shared-reuse 的真正剩余已经不是 unbounded external modular kernel，而是：

\[
\boxed{
\text{one fixed first-layer }p_C
+\text{pre-terminal spill / parity handoff}
+\text{fourth-order boundary cancellation}.}
\]

本文没有证明这些 handoff / boundary cancellation 本身矛盾，所以 `A2` 仍为 `待证`。

---

## 11. verification

```bash
uv run python scripts/exact-lift/a2-only/research-checks/crt-descent/check_a2_outer_external_q4_root_split.py
```
