# `A_2`-only 分支

本文件是 A2 的规范导航入口。A2 当前仍为 **待证**：大量 source / endpoint / Gaussian / CRT / fixed-prime 通道已经严格压缩或降级，但 `m_2>=11` 的 deep-even 无界核心及剩余 fixed-prime、prefix-gcd、sphere-height 通道尚未统一排除。

当前严格结果集中在下列入口；作用域以各命题的假设为准。

| 入口 | 已证明的结果 | 仍未关闭的部分 |
| --- | --- | --- |
| [actual transport 审计](crt-descent-ledger.md#transport-direction-audit) | 实际减向；strict terminal 条件 `(26/p)=+1`；旧 plus 高阶链降级 | 不复用旧 quartic orientation 或 `6/10` 初项 |
| [external `Q4`](outer-external-q4-root-split.md#9-actual-transport-方向审计与严格-terminal-条件) | `pC=24303427940647` 四对象共深度只有 `1`；deeper recycling 必须 exact triple saturation | third parity 需 terminal pool 外供应，仍缺统一预算 |
| [fixed `3`](fixed3-terminal-spill.md#fixed3-corrected-depths) | 原 sphere/plane 重建 `a2`-shallow f-unit depth `8`、全部 a3-shallow depth `12`；contact 的 source 层初项 `9/10/11` | odd 只可能来自 a2-shallow f-contact；更深 zero sheet 奇偶待证 |
| [contact orientation](fixed3-f-contact-orientation.md#eta2-contact-slots) | `eta=1` contact 排除；`eta=2` 只剩八个 positive `e3=1` slot | 八型不是全局十进制候选集 |
| [source `A3` / pool 接口](fixed3-f-contact-orientation.md#source-a3-parity-surcharge) | 明确子片强迫异于 `pC` 的 non-`3` inert label；saturated gcd≤`11` 且不能再进入 descendant | 不提供整个 qf 池的独立性或新预算 |
| [shared `7`](fixed3-f-contact-orientation.md#95-允许的-shared-7-sheet) | source/height/descendant/outer 联立后，`eta=2` 只剩 `(cQ,kh)=(31,51),(527,3)`、`m=2 mod3` | 原 source charts 可无限局部提升，且 `7` 可承担 odd third parity；非 Exact Lift 解 |
| [真实整数核](fixed3-f-contact-orientation.md#96-剩余两型的真实整数核) | `g|5^(3m-3)+cQ cu` 与唯一 numerator remainder 恢复；`v2(g)=2` 的有限 lower length 为 `m>=68,80` | 无界 `m` 的 divisor / remainder / sphere 排除待证 |
| [剩余 parity](fixed3-f-contact-orientation.md#97-实际-fixed-3-word-与剩余-parity-供应) | 两型强迫 `K/3=1 mod3`；明确 deep source / generic 7-word 子片需 `3,7` 外的 inert label | label 尚未与全部旧 pools 分离，不自动增加独立高度预算 |

其它 terminal 类型、fourth-order boundary cancellation、prefix-gcd 与 sphere-height
核心仍为 **待证**。有限证书与局部 Hensel 兼容均不能替代无界整数证明。

主线结论保留在六个规范专题文件中；大量细粒度 continuation 已按依赖机械归并为五本研究账本。下面的独立 continuation manifest 已保留本地补导航涉及的全部 17 个专题；其适用范围、更正与闭合声明以专题正文为准，导航合并不表示重新核验所有证明和证书。不要在本目录新增同一主题的平行副本。

## 规范主线

推荐先读 [`core.md`](core.md)、[`phase-and-defect.md`](phase-and-defect.md)、[`hensel.md`](hensel.md)、[`endpoint-lattice.md`](endpoint-lattice.md)、[`prime-source.md`](prime-source.md)、[`primitive-reduction.md`](primitive-reduction.md)。五本细粒度账本为 [`auxiliary-reductions-ledger.md`](auxiliary-reductions-ledger.md)、[`source-angle-ledger.md`](source-angle-ledger.md)、[`crt-descent-ledger.md`](crt-descent-ledger.md)、[`height-ledger.md`](height-ledger.md)、[`fixed23-and-cq-ledger.md`](fixed23-and-cq-ledger.md)。

所有“collapse / closure”只按文件写明的 hypotheses 生效；它们不能仅凭文件名升级为 A2 全局空性。

## 独立 continuation manifest

以下文件保留独有的后续推导，因此继续作为顶层可审计节点；每个节点都必须从本 README 直接可达。

- [`additive-descendant-gcd-interface.md`](additive-descendant-gcd-interface.md)
- [`descendant-f-gd-bridge.md`](descendant-f-gd-bridge.md)
- [`endpoint-five-point-cofactors.md`](endpoint-five-point-cofactors.md)
- [`external-shared-outer-fixed-templates.md`](external-shared-outer-fixed-templates.md)
- [`external-shared-outer-nogo.md`](external-shared-outer-nogo.md)
- [`fixed-prime-asymmetric-lifts.md`](fixed-prime-asymmetric-lifts.md)
- [`fixed-prime-descendant-transversality.md`](fixed-prime-descendant-transversality.md)
- [`fixed-target-serial-dichotomy.md`](fixed-target-serial-dichotomy.md)
- [`fixed199-angle-residual.md`](fixed199-angle-residual.md)
- [`fixed3-exception-collapse.md`](fixed3-exception-collapse.md)
- [`fixed3-f-contact-orientation.md`](fixed3-f-contact-orientation.md)
- [`fixed3-terminal-spill.md`](fixed3-terminal-spill.md)
- [`outer-cofactor-reuse-gate.md`](outer-cofactor-reuse-gate.md)
- [`outer-descendant-additive-lock.md`](outer-descendant-additive-lock.md)
- [`outer-external-q4-root-split.md`](outer-external-q4-root-split.md)
- [`source-common-outer-fixed-exception.md`](source-common-outer-fixed-exception.md)
- [`target-common-parity-surcharge.md`](target-common-parity-surcharge.md)

## 当前边界

现有结果已经把许多看似独立的高阶 Hensel / quadratic-character / Gaussian-child 条件识别为既有 exact identities 的投影，后续不得重复收费。当前真正需要的新输入仍应同时控制 moving coefficient、真实 decimal window 与剩余 odd-prime/source channels；有限枚举、单个 fixed-prime closure 或局部 descendant transversality 均不能代替全局无界证明。
