# A2 fixed `3` 的 third-order spill reduction

> **依赖：** `endpoint-lattice.md` §§16.11–16.12、16.57–16.59；`primitive-reduction.md` §§1–3；历史 descendant chain 中 `spontaneous-crt-descendant-second-order-tail.md`、`spontaneous-crt-descendant-quartic-tail-hierarchy.md` 与 `spontaneous-crt-descendant-third-order-parity-spill.md` 的 canonical formulas。
>
> **严格状态：已严格完成（更正后的 generic depth `8/12`）；待证（`a2`-shallow `f`-contact parity）；失效/降级（旧 `6/10` 推导）。**
> 2026-09-30 [actual transport 方向审计](crt-descent-ledger.md#transport-direction-audit)
> 将 `Phi(J0+F/U,R0+K²L)-Phi(J0,R0)` 改回真实原式的减向。
> 正确 `H2` 使下面旧 §3 的 depth-`6`、旧 §4 的 depth-`10` leading forms
> 在 exact source substitution 后都为零。因此 `v3(N3)=6/10` 与旧
> “fixed 3 只能来自 f-contact / extra-central”frontier 均撤回。
> §§1–2 的 endpoint/source identities 仍有效；第三阶 global `3 mod4`
> orientation 由正确 second-order tail 和 cubic binary layer 独立重建。
> 新 §5 从 exact sphere/plane 重新归一化同一第三阶 parent，证明
> `a2`-shallow、`3∤f` 的 exact depth 为 `8`；全部 `a3`-shallow 的 exact depth 为 `12`。
> fixed `3` 仍可能从 `a2`-shallow `f`-contact 承担 spill parity；不关闭 A2。

---

## 1. endpoint fixed-`3` dichotomy

在 `Z≡1 mod4` orientation，`endpoint-lattice.md` 已证明

\[
\boxed{
\begin{cases}
v_3(a_3)=1,\quad v_3(a_2)\ge2,\\
\text{or}\\
v_3(a_2)=1,\quad v_3(a_3)\ge2,
\end{cases}}
\tag{1.1}
\]

同时

\[
3\nmid g,
\qquad
3\nmid c_u,
\qquad
3\nmid c_Q,
\qquad
3\nmid\beta.
\tag{1.2}
\]

而 `primitive-reduction.md` 给

\[
\alpha=\omega W_q,
\qquad
H_0=c_uW_q,
\qquad
\beta=S\omega,
\tag{1.3}
\]

其中 `3∤S` 于当前 odd-`3` channels 成立。因此

\[
\boxed{3\nmid\omega.}
\tag{1.4}
\]

又由 (1.1)，原拼接分子

\[
\alpha=TK+a_3
\]

恰含一个 `3`，所以

\[
\boxed{v_3(W_q)=v_3(H_0)=1.}
\tag{1.5}
\]

此外 `endpoint-lattice.md` §16.58 已给

\[
\boxed{3\nmid\widehat{\mathcal T}_2.}
\tag{1.6}
\]

---

## 2. descendant parent 与一个新的 exact source identity

为避免与 endpoint Gaussian factors `X,Y` 混淆，本节把 descendant parent coordinates 记为

\[
\boxed{
X_d:=5^\lambda\mathscr R_{63}^\star,
\qquad
Y_d:=g2^m\widehat{\mathscr D}_{63}.}
\tag{2.1}
\]

则

\[
\widehat{\mathcal T}_2=X_d+Y_d.
\tag{2.2}
\]

历史 descended quotient formula 是

\[
\widehat{\mathscr D}_{63}
=c_u^2\mathscr F_{63},
\tag{2.3}
\]

\[
\mathscr F_{63}
=(2K-9)B_\Delta
-\frac{63}{16}gTK^2,
\tag{2.4}
\]

其中

\[
B_\Delta=g((2K-9)T-a_3)-H_0.
\tag{2.5}
\]

利用

\[
H_0=c_u\frac{TK+a_3}{\omega},
\qquad
f=g\omega+c_u,
\]

可得到本文使用的 exact identity：

\[
\boxed{
\omega B_\Delta
=f((2K-9)T-a_3)
-3c_u(K-3)T.}
\tag{2.6}
\]

证明只是展开：

\[
\begin{aligned}
\omega B_\Delta
&=g\omega((2K-9)T-a_3)-c_u(TK+a_3)\\
&=(f-c_u)((2K-9)T-a_3)-c_u(TK+a_3)\\
&=f((2K-9)T-a_3)-3c_u(K-3)T.
\end{aligned}
\]

这条式子把 fixed-`3` descendant depth 与旧 denominator factor `f` 直接接起来。

---

## 3. `失效/降级`：旧 `a_2`-shallow exact depth `6`

先固定

\[
\boxed{
v_3(a_2)=1,
\qquad
v_3(a_3)\ge2.}
\tag{3.1}
\]

写

\[
K=3k,
\qquad k\in\mathbf Z_3^\times,
\qquad
s:=(-1)^m\in\{\pm1\}.
\tag{3.2}
\]

此时

\[
v_3(2K-9)=1.
\tag{3.3}
\]

若进一步

\[
\boxed{3\nmid f,}
\tag{3.4}
\]

因为 `g,omega,c_u` 均为 `3`-units，且

\[
f=g\omega+c_u,
\]

模 `3` 两个单位之和非零只可能来自相同 residue，因此

\[
\boxed{c_u\equiv g\omega\pmod3.}
\tag{3.5}
\]

由 (2.6)：第二项含至少 `3^2`，而第一项恰含一个 `3`，所以

\[
v_3(B_\Delta)=1.
\]

更精确地，模 `3` 有

\[
\frac{2K-9}{3}\equiv2k,
\qquad
\frac{B_\Delta}{3}\equiv gk.
\tag{3.6}
\]

(2.4) 的第二项含 `3^4`，因此

\[
\frac{\widehat{\mathscr D}_{63}}9
\equiv2g\pmod3,
\tag{3.7}
\]

进而

\[
\boxed{
\frac{Y_d}{9}
\equiv2s\pmod3.}
\tag{3.8}
\]

另一方面，直接把 `a_2≡a_3≡K≡0 mod3` 代入 primitive additive carrier formula，可得

\[
\widehat{\mathcal T}_2\equiv(-1)^m=s\pmod3.
\tag{3.9}
\]

因 `9|Y_d`，由 (2.2)

\[
\boxed{X_d\equiv s\pmod3.}
\tag{3.10}
\]

现在进入 third-order canonical recursion。写

\[
X_d\equiv x,
\qquad
Y_d=9y,
\qquad
K=3k.
\]

checker 从 exact `G_<,G_>,H_2,H_3` 重建并抽取 `3^6` initial form，得到

\[
\boxed{
\frac{\mathscr N_{63}^{(3)}}{3^6}
\equiv
yk^2(x+s)(2y+sk^2)
\pmod3.}
\tag{3.11}
\]

代入

\[
x=s,\qquad y=2s,\qquad k^2=1
\]
后，三因子均为 units。因此

\[
\boxed{
v_3(\mathscr N_{63}^{(3)})=6.}
\tag{3.12}
\]

所以本通道只要 `3∤f`，fixed `3` 对 third-order positive primitive carrier 的贡献是偶数，不能承担 odd spill parity。

因此唯一逃逸是

\[
\boxed{3\mid f.}
\tag{3.13}
\]

这已经把第一个 odd-`3` channel 完全压回旧 f-denominator sheet。


**正确更正。** primitive quadratic 的 depth-six form 为
\[
H_2^{[6]}=xyk^4-y^2k^2,
\quad H_3^{[6]}=xy^2k^2,
\]
所以 exact recursion 给
\[
\frac{N_3}{3^6}\equiv yk^4+2sH_2^{[6]}+2H_3^{[6]}\pmod3.
\]
代 `x=s` 后恒为零，特别地代 `y=2s,k²=1` 仍为零。
因此当前严格结论只有 `v3(N3)>=7`；旧 (3.11)–(3.13) 不能使用。
没有重新确定下一 digit 之前，不能说 `3` 对 spill parity 中性。

---

## 4. `失效/降级`：旧 `a_3`-shallow exact depth `10`

现在固定另一通道

\[
\boxed{
v_3(a_3)=1,
\qquad
v_3(a_2)\ge2.}
\tag{4.1}
\]

写

\[
\zeta=\frac{a_3}{T}=3z,
\qquad z\in\mathbf Z_3^\times,
\]

并抽出 guaranteed `3^2`：

\[
K=9k.
\tag{4.2}
\]

这里 `k mod3` 可以为 `0,1,2`；若 `k=0`，只是说明 `K` 实际深于 `3^2`。

central depth 由

\[
2K-9=9(2k-1)
\]
读取。因此

\[
\boxed{
v_3(2K-9)=2
\iff
k\not\equiv2\pmod3.}
\tag{4.3}
\]

先处于 generic central sector

\[
3\nmid f,
\qquad
v_3(2K-9)=2.
\tag{4.4}
\]

仍由 (3.5) 有 `c_u≡gomega mod3`。由 (2.6)，此时

\[
v_3(B_\Delta)=1,
\]

并从 (2.4) 得

\[
\boxed{v_3(\widehat{\mathscr D}_{63})=3.}
\tag{4.5}
\]

令

\[
y:=\frac{Y_d}{27}\pmod3.
\]

精确 normalized residue 为

\[
\boxed{
y=s(2k-1)z.}
\tag{4.6}
\]

同 §3，仍有

\[
X_d\equiv s\pmod3.
\tag{4.7}
\]

本通道中 checker 对 third recursion 抽取 `3^10` initial form。若

\[
X_d\equiv x,
\qquad
Y_d=27y,
\qquad
K=9k,
\qquad
\zeta=3z,
\]

则

\[
\boxed{
\frac{\mathscr N_{63}^{(3)}}{3^{10}}
\equiv
-y(k^2-k+1)\{z(k+1)-sy\}
\pmod3.}
\tag{4.8}
\]

代入 (4.6)：

\[
z(k+1)-sy
=z\{(k+1)-(2k-1)\}
=z(2-k).
\tag{4.9}
\]

在 generic central sector `k=0` 或 `1`：

\[
k^2-k+1\equiv1,
\qquad
2-k\not\equiv0,
\]

且 `y,z` 均为 units。因此

\[
\boxed{v_3(\mathscr N_{63}^{(3)})=10.}
\tag{4.10}
\]

同样是偶数。

所以第二通道中 fixed `3` 只有两种逃逸：

\[
\boxed{
3\mid f
\quad\text{或}\quad
v_3(2K-9)\ge3.}
\tag{4.11}
\]

第二个条件等价于

\[
K/9\equiv2\pmod3,
\]
即一个真正的 extra-central `3`-adic sheet，而不是新的 terminal coefficient root。


**正确更正。** 重建的 depth-ten recursion 在 `x=s` 后同样恒为零：
\[
\boxed{N_3/3^{10}\equiv0\pmod3.}
\]
此结论在 displayed generic central `k=0,1`、`y=s(2k-1)z` 下成立，
但没有确定更高赋值的 parity。旧 (4.8)–(4.11) 的 exact-depth / frontier
推论不能继续使用；当前只能得到 `v3(N3)>=11`。

---

<a id="fixed3-corrected-depths"></a>

## 5. `已严格完成`：exact sphere/plane 的新 depth `8/12`

本节使用真实减向 transport 的 `H2,H3`，完全重建上一节失效后的下一层。
记 `zeta=a3/T`，引入 `3`-unit 的有理尺度

```math
\vartheta:=\frac{c_u}{g\omega},\qquad
a:=2^mc_u^2g^2T,\qquad t:=2^{2M+2}.
```

`a` 只在本节作归一化尺度；不与 numerator digits `a2,a3` 混用。
由原 sphere、primitive plane 和 source rows，

```math
H_0^2-g^2a_3^2=c_Q^2 5^{2d}N_0,\qquad
H_0=\frac{c_uT(K+\zeta)}\omega,\qquad
Q_0=c_Qq,\qquad 5^\lambda q=g\omega-c_u,\qquad\lambda+d=m.
```

此外 endpoint (16.291) 配合 `XY=5^{-nu5}N0`、`nu5=m-3d` 给
`That_2=aR0-5^m Q0^2 N0`。于是

```math
\frac{5^mQ_0^2N_0}{a}
=\frac{(g\omega-c_u)^2}{c_u^2g^2}
 \left[\frac{c_u^2(K+\zeta)^2}{\omega^2}-g^2\zeta^2\right]
=(1-\vartheta)^2(K+\zeta)^2
 -\left(\frac{1-\vartheta}{\vartheta}\right)^2\zeta^2.
```

这条等式已经使用真实 sphere，不能换成互不相关的 parent units。
从 (2.4)–(2.5) 同时得到

```math
y:=Y_d/a=U[U-\zeta-\vartheta(K+\zeta)]-\frac{63}{16}K^2,\qquad U=2K-9,
```

```math
w:=(X_d+Y_d)/a
=R_0-(1-\vartheta)^2(K+\zeta)^2
 +\left(\frac{1-\vartheta}{\vartheta}\right)^2\zeta^2,\qquad x:=X_d/a=w-y.
```

同一归一化还直接恢复 actual quartic point：

```math
J=J_0-y/U=\vartheta(K+\zeta)-\zeta,\qquad
R=R_0-w=(1-\vartheta)^2(K+\zeta)^2
 -\left(\frac{1-\vartheta}{\vartheta}\right)^2\zeta^2.
```

代入 `Phi=J(J+2zeta)(K-J)^2-R(J+zeta)^2` 精确为零：两项都等于

```math
[\vartheta^2(K+\zeta)^2-\zeta^2]\,(1-\vartheta)^2(K+\zeta)^2.
```

因此这里的 `x,y`、四阶 hierarchy 与原十进制 coefficient plane 同源。

真实第三阶整数的同源系数为

```math
A=5^mB^2=ta,\qquad C=2^{2M+10}5^2 11=70400t,\qquad
D=2^{4M+17}5^2 11^2=24780800t^2.
```

因此定义下列整数系数多项式（checker 独立检验其 `350` 项皆在 `Z`）：

```math
P_3(K,\zeta,\vartheta):=\vartheta^6
\left[64(81xG_<+2yG_>)+70400\mathcal H_2(x,y)+24780800\mathcal H_3(x,y)\right].
```

homogeneity 给出 exact identity

```math
\mathscr N_{63}^{(3)}=T^6t^2a^3\vartheta^{-6}P_3.
```

右侧除 `P3` 外全部为 `3`-unit，故 `v3(N3)=v3(P3)`。
这只重写同一个 `N3` parent，没有新增一份独立 inert budget。

**`a2`-shallow、`3∤f`。** 此时 `K=3k`、`zeta=9z`，`k` 为 unit，
而 `f=g omega+cu` 为 unit 等价于 `vartheta=1+3h`。符号全系数核对给

```math
P_3(3k,9z,1+3h)\in3^8\mathbf Z[k,z,h],\qquad
\frac{P_3(3k,9z,1+3h)}{3^8}\equiv-k^8\pmod3.
```

`k` 为 unit 使该初项非零，因此严格得到

```math
\boxed{v_3(\mathscr N_{63}^{(3)})=8.}
```

这对任意更深 `a3` 都成立，不能用旧失效 depth `6` 替代这份重建。

**全部 `a3`-shallow。** 写 `K=9k`、`zeta=3z`，`z` 为 unit。
`k` 允许任意 residue，故包含 generic 和 deeper-central。
`3∤f` 时写 `vartheta=1+3h`，符号核对给

```math
P_3(9k,3z,1+3h)\in3^{12}\mathbf Z[k,z,h],\qquad
\frac{P_3(9k,3z,1+3h)}{3^{12}}\equiv(k+1)^4z^4+1\pmod3.
```

若 `k=-1 mod3`，右侧为 `1`；其它两类为 `2`，都非零。
`3|f` 时写 `vartheta=-1+3h`，同样有

```math
P_3(9k,3z,-1+3h)\in3^{12}\mathbf Z[k,z,h],\qquad
\frac{P_3(9k,3z,-1+3h)}{3^{12}}\equiv1\pmod3.
```

所以两种 `f` 类型统一满足

```math
\boxed{v_3(\mathscr N_{63}^{(3)})=12\quad\text{on every a3-shallow channel}.}
```

上述 `k,z,h` 的求值允许在 `Z_(3)={r/s:3∤s}`：例如 `z=a3/(9T)`、
`h=(vartheta-1)/3` 或 `(vartheta+1)/3` 通常不是普通整数。
全系数多项式恒等式、整除与 modulo `3` 初项在这个域直接保持有效。
这些是无界参数的符号多项式证明。最后只枚举 `k,z` 的三个/两个
residue 来确认显式初项非零，并未用 bounded decimal search 替代证明。

## 6. 更新后的 fixed-`3` frontier

§5 的 depth `8/12` 均为偶数。结合 endpoint 的 dichotomy，fixed `3`
若给真实 third-parent 的 odd inert parity，**只能**来自

```math
v_3(a_2)=1,\qquad v_3(a_3)\ge2,\qquad3\mid f.
```

这一片仍有精确下一层条件。令 `K=3k`、`zeta=9z`、`vartheta=-1+3h`，
其中 `h=f/(3g omega)`，则

```math
P_3(3k,9z,-1+3h)\in3^9\mathbf Z[k,z,h],\qquad
\frac{P_3(3k,9z,-1+3h)}{3^9}\equiv k^7[k(h-1)+1]\pmod3.
```

若括号非零，`v3(N3)=9` 为奇数；若为零，进入下一层，不把消去误写成偶 parity。
这里没有断言满足这些局部条件的原十进制候选存在。

**下一真实 source 层（`已严格完成`）。** 定义实际整数

```math
\mathscr A_3:=Ug\omega-Kc_u
=5^\lambda qU+c_u(K-9)>0.
```

它来自原 denominator/source rows，且满足

```math
\omega B_\Delta=T\mathscr A_3-fa_3,\qquad
\frac{\mathscr A_3}{9g\omega}=k(1-h)-1.
```

所以 contact 自动给 `v3(A3)>=2`；exact depth `2` 等价于上一项非零，
从而给 `v3(N3)=9`。这里 `A3` 与 `B_delta`、`F63` 属于同一 source chain，
没有独立第二份高度预算。

若 `v3(A3)>=3`，令 `r=A3/(27g omega) in Z_(3)`，则

```math
\vartheta=2-\frac3k-\frac{9r}k.
```

`k` 为 unit；清除它的分母后得到另一条全系数整数初项：

```math
k^{12}P_3\left(3k,9z,2-\frac3k-\frac{9r}k\right)
\in3^{10}\mathbf Z[k,z,r],
```

```math
\frac{k^{12}P_3(3k,9z,2-3/k-9r/k)}{3^{10}}
\equiv k^{18}\{z(k-1)-k^2-kr-1\}\pmod3.
```

单位 `k` 满足 `k^2=k^12=k^18=1 mod3`，故下一 residue 为

```math
\ell:=z(k-1)-kr+1\pmod3.
```

若 `ell!=0`，严格得到 `v3(N3)=10`，这个无界子片不能供应 fixed-`3` odd parity。
若 `ell=0`，得到 depth 至少 `11`；下面对真实 `k=1` word 再抽取一层。
例如以下两个有实质参数范围的子片已排除 fixed-`3` odd supplier：

```math
\begin{aligned}
v_3(\mathscr A_3)\ge4,\ k\equiv1\pmod3
&\Longrightarrow v_3(\mathscr N_{63}^{(3)})=10,\\
v_3(\mathscr A_3)\ge4,\ k\equiv2\pmod3,\ z\not\equiv2\pmod3
&\Longrightarrow v_3(\mathscr N_{63}^{(3)})=10.
\end{aligned}
```

`k≡1` 包含全部 `a2/3≡1`，`z=a3/(9T)` 允许任意更深 third digit。

**`k=1` word 的 depth `11` 初项（`已严格完成`）。** 这一 word 上
`ell=0` 等价于 `r=1 mod3`，故写 `k=1+3j,r=1+3s`。从同一个
`350` 项 `P3` 的全系数展开得到

```math
\frac{(1+3j)^{12}P_3\left(3(1+3j),9z,
2-\frac3{1+3j}-\frac{9(1+3s)}{1+3j}\right)}{3^{11}}
\equiv1-s+z(j-1)\pmod3.
```

分子全部系数整除 `3^11`，且 `(1+3j)^12` 为 unit。因此初项非零
严格给 `v3(N3)=11`，可以支付 odd parity；初项为零只给 `v3(N3)>=12`，
没有确定更高奇偶。`j,z,s` 同样允许取 `Z_(3)` 中的值。
两个允许 shared-`7` 的 `eta=2` slot 的真实 sphere 已强迫 `k=1 mod3`，
故该公式直接适用于它们，见
[`fixed3-f-contact-orientation.md` §9](fixed3-f-contact-orientation.md#9-已严格完成实际-source-a3-的-non-3-surcharge-与-pool-接口)。

剩余 contact 必须是 exact `A3` depth `2`，或通过更深 `ell=0` resonance，
才能承担 odd parity；上述 depth `11` 子片确实仍可供应它，
尚无统一整数上界或 prime-product 矛盾。

[`fixed3-exception-collapse.md`](fixed3-exception-collapse.md) 的
`eta=1` high-factor 矛盾独立排除了该终端类型的此片，因而该类型的
third-parent parity 必须由 non-`3` supplier 承担。

其它类型仍可选择这条 fixed `3` contact、old height/source/target pool
或 external label。没有独立-prime product bound，A2 仍为 `待证`。

---

## 7. verification

```bash
uv run python scripts/exact-lift/a2-only/check_a2_fixed3_terminal_spill.py
```

checker 从 canonical universal descendant cubic、Euclidean quotient 与实际减向
transport 重建 `G_<,G_>,H2,H3`，先保留旧 `6/10` forms 的失败审计，
再检验 exact sphere/plane normalization 的全系数整除、新 `8/12/9` 初项及
真实 source `A3` 的下一 collision `10/11` 初项。
输出只关闭上文明确的 fixed-`3` parity 切片，不关闭 A2。
