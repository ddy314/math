# A2 fixed `3` 的 `f`-contact orientation selector

> **依赖：** `fixed3-terminal-spill.md`、`fixed3-exception-collapse.md`、`endpoint-lattice.md` §§16.7、16.11、16.57–16.59，以及 `primitive-reduction.md`。
>
> **严格状态：已严格完成（orientation selector、`eta=2` 八型压缩及 §9 的明确支持界/局部证书），待证（剩余全局整数 contact）。** `f`-contact 会把 Gaussian high-2 side 完全定向：`e3=1` 必在正号槽，`e3=3` 必在负号槽，并固定 source-unit 的模 `3` 相位。`eta=1` 唯一 odd-`3` 类型因此排除；§8 对无界 `eta=2` family 强迫 `d<=2,e3=1,slot=+`，只剩八型。§9 的实际 source 接口与局部 Hensel 兼容不能声明十进制解存在，也未排除无界整数核心；A2 仍为 `待证`。

---

## 1. `a_2`-shallow odd-`3` channel

固定 `Z≡1 mod4` orientation 的第二个 odd-`3` endpoint channel：

\[
\boxed{
v_3(a_2)=1,
\qquad
v_3(a_3)\ge2.}
\tag{1.1}
\]

写

\[
a_2=3a,
\qquad 3\nmid a.
\tag{1.2}
\]

`endpoint-lattice.md` §16.11 已严格证明

\[
\boxed{
e_3:=v_3(k_h)\in\{1,3\},}
\tag{1.3}
\]

同时 sphere norm 的总 `3`-depth为 `4`。令 high-2 factor 的方向为

\[
\boxed{
H_0+\varepsilon Y_2=\frac{g^2k_h}{2},
\qquad
\varepsilon\in\{-1,+1\},}
\tag{1.4}
\]

以及

\[
Y_2=a_2c_Q5^d.
\tag{1.5}
\]

则另一个 low-2 factor 是 `H_0-epsilon Y_2`，两者 `3`-进深度精确为

\[
\boxed{
\bigl(v_3(H_0+\varepsilon Y_2),
      v_3(H_0-\varepsilon Y_2)\bigr)
=(e_3,4-e_3).}
\tag{1.6}
\]

---

## 2. 假设 `3|f` 后的两个 normalized units

现在进入旧 fixed sheet

\[
\boxed{3\mid f.}
\tag{2.1}
\]

由 `primitive-reduction.md`

\[
H_0=c_uW_q,
\qquad
\alpha=\omega W_q,
\qquad
f=g\omega+c_u.
\tag{2.2}
\]

当前 `a_2`-shallow channel 中

\[
\alpha=TK+a_3,
\qquad
\frac\alpha3\equiv a\pmod3,
\tag{2.3}
\]

因为 `K≡a_2 mod9`、`a_3` 至少含 `3^2`，且 `T=10^m≡1 mod3`。

由 (2.1),(2.2)，`g,omega,c_u` 都是 `3`-units 且

\[
\frac{c_u}{\omega}\equiv-g\pmod3.
\tag{2.4}
\]

所以

\[
\boxed{
\frac{H_0}{3}\equiv-ag\pmod3.}
\tag{2.5}
\]

定义

\[
\boxed{B:=c_Q5^d.}
\tag{2.6}
\]

则

\[
\boxed{
\frac{Y_2}{3}\equiv aB\pmod3.}
\tag{2.7}
\]

这里 `B` 是 unit，因为 odd-`3` channel 已有 `3∤c_Q`。

---

## 3. exact factor depths 决定 `epsilon B/g`

### 3.1 `e_3=1`

此时 high-2 factor 深度为 `1`，另一个 factor 深度为 `3`。因此

\[
3^2\mid
\frac{H_0-\varepsilon Y_2}{3}.
\]

特别地模 `3`：

\[
-ag-\varepsilon aB\equiv0.
\]

约去 unit `a`：

\[
\boxed{\varepsilon B\equiv-g\pmod3.}
\tag{3.1}
\]

### 3.2 `e_3=3`

现在 high-2 factor 本身深度为 `3`，所以

\[
3^2\mid
\frac{H_0+\varepsilon Y_2}{3}.
\]

由 (2.5),(2.7)：

\[
-ag+\varepsilon aB\equiv0,
\]

即

\[
\boxed{\varepsilon B\equiv g\pmod3.}
\tag{3.2}
\]

为统一记号，令

\[
\sigma=
\begin{cases}
-1,&e_3=1,\\
+1,&e_3=3.
\end{cases}
\]

则 (3.1),(3.2) 可写成

\[
\boxed{\varepsilon B\equiv\sigma g\pmod3.}
\tag{3.3}
\]

---

## 4. source `Q_0` identity 强迫唯一 orientation

另一方面，source split 给

\[
f=5^\lambda q+2c_u,
\qquad
Q_0=c_Qq=5^M+2^mgc_u,
\qquad
\lambda=m-d.
\tag{4.1}
\]

由 `3|f`：

\[
q\equiv(-1)^\lambda c_u\pmod3.
\tag{4.2}
\]

代入第二式：

\[
c_Q(-1)^\lambda c_u
\equiv
(-1)^M+(-1)^mgc_u
\pmod3.
\]

约去 `c_u`，再用 `lambda=m-d` 与 `B=c_Q(-1)^d`：

\[
\boxed{
B\equiv g+\delta c_u^{-1}\pmod3,}
\tag{4.3}
\]

其中

\[
\boxed{
\delta:=(-1)^{M+m}=(-1)^{m-\eta},
\qquad
\eta=2m-M.}
\tag{4.4}
\]

把 (3.3) 写成

\[
B\equiv\sigma\varepsilon g.
\]

与 (4.3) 比较：

\[
\delta c_u^{-1}
\equiv
(\sigma\varepsilon-1)g.
\tag{4.5}
\]

左边是 unit，因此右边不能为零。于是

\[
\boxed{\sigma\varepsilon=-1.}
\tag{4.6}
\]

这立即给出本文主 selector：

\[
\boxed{
\begin{array}{c|c}
e_3&\varepsilon\\ \hline
1&+1\\
3&-1
\end{array}}
\tag{4.7}
\]

也即

\[
\boxed{
e_3=1\Longrightarrow\text{positive high-2 slot},}
\tag{4.8}
\]

\[
\boxed{
e_3=3\Longrightarrow\text{negative high-2 slot}.}
\tag{4.9}
\]

所以 `f`-contact 并不是一个可同时出现在两张 Gaussian sheets 上的自由异常；它严格选中其中一张。

---

## 5. 同时固定三个 source-unit phases

由 (4.6)，`sigma epsilon=-1`，所以 (3.3) 进一步给

\[
\boxed{B\equiv-g\pmod3.}
\tag{5.1}
\]

而 (4.5) 化成

\[
\delta c_u^{-1}\equiv g,
\]
故

\[
\boxed{gc_u\equiv\delta=(-1)^{m-\eta}\pmod3.}
\tag{5.2}
\]

再由 `f=gomega+c_u≡0 mod3`：

\[
\boxed{
\omega\equiv-\delta
=(-1)^{m-\eta+1}\pmod3.}
\tag{5.3}
\]

因此 general `a_2`-shallow `f`-contact 不仅选择 slot，还把

\[
(c_Q5^d,\ gc_u,\ \omega)
\]

的全部 first `3`-adic unit phase固定下来。

用 `S=2^{M+m+1}gc_Q5^d`、`beta=Somega` 还可校验

\[
S\equiv\delta,
\qquad
\boxed{\beta\equiv-1\pmod3.}
\tag{5.4}
\]

这与 §16.11 已有 `3∤beta` 完全一致，而不是新的矛盾；故本文不把 (5.4) 误写成 closure。

---

## 6. `eta=1` 旧异常成为立即推论

`fixed3-exception-collapse.md` 中 `eta=1` 唯一 odd-`3` survivor 是

\[
(d,c_Q,k_h,slot)=(2,7,3,-).
\tag{6.1}
\]

这里

\[
e_3=v_3(k_h)=1,
\qquad
\varepsilon=-1.
\]

但 (4.7) 对 `e_3=1` 强迫 `epsilon=+1`。矛盾。

因此旧结论

\[
\boxed{
\eta=1,\ a_2\text{-shallow}
\Longrightarrow 3\nmid f}
\tag{6.2}
\]

现在不再依赖该单点的专门 high-factor 数值 `3g^2/2`；它只是 general orientation selector 的一个特例。

---

## 7. revised fixed-`3` frontier

`a_2`-shallow `f`-contact 的一般开放集从

\[
\eta\ge2,\quad e_3\in\{1,3\},\quad\varepsilon\in\{\pm1\}
\]

严格缩成

\[
\boxed{
\begin{cases}
e_3=1,\ \varepsilon=+1,\\
\text{or}\\
e_3=3,\ \varepsilon=-1,
\end{cases}}
\tag{7.1}
\]

并附带 (5.1)–(5.4) 的完整 mod-`3` source phase。

这还不是空集。后续若继续局部关闭该 sheet，应把 (5.1)–(5.4) 与 `endpoint-lattice.md` 的 high-2 slot natural representative、`C` phase 或 Gaussian composition identity 联立，而不是继续机械提升 `f mod 9`。

**2026-09-30 方向更正：**旧称 `a3`-shallow f-contact 能供应 odd third-depth
的结论为 **失效/降级**。
[`fixed3-terminal-spill.md` §5](fixed3-terminal-spill.md#fixed3-corrected-depths)
从真实 source rows 重建了全部 `a3`-shallow exact depth `12` 与
`a2`-shallow f-unit exact depth `8`。可能供应 fixed `3` odd parity 的只剩
本文 `a2`-shallow f-contact：其正整数 `A3=Ug omega-Kcu` exact depth `2`
给 `N3` depth `9`，更深 contact 用该文 §6 的实际 depth-`10/11` initial forms 继续分裂。
不能因某一初项消去就要求独立 non-`3` supplier。

A2 仍为 `待证`。

---

<a id="eta2-contact-slots"></a>

## 8. `已严格完成`：`eta=2` contact 只剩八个 positive slot 类型

固定 `eta=2m-M=2`，`m,M` 不设上界。endpoint (16.1) 给

```math
G=\frac{c_Q\chi}{w}\,2^{-3}5^{d-3},\qquad
\chi=1+H/5^{M-1}>1.
```

若 `d>=5`，由 `cQ>=3,w<843/1000` 得
`G>(3/8)5^2/(843/1000)>1212/125`，超过全部 high-2 slots，故 `d<=4`。
对 `d=1,...,4`，(16.2) 给以下严格有界的奇整数 product：

```math
16\,5^{3-d}\,s_\pm\frac{837}{1000}\frac{19}{20}
<c_Qk_h<
16\,5^{3-d}\,s_\pm\frac{843}{1000},
```

其中下/上界分别取 endpoint 的 `s±` 下/上端点：
`s- in (393/125,1607/500)`、`s+ in (2389/500,606/125)`。
逐个因子分解这些有界 products，先施加 `cQ=3 mod4`、`3∤cQ`、`5∤cQ`、
`kh` 奇与 `v3(kh) in {1,3}`，共有 `27` 个粗类型。
再施加 Gaussian norm 的严格支持条件 `5∤kh`、
`p|kh,p=3 mod4 =>p=3`，以及本文 selector，恰剩

| `d` | `(cQ,kh,slot)` |
| --- | --- |
| `1` | `(7,219,+)`, `(31,51,+)`, `(511,3,+)`, `(523,3,+)`, `(527,3,+)`, `(539,3,+)` |
| `2` | `(103,3,+)`, `(107,3,+)` |

所以这个完整无界 source family 满足

```math
\boxed{\eta=2,\ a_2\text{-shallow},\ 3\mid f
\Longrightarrow d\le2,\quad v_3(k_h)=1,\quad\varepsilon=+1.}
```

特别地，`eta=2` 的全部 negative high-2 / `e3=3` contact sheets 与全部
`d>=3` contact 已严格排除。八型的 `N3` 最终 parity、其它 `eta` 与 non-`3`
supplier 仍待证；这是有限 slot 分类覆盖无界 `m,M`，不是原候选有限枚举。

<a id="source-a3-parity-surcharge"></a>

## 9. `已严格完成`：实际 source `A3` 的 non-`3` surcharge 与 pool 接口

本节的严格结论是下表的必要条件与局部兼容证书；剩余原十进制整数问题仍为 `待证`。

| 对象 | 当前严格结论 | 作用域 |
| --- | --- | --- |
| 正 source `A3` | 明确 binary / even-`3` 子片强迫 non-`3` inert 奇数因子，且异于 `pC` | §9.2 |
| saturated denominator / additive / descendant | 四对象 gcd 至多 `11`；再加 descendant 时为 `1` | §9.4.1 |
| unsaturated `q/f` / descendant | 支持至多 `43·109` / `7`，共同深度至多 `1` | §9.4.2 |
| inert height / descendant | 支持至多 `7·12569471`；再与 outer overlap 联立只剩 `7` | §9.4.3 |
| shared-`7` 的 `eta=2` slice | 八型缩到两个 `d=1` 型、`m=2 mod3` | §9.5.1 |
| 原 source `3/7` charts | 有无限局部 lift，包含 odd third-depth；不能局部统一关闭 | §§9.5.2–9.5.3、9.7 |
| 两型的全局整数恢复 | 每个 `(m,cu,g)` 至多一组 numerator pair；无界 `m` 未排除 | §9.6 |

### 9.1 作用域与唯一实际归一化

所有结果沿用 `Z=1`、`a2`-shallow f-contact 与真实 high-2 allocation；
仅 §9.5 起专门限制为 `eta=2` shared-`7` 的两个 surviving slots。
`A3` 始终指正 source 整数 `Ug omega-Kcu`，不与第三分子 `a3` 混用。

`theta=cu/(g omega)`、`a=2^m cu²g²T` 及 actual `x,y,w,J,R,P3`
的唯一完整推导在 [`fixed3-terminal-spill.md` §5](fixed3-terminal-spill.md#fixed3-corrected-depths)。
特别是 `J=J0-y/U,R=R0-w`；本文所有 prime-power evaluations 均使用该减向。
旧 plus-transport 的高阶 parity 链已降级，不能借其旧 `6/10` 初项或
quartic positive-carrier orientation 补上本节缺口，见
[`crt-descent-ledger.md` 方向审计](crt-descent-ledger.md#transport-direction-audit)。
下文整数 `Theta_H=(5^(3m-3)+cQ cu)/g` 与这个有理 `theta` 是不同对象。
所有 parent 与 source carrier 都接回同一十进制 coefficient plane；
没有因改写 hierarchy 而新增独立高度预算。

### 9.2 source 奇数因子及与 `pC` 的分离

沿用 `fixed3-terminal-spill.md` 的正整数
`A3=Ug omega-Kcu`，本节仍在 `Z=1`、`a2`-shallow f-contact 及真实 high-2 allocation。
原 endpoint 的 `Wq=3Z mod4`、`H0=cu Wq`、`cu=1 mod4` 给 `H0=3 mod4`。
又 `B=cQ5^d=3 mod4`，而 high factor `H0+epsilon Y2=g^2 kh/2` 被 `8` 整除，
所以

```math
e_3=1,\ \varepsilon=+1\Longrightarrow a_2\equiv3\pmod4,\qquad
e_3=3,\ \varepsilon=-1\Longrightarrow a_2\equiv1\pmod4.
```

`omega` 为 odd，因为它整除 odd 拼接分子 `alpha=TK+a3`。
`K=9*10^M+10a2`、`M>=11` 给 `K/2=a2 mod4`，`U=3 mod4`。
`g=2^(t-1)rho`、`t>=3` 给 `v2(g)>=2`。因此

```math
\frac{\mathscr A_3}{2}
\equiv U\frac g2\omega-\frac K2c_u\pmod4
\in\{1,3\},\qquad v_2(\mathscr A_3)=1.
```

它等于 `3 mod4` 恰在以下两片：

```math
\bigl(v_2(g)=2,\ e_3=1,\varepsilon=+1\bigr)
\quad\text{or}\quad
\bigl(v_2(g)\ge3,\ e_3=3,\varepsilon=-1\bigr).
```

设其中一片还满足 `v3(A3)` 为偶数。除去全部 binary 与 `3` content 的正整数

```math
\mathscr A_3^\circ:=\frac{\mathscr A_3}{2\,3^{v_3(\mathscr A_3)}}
\equiv3\pmod4,\qquad\gcd(\mathscr A_3^\circ,6)=1
```

必含某枚 `r!=3,r=3 mod4` 到奇数次。这是一个实际 source carrier 的
parity consequence。特别在 `v3(A3)=2` 时，`N3` 的 depth `9` 可由 fixed `3`
支付，但上述片仍另外强迫一枚 non-`3` inert supplier。`eta=2` 的八型中全为
`e3=1/+`，所以 `v2(g)=2,v3(A3)=2` 给这一完整无界子片的 surcharge。
没有把 `N3` 和 `A3` 自动视为两份独立高度预算。

**与 `pC` 分离。** 在 genuine external shared-outer / descendant 的唯一
`pC=24303427940647` 点，
`K=21805672591624,zeta=9250192938088 mod pC`。
真实 `F=0` 给 `J=J0`；上一专题的 actual source identity 给

```math
\vartheta=\frac{J_0+\zeta}{K+\zeta}
\equiv18367788003561\pmod{p_C},\qquad
\frac{\mathscr A_3}{g\omega}=U-K\vartheta
\equiv11023269555785\not\equiv0\pmod{p_C}.
```

checker 同时核对该 `vartheta` 在真实 `y,w` 归一化上为零。
依赖 [`outer-external-q4-root-split.md`](outer-external-q4-root-split.md)
的共同点唯一性与 genuine unit 假设，严格得到 `pC∤A3`。
因此本节强迫的 `r` 必与 terminal label `pC` 不同；尚未证明它与全部其它 old pools 分离。

### 9.3 prime-power gcd 与 height 接口

primitive source 已给
`gcd(cu,qf g omega)=1`。令 `D3=2g omega-cu`，则

```math
\begin{aligned}
\gcd(\mathscr A_3,q)&=\gcd(q,K-9),\\
\gcd(\mathscr A_3,f)&=\gcd(f,3(K-3)),\\
\gcd(\mathscr A_3,\omega)&=\gcd(\omega,K),\\
\gcd(\mathscr A_3,g)&=\gcd(g,K).
\end{aligned}
```

第一式用 `g omega=5^lambda q+cu`；第二式用 `g omega=f-cu`；
后两式直接模 `omega,g`。这些是完整 prime-power gcd 等式。
还有

```math
\mathscr A_3=KD_3-9g\omega,\qquad
\gcd(D_3,g\omega)=1,\qquad
\gcd(\mathscr A_3,D_3)=\gcd(9,D_3)\mid9.
```

令 third-block 整数 `H_A=9Tg omega+D3 a3`；exact Euclidean identity 为

```math
D_3\alpha-T\mathscr A_3=\mathscr H_A.
```

所以对每个 `p∤30`，`D3,T` 在 `p|A3` 时均为 units，

```math
\min\{v_p(\mathscr A_3),v_p(\alpha)\}
=\min\{v_p(\mathscr A_3),v_p(\mathscr H_A)\}.
```

任何 non-`3` inert height prime `r|Wq,A3` 还满足 `r∤omega`：
否则第三个 gcd 式给 `r|K`，`alpha=omega Wq` 给 `r|a3`，`H0=cu Wq` 与
sphere 给 `r|N0`；惰性 norm 再给 `r|b2`，与 height theorem 的
`r∤gcu cQ` 矛盾。因此这里的 height overlap 被同一个 `H_A` 逐 prime-power 读取。

### 9.4 固定支持界

#### 9.4.1 共同 saturation 的单层 `11` 上界

本节的实际 source normalization
还给出一个覆盖无界参数的完整 gcd 结论。令

```math
G_A:=\gcd(\mathscr A_3,\widehat{\mathcal T}_2,\mathscr L_{23},qf),
\qquad \mathscr L_{23}=9T/2+a_3.
```

在当前 `Z=1,a2`-shallow f-contact 中，primitive additive carrier
`That2` 为 `2,5` 单位；`K,zeta=0 mod3` 与 `theta=-1 mod3` 又使
`w=That2/a=55=1 mod3`。因此 `gcd(G_A,30)=1`。
对任意 `p∤30`，设 `p^j|G_A`。primitive 假设使
`a=2^m cu²g²T`、`g omega`、`cu` 均为 `p`-进单位。
由于 `gcd(q,f)=1`，完整 `p^j` 必落在其中一侧。
`q` 侧给 `theta=1 mod p^j,K=9 mod p^j`；`f` 侧给
`theta=-1 mod p^j,K=3 mod p^j`。真实减向表达式满足

```math
\begin{aligned}
w(K,\zeta,1)=-26-18\zeta+(K-9)(K-9-4\zeta),\\
w(K,\zeta,-1)=-26-18\zeta-3(K-3)(K+9+4\zeta).
\end{aligned}
```

`p^j|L23` 给 `zeta=-9/2 mod p^j`，而 `p^j|That2` 给 `w=0`。
两侧都得到 `p^j|55`。故

```math
\boxed{G_A\mid11.}
```

这只限制所列四对象的共同 saturation，不是整个 `qf` 池的支持结论。
该唯一一层还不能进入 descendant common：在两种 `11` 点，真实
`y=Yd/a` 分别等于

```math
y(9,-9/2,1)=-3^4\,47/16\equiv2\pmod{11},\qquad
y(3,-9/2,-1)=-3^4\,7/16\equiv1\pmod{11}.
```

上述 `16,a,g omega,cu,T` 在 `11` 上均为单位；
`GDelta|widehat D63`、`Yd=g 2^m widehat D63` 因而与这些单位值矛盾。
结合 `GDelta|That2`，严格得到

```math
\boxed{\gcd(\mathscr A_3,\mathscr L_{23},qf,G_\Delta)=1.}
```

所以本文 source surcharge 的 non-`3` supplier 无法同时复用完整
denominator saturation 与 descendant common。未饱和的 `q/f` 接触、
仅单侧 outer、height overlap 等仍不受这个四对象结论自动排除。

#### 9.4.2 未饱和 denominator / descendant 交集

不加 `L23` 条件仍有严格
的固定支持上界。若 `p∤30`、`p^j|A3,q,GDelta`，上述单位推导使
`K=9,theta=1 mod p^j`。由 `GDelta|That2,Yd`，真实 `w,y` 都为零，
而它们的差在该 source sheet 上恒为

```math
y(9,\zeta,1)-w(9,\zeta,1)=-4687/16=-43\cdot109/16.
```

若 `p^j|A3,f,GDelta`，则 `K=3,theta=-1 mod p^j`，
`y(3,zeta,-1)=-567/16=-3^4\cdot7/16`。结合当前 `GDelta` 为 `30` 单位，得

```math
\boxed{\gcd(A3,q,G_\Delta)\mid43\cdot109,\qquad
       \gcd(A3,f,G_\Delta)\mid7.}
```

两侧 surviving depth 都至多一层。`109=1 mod4` 不供应 inert parity。
`q` 侧还由 `w=0` 得 `zeta=-13/9`；此时 `R0=0`，实际 outer evaluations 为

```math
\Phi_2=-784/9,\qquad \Phi_4=1000/9.
```

它们在 `43,109` 上都为单位。因此 `A3` 的 `q`-side descendant overlap
不能同时支付任何一侧 outer cofactor。`f` 侧的 `7` 点为
`(K,zeta,theta)=(3,4,-1) mod7`；两 outer values 确实都为零。
这只是必要源值兼容，不能把该点写成 Exact Lift 解，也不能套用旧
fixed-`7` label 的 `K=1` 排除；它是不同的 residue sheet。

#### 9.4.3 真实 height / descendant 交集

只对本文强迫的 non-`3` inert prime
读取 height。设
`j=min(vp(A3),vp(Wq),vp(GDelta))>=1`。
前述 height lemma 已给 `p∤omega`，且 `p∤30gcu`，所以
`alpha=omega Wq` 使 `zeta=-K mod p^j`。
`A3=0` 给 `theta=U/K mod p^j`；`K,U` 也都是单位。
在真实 source sheet 上精确有

```math
y(K,-K,U/K)=\frac3{16}\mathcal Y_A(K),\qquad
w(K,-K,U/K)=\frac{\mathcal W_A(K)}{U^2},
```

```math
\begin{aligned}
\mathcal Y_A&=11K^2-240K+432,\\
\mathcal W_A&=21K^4-342K^3+2002K^2-4896K+4455.
\end{aligned}
```

两者的整数 Bezout identity 为

```math
\begin{aligned}
&(1999434528K^3-28611870921K^2+133944686430K-202282077546)\mathcal Y_A\\
&\quad +(20781450135-1047322848K)\mathcal W_A
=3^{10}\cdot7\cdot12569471.
\end{aligned}
```

因此完整 prime-power 共深度只可能为 `p=7` 或 `p=12569471`，且 `j<=1`；
后者也是 `3 mod4` 的素数，checker 在确定性范围内核验素性。
在 `12569471` 的唯一共同点，`K=-267471,zeta=267471`，`U` 为单位，
`Phi2=12143998,Phi4=4798615 mod p`，故它不能支付任一 outer cofactor。
在 `7` 的唯一共同点仍是上述 `(3,4,-1)`，局部源值兼容而未关闭。
这些结论只限制 inert part 的 `A3/Wq/GDelta` 共同层；不能对所有
`p|alpha` 忽略 `omega` content，也不排除只有 height、没有 descendant
的 supplier。把 source、height、descendant 及 outer 两侧同时复用的
剩余必要标签现已压成该单层 `7` sheet，不能据此新增一份高度预算。

### 9.5 允许的 shared-`7` sheet

#### 9.5.1 `eta=2` 的两个 slot

将上述实际
`K=3,zeta=4,theta=-1 mod7` 与原 prefix、sphere 和 high-factor rows
联立。所有幂的模 `7` 周期整除 `6`，所以只需完整审计
`m mod6` 以及 `cu,g` 的全部 `7`-进单位。令 `M=2m-2,lambda=m-d`，
使用的必要原式是

```math
\begin{gathered}
a_2=(3-9\,10^M)/10,\qquad a_3=-3\,10^m,\qquad
b_2=2^{M+m+1}c_ug,\\
q=-2c_u5^{-\lambda},\qquad
c_Qq=5^M+2^mc_ug,\\
(c_Q5^d)^2[(9b_2/2)^2+a_2^2]+g^2a_3^2=0,\qquad
c_Q5^d a_2=g^2k_h/2\pmod7.
\end{gathered}
```

其中最后一式用 `eta=2` 已证明的 positive high-2 orientation；
球面式用 `H0=cu Wq=0`。对 §8 的八个 slot，这个完整单位审计
只剩以下四个必要 states（所有表项除 `m` 外均为模 `7`）：

| `(d,cQ,kh)` | `m mod6` | `(cu,g,a2,a3)` |
| --- | --- | --- |
| `(1,31,51)` | `2` | `(4,4,2,1)` |
| `(1,31,51)` | `5` | `(3,3,2,6)` |
| `(1,527,3)` | `2` | `(6,5,2,1)` |
| `(1,527,3)` | `5` | `(1,2,2,6)` |

所以其余六个 `eta=2` contact slot 以及这两型的 `m!=2 mod3`，
都不能复用 `A3/Wq/GDelta` 的单层 `7` 来同时支付 outer parity。
这是周期性必要条件覆盖无界 `m,M`，不是完整 Exact Lift 解枚举。
四个 remaining local states 和不作此共同复用的 carriers 仍待证。

#### 9.5.2 原 source 的无限 `7`-进 lift

这个
边界可以用无界局部构造证明。固定两种 surviving slot 与任意
`m>=7,m=2 mod3`，取 `M=2m-2`、`B=cQ5^d`，并把 positive high-factor
代入原式，得到三个整数多项式

```math
\begin{aligned}
F_Q&=B(g\omega-c_u)-5^{M+m}-10^mc_ug,\\
F_P&=\omega(g^2k_h-2Ba_2)-2c_u[10^mK+a_3],\\
F_S&=(g^2k_h-2Ba_2)^2-4g^2a_3^2-B^2(81b_2^2+4a_2^2),
\end{aligned}
```

这里 `K=9*10^M+10a2,b2=2^(M+m+1)cu g`。
固定 `cu,g` 为各自允许的 `7`-进单位，以 `(omega,a2,a3)` 为未知。
上述四个 base states 的 Jacobian determinant 分别为 `3,3,4,4 mod7`；
故多变量 Hensel lemma 给每个 base state 唯一的无限 source lift。

checker 还完整审计 `m mod42`（全部模 `49` 幂的周期）及
`cu=cv+7dc,g=gv+7dg` 的 `49` 对首 lift digits。每个 slot / exponent phase
都至少有 `17` 个 lifts，使

```math
v_7(A3)=v_7(Wq)=v_7(That2)=v_7(Yd)
=v_7(\Phi_2^{actual})=v_7(\Phi_4^{actual})=1.
```

`Phi_j^actual` 此处使用真实 `R=R0-w`，不是把 `R0` 继续代到模 `49`。
单位尺度使 `v7(GDelta)=1`；`Jsource=3 mod7` 又给 `C=0 mod7`，
而 `D=2^m5^d g` 为单位，所以两个 outer denominators `D±C` 也为单位。
因此这些 lifts 同时保持真实两个 outer cofactors 的 `7` 深度为奇数 `1`。
同一光滑 chart 可无限提升，所有已经核验的 depth-`1` 值在提升后仍为 `1`。
这证明单独的 `7`-进 source/sphere/plane 与这些 carrier parity
相容，不证明正整数 decimal window、全局 prime support 或 Exact Lift 解存在。
若要关闭这张 sheet，必须再使用这些局部条件尚未控制的真实整数/位数或
其它 source allocation；不能把单层共深度或下一字层枚举改写成不存在性。

#### 9.5.3 同源 `N3` 的下一字层与 odd-depth lift

使用 `fixed3-terminal-spill.md` §5 的唯一
实际 `P3`，令

```math
K=3+7k_7,\qquad\zeta=4+7z_7,\qquad\vartheta=-1+7h_7,\qquad
V_7:=k_7+z_7+1=\frac{\alpha}{7T}\pmod7.
```

在本节单位范围内 `N3` 与 `P3` 的 prefactors 均为 `7` 单位。
完整整数多项式展开严格给

```math
P3/7^2\equiv h_7^2-2V_7^2
=(h_7-3V_7)(h_7+3V_7)\pmod7.
```

两种 `eta=2` slot 的完整 source 三行首阶展开又给
`h7-3V7=5m mod7`；checker 对全部 `m mod42` 先作符号线性化，
然后审计所有 free first digits。因此

```math
\boxed{P3/7^2\equiv2m(V_7+2m)\pmod7.}
```

若 `7∤m` 且 `V7!=-2m mod7`，就有 exact depth `v7(N3)=2`，
该完整无界 word 子片不由 `7` 支付 third parity。
若 `7|m` 或 `V7=-2m`，仅凭这个初项得到 depth 至少 `3`；
不能把 zero digit 当作 odd 或 even。`V7` 是真实 height word，
没有为它新增独立预算。局部 `7` source compatibility 与全局整数关闭
仍必须区分。

进一步对完整 source 行作下一次 Hensel lift，得一个严格的局部奇数深度证书。
设 `m=14 mod21`，即当前允许相位且 `7|m`。checker 遍历 powers 模 `343`
的完整共同周期 `m mod294`，每型的 `14` 个 exponent phases，以及
`cu=cv+7dc,g=gv+7dg` 的 `49` 对首 digits；更高 free digits 暂取零，
三个 implicit variables 唯一提升到模 `343`。每型、每相位有
`12`–`17` 个已核验点同时满足

```math
v_7(A3)=v_7(Wq)=v_7(That2)=v_7(Yd)
=v_7(\Phi_2^{actual})=v_7(\Phi_4^{actual})=1,
\qquad v_7(N3)=3.
```

最后的 exact `3` 来自完整 `350` 项 `P3` 模 `2401` 的非零值，
不是首项为零后的 parity 猜测。由于 universal sheet expansion 整除 `49`，
`(K,zeta,theta)` 的模 `343` 值已确定 `P3 mod2401`：三个 sheet coordinates
模 `49` 的更高变化给 `P3` 的变化整除 `49²`。因此这些点的无限 source
Hensel extensions 保持上述全部 exact depths。这里显示 `7` 确可在当前
source chart 局部承担 odd third parity；仍未控制全局正窗口、整数恢复和
prime support，不能据此宣称 Exact Lift 解存在。

### 9.6 剩余两型的真实整数核

这一步只专门化既有 source identities，
不增加 product budget。两型均为 `d=1,cQ kh=1581`。给定 `m,cu`，

```math
M=2m-2,\quad T=10^m,\quad N=10^M,\quad B=5c_Q,
\quad b_3=B\,2^{3m-1}c_u,
```

```math
\frac{2(837/1000)}{5c_Q}(5/4)^m<c_u
<\frac{2(843/1000)}{5c_Q}(5/4)^m.
```

原整数 source quotient（不同于 `vartheta=cu/(g omega)`）为

```math
\Theta_H=\frac{5^{3m-3}+c_Qc_u}{g}\in\mathbb Z_{>0},\qquad
\omega=\frac{\Theta_H+2^m5^{m-1}c_u}{c_Q}\in\mathbb Z_{>0}.
```

所以只需考虑 `5^(3m-3)+cQ cu` 的正除数 `g`，并核对 `omega` 的整性。
`b2=2^(3m-1)cu g`；实际 positive high-factor window 还给
`2389/(250kh)<g/T<1212/(125kh)`。
令两个实际整数

```math
\mathcal L:=B\omega+10c_uT,\qquad
\mathcal E:=\frac{\omega g^2k_h}{2}-9c_uTN.
```

直接展开原 concatenation plane 得
`E-L a2=cu a3`，符号为减号。
source 的 `20<cQ omega/(2^m5^(m-1)cu)<21` 又给
`30cuT<L<31cuT`。把 `E-cuT` 作普通 Euclidean division：

```math
\mathcal E-c_uT=\mathcal L Q_E+R_E,\qquad 0\le R_E<\mathcal L.
```

真实 `1<a3/T<251/250` 严格等价于本次恢复所需的

```math
\boxed{a_2=Q_E,\quad 0<R_E<c_uT/250,\quad c_u\mid R_E,
\quad a_3=T+R_E/c_u.}
```

若 quotient 不等于 `a2`，相邻整数会把 `a3` 移动超过 `30T`，
所以没有第二个 numerator candidate。sphere 剩下一个精确整数核对：

```math
\boxed{k_h^2g^2=81b_3^2+4a_3^2+4k_hBa_2.}
```

最后仍须检查 numerator/denominator digit windows、既约性和本节
carrier valuations。每个 `(m,cu,g)` 至多恢复一组 `(a2,a3)`；
`m` 无上界，不能因每个固定参数只有有限 candidates 就宣称 A2 有限或为空。

在实际 surcharge 子片 `v2(g)=2`，source mod `8` 给
`cu=5^m mod8`。联立已证明的 `3` 与 `7` phase 后，完整必要 CRT 表为

| `(cQ,kh)` | `m mod6` | `cu mod168` | `g mod168` |
| --- | --- | --- | --- |
| `(31,51)` | `2` | `25` | `4` |
| `(31,51)` | `5` | `101` | `52` |
| `(527,3)` | `2` | `41` | `68` |
| `(527,3)` | `5` | `85` | `44` |

这个表与严格 `cu` interval、`5∤cu` 及 `cu` 只含 `1 mod4` 素因子相交，
给有限参数证书：第一型所有 `7<=m<68`、第二型所有 `7<=m<80`
都没有可能的 `cu`。首个 interval/unit survivors 分别是
`(m,cu)=(68,42193)` 与 `(80,35993),(80,36161)`；它们尚未通过上述
divisor、remainder、sphere 等检查，不能称为 Exact Lift candidates。
这个 lower-length certificate 不为无界 `m` 提供上界。

### 9.7 实际 fixed-`3` word 与剩余 parity 供应

上述精确 sphere 取消式
还控制真实 shallow prefix。写 `kh=3kappa,a2=3A2`，并用 `9|a3`；
除去共同 `9` 后模 `3` 得

```math
\kappa^2g^2=\kappa BA_2\pmod3.
```

对 `(31,51)` 与 `(527,3)`，均有 `kappa B=1 mod3`，且 `g²=1 mod3`，
所以严格强迫

```math
\boxed{k_3:=K/3\equiv a_2/3\equiv1\pmod3.}
```

这不是重新分配一份 source budget。将这个真实 prefix word 代入
`fixed3-terminal-spill.md` §6 已核验的 collision form，令
`r3=A3/(27g omega)`，两型的完整 fixed-`3` 状态为

| 实际 `A3` 状态 | `v3(N3)` | `3` 能否供应 odd parity |
| --- | --- | --- |
| `v3(A3)=2` | `9` | 可以 |
| `v3(A3)=3,r3=2 mod3` | `10` | 不可以 |
| `v3(A3)=3,r3=1 mod3` | 由下一初项决定 | 见下式 |
| `v3(A3)>=4` | `10` | 不可以 |

理由是 corrected depth-`10` 初项在 `k3=1` 时就是 `1-r3`，与
`a3/(9T)` 的更深 word 无关。在 `r3=1 mod3` 上写
`k3=1+3j,r3=1+3s,z=a3/(9T)`，同源完整 `P3` 再给

```math
N_3/3^{11}=\text{unit}\cdot[1-s+z(j-1)]\pmod3.
```

括号非零时 exact depth 为 `11`，仍供应 odd parity；为零时只能记
`v3(N3)>=12`。完整全系数推导集中在
[`fixed3-terminal-spill.md` §6](fixed3-terminal-spill.md#6-更新后的-fixed-3-frontier)。
特别地，完整无界子片

```math
v_3(A3)\ge4,\qquad7\nmid m,\qquad V_7\not\equiv-2m\pmod7
```

同时有 `v3(N3)=10,v7(N3)=2`。方向审计已证明正第三阶 carrier
`-N3` 去除 binary/`5` content 后为 `3 mod4`；这些偶数 `3,7` 深度
不能支付它的 inert parity。因此该子片必有一枚
`ell=3 mod4,ell!=3,7` 到奇数次。它是与 shared-`7` 不同的供应标签，
尚未证明与全部其它 pools 分离，也不自动新增独立 height budget。

#### 9.7.1 原 source 的无限 `3`-进 lift

只对这两个 `d=1` 型，
写 `a2=3A,a3=9Z,kh=3kappa,B=5cQ`，原 §9 的三行精确约成

```math
\begin{aligned}
B(g\omega-c_u)-5^{3m-2}-Tc_ug&=0,\\
\omega(\kappa g^2-2BA)-2c_u[T(3N+10A)+3Z]&=0,\\
\kappa^2g^2-4\kappa BA-9b_3^2-36Z^2&=0,\qquad
b_3=B2^{3m-1}c_u.
\end{aligned}
```

第二行从原 plane 除 `3` 得到，第三行从原 sphere 除 `9g²` 得到，
不是独立的 projective approximation。模 `3` 的唯一单位 base 为
`g=-B,cu=(-1)^m/g,omega=-(-1)^m,A=1`，而 `Z` 自由。
固定 `(g,Z)`、以 `(omega,A,cu)` 为 implicit variables 时，Jacobian 为

```math
\begin{pmatrix}-1&0&0\\-B&(-1)^mB&1\\0&-1&0\end{pmatrix}\pmod3,
\qquad\det=-1.
```

因此每个已核验 source 点均能 Hensel 提升到任意 `3`-进深度。
checker 完整遍历 `m mod18` 的六个允许相位、`g mod81` 的 `27` 个
允许类以及 `Z mod81` 的 `81` 类；原 powers 模 `81` 的共同周期为 `18`。
每个型、每个相位的 `2187` 个 source 点均分为

| 实际 `N3` 初项状态 | 数量 |
| --- | ---: |
| exact depth `9` | `1458` |
| exact depth `10` | `486` |
| depth-`11` 初项为 `1` | `81` |
| depth-`11` 初项为 `2` | `81` |
| depth 至少 `12` | `81` |

这证明上述原 source 行的 `3`-进必要条件不能统一消去 fixed-`3` odd supplier。
它只给局部 source 兼容点，未满足十进制正窗口、global prime support、
整数 divisor/remainder 等条件，不能称为 Exact Lift 解。

#### 9.7.2 尚未关闭的核心

这些接口把新 supplier 接回 q/f/content/height 的真实对象，但不使它们自动为空。
`H_A` 的定义本身不提供统一 height drop 或额外 product budget。
尚缺这些 carriers 的 source support 或 product-height 的统一排除；A2 仍为 `待证`。

## 10. verification

```bash
uv run python scripts/exact-lift/a2-only/research-checks/crt-descent/check_a2_fixed3_f_contact_orientation.py
uv run python scripts/exact-lift/a2-only/research-checks/crt-descent/check_a2_fixed3_f_contact_eta2_slots.py
uv run python scripts/exact-lift/a2-only/check_a2_fixed3_terminal_spill.py
```
