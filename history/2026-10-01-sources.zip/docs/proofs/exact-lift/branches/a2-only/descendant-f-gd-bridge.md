# A2 descendant quotient 的 exact `f/G_D` bridge

> **依赖：** `fixed3-terminal-spill.md`；历史 `spontaneous-crt-descended-quotient-orientation.md`；`fixed-prime-descendant-transversality.md`。
>
> **严格状态：已严格完成（exact `f/G_D` bridge 和 `F63` 初层深度），待证（剩余 `a2`-shallow `f`-contact）。** 本文将 source factor `f` 与 central gate `G_D` 放入同一个 descended quotient 的两项恒等式。当前 third-parent parity 范围以 `fixed3-terminal-spill.md` 新 §5 的 exact source 重建为准；不是旧加向 transport 的 `6/10` 路线。


> **2026-09-30 作用域更正：**本文件的 exact `f/G_D` bridge 与 `F63`
> 深度计算独立保留。所引用旧 generic third-parent depths `6/10`
> 已在 [transport 方向审计](crt-descent-ledger.md#transport-direction-audit)
> 中撤回。随后 [新的 sphere/plane 重建](fixed3-terminal-spill.md#fixed3-corrected-depths)
> 证明 `a2`-shallow `f`-unit 的 exact depth `8` 与全部 `a3`-shallow 的 exact depth `12`。
> 因此 fixed `3` 的 odd third-parent parity 只剩 `a2`-shallow `3|f`；旧 extra-central frontier 仅为历史推导。

---

## 1. descendant quotient

沿用

\[
\widehat{\mathscr D}_{63}=c_u^2\mathscr F_{63},
\]

\[
\mathscr F_{63}
=(2K-9)B_\Delta-\frac{63}{16}gTK^2,
\tag{1.1}
\]

\[
B_\Delta=g((2K-9)T-a_3)-H_0.
\tag{1.2}
\]

同时

\[
H_0=c_uW_q,
\qquad
W_q=\frac{TK+a_3}{\omega},
\qquad
f=g\omega+c_u.
\tag{1.3}
\]

`fixed3-terminal-spill.md` 已得到

\[
\omega B_\Delta
=f((2K-9)T-a_3)-3c_u(K-3)T.
\tag{1.4}
\]

---

## 2. `已严格完成`：exact `f/G_D` bridge

定义旧 descendant-height gate

\[
\boxed{G_D(K):=11K^2-240K+432}
\tag{2.1}
\]

和新的 coefficient

\[
\boxed{
J_f(K,a_3,T)
:=K^2T-576KT-32Ka_3+1296T+144a_3.}
\tag{2.2}
\]

把 (1.4) 代入 (1.1)，并用

\[
g\omega=f-c_u
\]
整理，得到 exact identity

\[
\boxed{
16\omega\mathscr F_{63}
=fJ_f-3c_uT\,G_D.}
\tag{2.3}
\]

这不是模素数的 resultant，而是全局整数恒等式。历史 `fixed3-terminal-spill.md` 的两个 exceptions

\[
3\mid f,
\qquad
v_3(2K-9)\ge3
\]

现在被放进同一个 descended quotient：前者提高第一项，后者通过 `G_D` 的 central expansion 控制第二项。

---

## 3. central coordinates

令

\[
U:=2K-9,
\qquad
\zeta:=a_3/T.
\]

直接代

\[
K=\frac{U+9}{2}
\]
得到

\[
\boxed{
\frac{4J_f}{T}
=U^2-64U\zeta-1134U-5103,}
\tag{3.1}
\]

\[
\boxed{
4G_D
=11U^2-282U-1701.}
\tag{3.2}
\]

固定系数分解为

\[
5103=3^6\cdot7,
\qquad
1134=2\cdot3^4\cdot7,
\]

\[
1701=3^5\cdot7,
\qquad
282=2\cdot3\cdot47.
\tag{3.3}
\]

特别地，旧 central/descendant transversality 正是 (3.2)。

---

## 4. `a_2`-shallow fixed-`3` channel

固定

\[
v_3(a_2)=1,
\qquad
v_3(a_3)\ge2.
\]

此时

\[
v_3(K)=1,
\qquad
v_3(U)=1.
\]

由 (3.1)，`U^2` 是唯一必然的 depth-2 leading term，所以

\[
\boxed{v_3(J_f)=2.}
\tag{4.1}
\]

写

\[
K=3k,
\qquad k\in\mathbf Z_3^\times.
\]

由 (3.2) 或直接计算：

\[
\frac{G_D}{9}
\equiv k(2k+1)\pmod3.
\tag{4.2}
\]

因此

\[
\boxed{
\begin{cases}
k\equiv2\pmod3&\Longrightarrow v_3(G_D)=2,\\
k\equiv1\pmod3&\Longrightarrow v_3(G_D)\ge3.
\end{cases}}
\tag{4.3}
\]

所以若 `3|f`，(2.3) 的两项从 depth `v_3(f)+2` 与 `1+v_3(G_D)` 开始竞争。fixed `3` 的剩余 odd contribution 必须来自这个明确的 two-term normalized cancellation；不存在第三个 coefficient source。

---

## 5. `a_3`-shallow fixed-`3` channel

固定

\[
v_3(a_3)=1,
\qquad
v_3(a_2)\ge2.
\]

令

\[
h:=v_3(U)\ge2.
\]

当 `h=2,3` 时，(3.1) 中 `U\zeta` 项给

\[
\boxed{v_3(J_f)=h+1,}
\tag{5.1}
\]

而 (3.2) 中 `282U` 项给

\[
\boxed{v_3(G_D)=h+1.}
\tag{5.2}
\]

因此若 `3\nmid f`，(2.3) 的第一项 depth 为 `h+1`，第二项为 `h+2`；不会在首层 cancellation：

\[
\boxed{3\nmid f,\ h\in\{2,3\}
\Longrightarrow
v_3(\mathscr F_{63})=h+1.}
\tag{5.3}
\]

`h=2` 正好恢复 generic descendant depth `3`。`h=3` 把 deeper-central 的
descendant depth固定为 `4`；这一计算继续有效。完整 `N3` 的真实 source
归一化现在已将全部 `a3`-shallow 的下一层固定为 exact depth `12`。

---

## 6. revised fixed-`3` frontier

旧用 generic depth `6/10` 把剩余通道分成 f-contact 与 extra-central 的
证明链为 **失效/降级**，不能把该初项失败隐藏在原 frontier 中。

当前 [`fixed3-terminal-spill.md` §§5–6](fixed3-terminal-spill.md#fixed3-corrected-depths)
用同一 `N3` 的真实 source rows 重新证明：

1. `a2`-shallow `3∤f` 给 exact even depth `8`；
2. 全部 `a3`-shallow 给 exact even depth `12`，包括 f-contact 与 deeper-central；
3. 唯一 fixed-`3` odd parity 可能性是 `a2`-shallow `3|f`。其 descendant quotient
   仍由 (2.3) 的 `fJ_f-3c_uTG_D` 精确读取，而真实 third-parent 的 depth-nine
   digit 是 `k^7[k(h-1)+1]`，其中 `k=K/3`、`h=f/(3g omega)`；
4. `eta=1` 的唯一 odd-`3` 类型 `(d,c_Q,k_h,slot)=(2,7,3,-)` 已由
   high-factor equality 独立排除该 f-contact；其它 `eta` 类型仍需进一步约束。

后续目标是把 (2.3) 的两项 collision、depth-nine digit 与原 Gaussian
high-2 orientation 联立，而不是把同一 `M` hierarchy 当成多个独立 product budgets。

A2 仍为 `待证`。

---

## 7. verification

```bash
uv run python scripts/exact-lift/a2-only/check_a2_descendant_f_gd_bridge.py
```
