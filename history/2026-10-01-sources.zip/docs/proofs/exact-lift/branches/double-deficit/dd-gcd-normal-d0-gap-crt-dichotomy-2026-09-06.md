# DD gcd-normal `d_0` source-gap CRT 与 large-gap multiplicative dichotomy

> 日期：2026-09-06
>
> 依赖：[`good-genuine-ledger.md`](good-genuine-ledger.md) 中 `gcd-normal-exact-small-factor`、[`tail-allocation-ledger.md`](tail-allocation-ledger.md) 中 `tail-rough-d0-allocation` / `tail-rough-cq-excess`、[`dd-corrected-hard-source-split-2026-08-22.md`](dd-corrected-hard-source-split-2026-08-22.md)。
>
> **严格状态：已严格完成（整个 DD gcd-normal tail；local source sharpening 对 odd non-decimal `d_0` support）。**
>
> 本文不使用 unified discriminant root、不使用 suspended `General-transfer-local`，也不使用 canonical `t_2=1`。核心是把 gcd-normal tail recovery 与 DD gap exact identity直接联立。得到两个此前未显式利用的结果：
>
> 1. reduced denominator core `v` **全局整除 sphere height** `H_sph`；
> 2. gap quotient `a` 同时被两个互素 moduli `d_0` 与 `v` 读取。
>
> 因而 `a` 要么是 modulo `d_0v` 的 ordinary exact CRT lift，要么 `a>=d_0v` 并强迫
>
> \[
> \boxed{F_->Q^2v^3,}
> \]
>
> 比 universal `F_->Qv^2` 多一整份 `Qv`。
>
> 此外，`d_0`-reader 在 odd source prime上做 coefficient stripping后留下的 local modulus exponent为
>
> \[
> \boxed{r_p^{(d_0)}=(c-t-(j-E)_+)_+,}
> \]
>
> 比此前 `C_Q` Euclidean modulus `(c-max(E,j)-t)_+` 恰好恢复了 prefix-common depth `E`。在 corrected split 上，这个新 modulus自动覆盖全部 `X_N X_H` residual。

---

## 1. gcd-normal exact data

写

\[
\kappa=\gamma u,
\qquad
G=\gamma v,
\qquad
(u,v)=1,
\]

并令

\[
d_0=(u,Q),
\qquad
u=d_0L,
\qquad
Q=d_0q,
\qquad
(L,q)=1.
\tag{1.1}
\]

这里使用 `gcd-normal-exact-small-factor` 已证明的 exact identification：其旧记号 `r` 就是 DD tail normalization 的 `L`。同时

\[
\boxed{\tau=vq,}
\tag{1.2}
\]

\[
\boxed{(d_0,v)=1,\qquad(L,v)=1.}
\tag{1.3}
\]

令

\[
\omega:=(10^m,b_3)=10^m/L,
\]

以及

\[
c_3:=q_{\rm lcm}/b_3.
\]

由 tail recovery

\[
b_3=v\omega q,
\]

故

\[
\boxed{q_{\rm lcm}=v\omega q c_3.}
\tag{1.4}
\]

注意 `omega` 是 `{2,5}`-smooth，但一般**不是**纯 `10` 次幂。后续 decimal phase shifting只能抽取其中的完整 `10`-power `10^{v_{10}(omega)}`；剩余 one-sided `2`/`5` factor必须保留在 coefficient 中。

---

## 2. source-gap exact identity直接给 `v | H_sph`

DD gap exact identity为

\[
\boxed{
\mathcal M=q_{\rm lcm}A_{12}10^d
=QH_{\rm sph}+\tau a.
}
\tag{2.1}
\]

代入 `(1.1)--(1.4)`：

\[
v\omega q c_3A_{12}10^d
=d_0qH_{\rm sph}+vqa.
\]

约去正整数 `q`：

\[
\boxed{
v\omega c_3A_{12}10^d
=d_0H_{\rm sph}+va.
}
\tag{2.2}
\]

右边说明

\[
v\mid d_0H_{\rm sph}.
\]

由 `(d_0,v)=1`：

\[
\boxed{v\mid H_{\rm sph}.}
\tag{v-H}
\]

定义

\[
\boxed{H_{\rm sph}=vH_0,\qquad H_0\in\mathbf Z_{>0}.}
\tag{2.3}
\]

把 `(2.3)` 代回 `(2.2)` 并约去 `v`：

\[
\boxed{
\omega c_3A_{12}10^d
=a+d_0H_0.
}
\tag{D0-parent}
\]

因此得到第一个 source residue：

\[
\boxed{
 a\equiv \omega c_3A_{12}10^d\pmod{d_0}.
}
\tag{D0-residue}
\]

---

## 3. sphere gap给互素 `v`-residue

因为

\[
y_3=a_3\frac{q_{\rm lcm}}{b_3}=a_3c_3,
\]

而 DD gap normalization为

\[
H_{\rm sph}-y_3=La,
\]

结合 `H_sph=vH_0`：

\[
\boxed{
vH_0=a_3c_3+La.}
\tag{V-parent}
\]

模 `v`：

\[
\boxed{La\equiv-a_3c_3\pmod v.}
\tag{V-residue}
\]

由 `(L,v)=1`：

\[
\boxed{
a\equiv-a_3c_3L^{-1}\pmod v.}
\tag{V-residue-unit}
\]

又 `(d_0,v)=1`，所以 `(D0-residue)` 与 `(V-residue-unit)` 由 CRT 唯一确定一个

\[
\boxed{\rho_a\in[0,d_0v)}
\tag{3.1}
\]

满足

\[
\boxed{a\equiv\rho_a\pmod{d_0v}.}
\tag{Gap-CRT}
\]

这是两个**不同 coprime moduli** 对同一个 gap quotient 的 exact global reconstruction；本文不把它们当两份 p-adic height payer，只使用其 CRT location。

---

## 4. small-gap / large-gap 二分

### 4.1 small-gap branch

若

\[
\boxed{0<a<d_0v,}
\tag{4.1}
\]

则 `(Gap-CRT)` 立即升级成 ordinary exact lift：

\[
\boxed{a=\rho_a.}
\tag{Gap-CRT-lock}
\]

特别地，若 computed residue `rho_a=0`，则与 `a>0` 矛盾，该 fiber为空。

### 4.2 large-gap branch

若

\[
\boxed{a\ge d_0v,}
\tag{4.2}
\]

exact small-factor normalization为

\[
\boxed{
F_-=L(u+2v)\,a\frac{g_*}{v},
\qquad \frac{g_*}{v}\in\mathbf Z_{>0}.
}
\tag{4.3}
\]

由 `u=d_0L`、`a>=d_0v`：

\[
F_-
\ge L(u+2v)d_0v
=uv(u+2v)
>u^2v.
\tag{4.4}
\]

而 gcd-normal tail window给

\[
\boxed{Q<u/v\le10Q,}
\tag{4.5}
\]

所以 `u>Qv`。代入 `(4.4)`：

\[
\boxed{F_->Q^2v^3.}
\tag{Large-gap-Fminus}
\]

这严格强于 universal multiplicative lower

\[
F_->Qv^2.
\]

---

## 5. large-gap height consequence

由 decimal lengths

\[
Q\ge10^{S-1},
\qquad
G\ge10^{S-2},
\]

且

\[
v=G/\gamma,
\]

记

\[
\Gamma:=\frac{\log_{10}\gamma}{S}.
\]

则 `(Large-gap-Fminus)` 给

\[
\boxed{
\frac{\log_{10}F_-}{S}
\ge5-3\Gamma-o(1).
}
\tag{5.1}
\]

与 d-dominant Archimedean upper

\[
\log_{10}F_-<4S+2m-n+O(1)
\]

联立：

\[
\boxed{
\frac nS
\le-1+2\frac mS+3\Gamma+o(1).
}
\tag{Large-gap-slope}
\]

旧 universal multiplicative lower只给

\[
\frac nS\le1+2\frac mS+2\Gamma+o(1).
\]

二者目标差为

\[
(-1+2M+3\Gamma)-(1+2M+2\Gamma)=\Gamma-2.
\]

而 `gamma|G`，故 `Gamma<=1+o(1)`。所以在 large-gap branch，本文的新 slope inequality具有至少约一整份 normalized `S` 的严格余量。

---

## 6. odd `d_0` source 的 coefficient-stripped modulus

现在回到 second-Schmidt odd non-decimal support。固定

\[
p\nmid10,
\qquad p\mid d_0.
\]

沿用 `tail-rough-d0-allocation` 的 notation：

\[
E=v_p(b_1)=v_p(b_2),
\quad
j=v_p(b_3),
\quad
c=v_p(C_Q),
\]

其中

\[
C_Q=Q/(b_1,b_2).
\]

并令

\[
t=v_p(A_{12}).
\]

旧 exact ledger给

\[
\boxed{v_p(d_0)=E+c-j,}
\tag{6.1}
\]

以及

\[
\boxed{v_p(c_3)=(E-j)_+.}
\tag{6.2}
\]

因为 `p` 为 non-decimal prime，`omega` 是 p-unit。故 `(D0-parent)` 左侧 coefficient

\[
\omega c_3A_{12}
\]

在 p 处深度为

\[
\boxed{s_p=(E-j)_++t.}
\tag{6.3}
\]

定义 stripping 后的 residual exponent

\[
\boxed{
r_p^{(d_0)}
:=\bigl(v_p(d_0)-s_p\bigr)_+.
}
\tag{6.4}
\]

代入 `(6.1),(6.3)`：

\[
\boxed{
r_p^{(d_0)}
=\bigl(c-t-(j-E)_+\bigr)_+.
}
\tag{D0-local-depth}
\]

若 `r_p^(d0)>0`，则 `s_p<v_p(d_0)`；由 `(D0-parent)` 的 unit `10^d` 可知两边要能相差 `p^{v_p(d0)}`，必有

\[
\boxed{v_p(a)=s_p.}
\tag{6.5}
\]

所以除去 `p^{s_p}` 后确实留下一个 coefficient/right-side 都为 p-unit 的模 `p^{r_p^(d0)}` source residue。

同时

\[
r_p^{(d_0)}\le c,
\]

故全局 modulus

\[
\boxed{
D_{d_0}:=\prod_{p\mid\operatorname{core}_{10}(d_0)}p^{r_p^{(d_0)}}
}
\tag{6.6}
\]

满足

\[
\boxed{D_{d_0}\mid C_Q.}
\tag{6.7}
\]

这点非常重要：虽然 reader源自更大的 `d_0`，stripping 后留下的有效 source modulus仍落回 primitive prefix modulus `C_Q`，所以可以继续合法使用 prefix block folding。

---

## 7. 相比旧 `C_Q` Euclidean modulus精确恢复 `E` 层

旧 Euclidean coefficient stripping在同一 prime给

\[
\boxed{
r_p^{(E)}=(c-\max(E,j)-t)_+.}
\tag{7.1}
\]

而

\[
\max(E,j)=E+(j-E)_+.
\]

所以在取 positive part之前：

\[
\boxed{
 c-t-(j-E)_+
=
\bigl(c-\max(E,j)-t\bigr)+E.
}
\tag{7.2}
\]

因此

\[
\boxed{r_p^{(d_0)}\ge r_p^{(E)}.}
\tag{7.3}
\]

新 `d_0` reader恰好把旧 `C_Q` coefficient中被 `q_lcm` denominator maximum吞掉的 prefix-common depth `E` 恢复进 source modulus。

---

## 8. corrected split 中 `D_{d_0}` 覆盖全部 `X_N X_H`

使用 `dd-corrected-hard-source-split` notation。

### 8.1 hard support `h>0`

hard ledger为

\[
\boxed{c=h+2t+n_0+M+j,\qquad M=\max(E,j).}
\tag{8.1}
\]

若 `E>=j`：

\[
r_p^{(d_0)}=c-t
=h+t+n_0+E+j
\ge h+n_0.
\]

若 `j>E`：

\[
\begin{aligned}
r_p^{(d_0)}
&=c-t-(j-E)\\
&=h+t+n_0+j+E\\
&\ge h+n_0.
\end{aligned}
\]

所以所有 hard source + hard prefix-norm exponent都进入 `D_d0`。

### 8.2 soft prefix-norm support `e_N>0,h=0`

corrected split定义本身给

\[
e_B=t,
\qquad e_a=\alpha,
\]

以及

\[
x=t+\alpha+e_N+e_3.
\tag{8.2}
\]

若 `j>E`，由 source-excess identity

\[
c=x+j+E
\]

得到

\[
\begin{aligned}
r_p^{(d_0)}
&=c-t-(j-E)\\
&=\alpha+e_N+e_3+2E\\
&\ge e_N.
\end{aligned}
\]

若 `E>=j`，则 `e_3=0` 且

\[
c=x+2j,
\]

故

\[
\begin{aligned}
r_p^{(d_0)}
&=c-t\\
&=\alpha+e_N+2j\\
&\ge e_N.
\end{aligned}
\]

因此全局严格有

\[
\boxed{X_NX_H\mid D_{d_0}.}
\tag{D0-covers-NH}
\]

这是相对旧 Euclidean modulus的主要结构升级：不再留下 `X_{N,D}|(b_1,b_2)` 的 denominator-common escape。

---

## 9. decimal circular normalization 的正确边界

因为 `D_d0|C_Q`，在 `D_d0` 上 primitive prefix relation

\[
u_1 10^{m_2}\equiv-u_2
\]

仍可用于 exponent folding，且 `u_1,u_2` 为 target units。

但必须注意：`omega` 只保证 `{2,5}`-smooth，不保证是纯 `10` 次幂。定义

\[
c_{10}^{(d_0)}:=v_{10}(\omega c_3A_{12}),
\qquad
s_{10}^{(d_0)}:=v_{10}(a),
\]

其中

\[
v_{10}(N):=\min(v_2(N),v_5(N)).
\]

只有这两份完整 decimal powers可向 exponent搬移；其余 one-sided smooth part保留在 unit coefficient中。

因此和前一 circular theorem完全相同的离散 interval argument给一个 normalized exponent

\[
\boxed{r_{d_0,\rm circ}\ge0}
\]

满足

\[
\boxed{
r_{d_0,\rm circ}
\le
\max\left(
0,
\left\lfloor
\frac{m_2-c_{10}^{(d_0)}-s_{10}^{(d_0)}}2
\right\rfloor
\right)
\le\frac{m_2}{2}.
}
\tag{D0-circular-range}
\]

并存在 target-unit coefficients `A_d,B_d` 使

\[
\boxed{
D_{d_0}\mid A_d10^{r_{d_0,\rm circ}}-B_d,
\qquad
(A_dB_d,D_{d_0})=1.
}
\tag{D0-circular-reader}
\]

所以若

\[
D_{d_0}>10^{r_{d_0,\rm circ}},
\]

则得到 ordinary exact source-phase lock；若 ordinary criterion失败，则由 `(D0-covers-NH)`：

\[
\boxed{
X_NX_H
\le D_{d_0}
\le10^{r_{d_0,\rm circ}}.
}
\tag{D0-failure}
\]

结合现有 corrected third-gap bootstrap

\[
3\log F_-+\log(X_NX_H)\ge3S-o(S)
\]

得到

\[
\boxed{
\log F_-
\ge S-\frac13r_{d_0,\rm circ}-o(S).
}
\tag{D0-failure-Fminus}
\]

由于 `r_d0,circ<=m2/2<=S/2`，粗化为 `5S/6-o(S)`。这**不取代**前一 `7S/8` circular-failure lower；后者通过保留并再收费 denominator gcd 得到更强的 worst-case constant。本文 d0-reader的主要价值是：

1. source modulus更大；
2. `X_NX_H` 无 denominator-common escape；
3. ordinary-lock branch更容易触发；
4. 和 coprime `v`-residue一起直接控制 gap quotient `a`。

不能把同一 prefix-common `E` 同时当成新 modulus surplus与额外 independent height payer重复收费。

---

<a id="canonical-large-gap-exclusion"></a>

## 10. 2026-09-30 canonical one-channel 的 large-gap 无界子支排除

**严格状态：已严格完成（corrected canonical `t_2=1` quantitative
one-channel neighborhood 内的渐近结论，非有效）。** 本节只使用
[`dd-corrected-high-funnel-quantitative-defect-2026-08-22.md`](dd-corrected-high-funnel-quantitative-defect-2026-08-22.md)、
[`dd-corrected-terminal-digit-polarization-2026-08-22.md`](dd-corrected-terminal-digit-polarization-2026-08-22.md)
的未粗化 short-head estimate，以及
[`dd-corrected-terminal-two-adic-uz-neighborhood-2026-08-22.md`](dd-corrected-terminal-two-adic-uz-neighborhood-2026-08-22.md)
的 two-adic reader。其共同作用域是沿 `S -> infinity` 的 corrected canonical
sequence，固定 `0<=delta<=1/2`；不覆盖一般 non-canonical DD 状态。

### 10.1 记号与命题

本节保留 `a` 为正整数 gap quotient，另用

\[
\alpha:=\log_{10}2,\qquad\beta:=1-\alpha,\qquad
A:=\frac{2(1+2\alpha)}3,\qquad
\lambda:=\frac{2+\alpha}{1+2\alpha},
\]

\[
M_*:=\frac3A,\qquad c_*:=2+3\lambda,
\qquad \mu:=M_*-\frac mS,\qquad
\delta:=c_*-\frac nS.
\]

Canonical `G=gamma V`、`(V,10)=1` 给

\[
\boxed{\Gamma:=\frac{\log_{10}\gamma}{S}
=\alpha G_2+\beta G_5+R.}
\tag{10.1}
\]

这里 `G_2=v_2(G)/S`、`G_5=v_5(G)/S`、
`R=log_10(core_10(gamma))/S`；`Q_2,N_2,Q_5,N_5` 与
normalized Schmidt slack `sigma_S` 均沿上述 corrected quantitative-defect
文件定义，`sigma_S>=-o(1)`，其它 defects 非负。

令

\[
K_*:=c_*+1-2M_*
=\frac92-M_*
=1.691116422381968\ldots.
\tag{10.2}
\]

则整个现行 one-channel neighborhood 有 quantitative gap location

\[
\boxed{
\frac1S\log_{10}\frac{a}{d_0v}
\le-K_*+\frac52\delta+o(1).}
\tag{Canonical-small-gap-location}
\]

特别地 `delta<=1/2` 时右端至多
`-0.441116422381968...+o(1)`。所以该 neighborhood 中
**不存在 `a>=d_0v` 的无界 DD 序列**；任何满足这些假设的无界序列，最终都
落在 `0<a<d_0v`，并由 `(Gap-CRT-lock)` 得到 `a=rho_a`。

### 10.2 共享预算对 `3 Gamma - 2 mu` 的控制

未粗化 short-head estimate 为

\[
\frac{m_1}{S}
\le\frac\delta2
-\left(1-\frac\beta3\right)\mu
-\frac\beta3Q_5+\frac\beta3G_5
-\frac\beta6N_5+\frac R2+o(1).
\tag{10.3}
\]

Two-adic reader给 `alpha G_2<=m_1/S+alpha Q_2+o(1)`。与 `(10.1)`
联立：

\[
\Gamma\le\frac\delta2
-\left(1-\frac\beta3\right)\mu
+\alpha Q_2-\frac\beta3Q_5
+\frac{4\beta}3G_5-\frac\beta6N_5
+\frac32R+o(1).
\tag{10.4}
\]

因此

\[
3\Gamma-2\mu+\delta
\le\frac52\delta-(5-\beta)\mu
+3\alpha Q_2-\beta Q_5+4\beta G_5
-\frac\beta2N_5+\frac92R+o(1).
\tag{10.5}
\]

使用**同一份** corrected Schmidt identity

\[
A\mu=\sigma_S+2\alpha Q_2+\alpha N_2
+\frac\beta3(2Q_5+4G_5+N_5)+2R+o(1),
\tag{10.6}
\]

并写 `C:=(5-beta)/A=(4+alpha)/A`，得到

\[
\begin{aligned}
3\Gamma-2\mu+\delta
\le{}&\frac52\delta-C\sigma_S
+\alpha(3-2C)Q_2-\alpha C N_2\\
&-\beta\left(1+\frac{2C}3\right)Q_5
+\beta\left(4-\frac{4C}3\right)G_5\\
&-\beta\left(\frac12+\frac C3\right)N_5
+\left(\frac92-2C\right)R+o(1).
\end{aligned}
\tag{10.7}
\]

因为 `alpha<2/3`（等价于 `2^3<10^2`），有 `C>3`。所以所有显示的
correction coefficients 都严格为负；`sigma_S>=-o(1)` 的误差仍可吸收进
`o(1)`。故

\[
\boxed{3\Gamma-2\mu+\delta\le\frac52\delta+o(1).}
\tag{Gamma-mu-shared-budget}
\]

这一步没有把 common scale、prefix-common depth 或任何 local prime重复记账。

### 10.3 exact small factor给 quantitative location

不先假设 large-gap。由 `(4.3)` 和 `g_*/v>=1`：

\[
F_-\ge L(u+2v)a
=\frac{a}{d_0v}\,uv(u+2v)
>\frac{a}{d_0v}\,Q^2v^3,
\tag{10.8}
\]

最后一步使用 `u>Qv`。又 `Q>=10^{S-1}`、`G>=10^{S-2}`、
`v=G/gamma`，所以

\[
\frac1S\log_{10}\frac{a}{d_0v}
<\frac{\log_{10}F_-}{S}-5+3\Gamma+o(1).
\tag{10.9}
\]

沿 d-dominant canonical sequence，前述 small-factor Archimedean upper 为

\[
\frac{\log_{10}F_-}{S}
\le4+2\frac mS-\frac nS+o(1).
\tag{10.10}
\]

代入 `m/S=M_*-mu`、`n/S=c_*-delta`，再用
`(Gamma-mu-shared-budget)`，即得 `(Canonical-small-gap-location)`。

作为仅依赖 large-gap 假设的写法，`a>=d_0v` 会强迫

\[
\delta\ge\frac{2K_*}5-o(1)
=0.676446568952787\ldots-o(1),
\]

与当前 `delta<=1/2` 有固定正余量。此 threshold 是联立不等式的必要条件，
不是把 one-channel 输入的作用域扩展到 `delta>1/2`。

### 10.4 更窄邻域中的两个单独 ordinary readers

本节还给出一个不增加 height payer 的位置推论。因为 `d_0|Q`、`v|G`，
且 `Q,G<10^S`，将 `(Canonical-small-gap-location)` 分别乘回 `d_0` 与 `v`
的 height可得

\[
\boxed{
\max\left\{
\frac1S\log_{10}\frac av,
\frac1S\log_{10}\frac a{d_0}
\right\}
\le-U_*+\frac52\delta+o(1),}
\qquad U_*:=K_*-1=0.691116422381968\ldots.
\tag{Separate-gap-reader-window}
\]

因此对任意 fixed

\[
0\le\delta_0<\frac{2U_*}5
=0.276446568952787\ldots,
\]

`delta<=delta_0` 的上述 canonical sequence最终满足

\[
\boxed{0<a<\min(d_0,v).}
\tag{Separate-ordinary-gap-locks}
\]

此时两个 coprime reader各自都升级成普通整数重构：

\[
\boxed{
a=[\omega c_3A_{12}10^d]_{d_0}
=[-a_3c_3L^{-1}]_v,}
\tag{Separate-ordinary-gap-readers}
\]

`[x]_M` 表示 `[0,M)` 中的 least residue。特别地这些 moduli 最终都大于
`1`，两个 residues都必须非零并彼此相等。

这是同一 location estimate的推论，不能把两个 least-residue equality
再当两份 independent lower height。`D0-parent` 与 `V-parent` 消去 `H_0`
只回到既有 exact determinant equation：

\[
\boxed{
c_3\bigl(v\omega A_{12}10^d-d_0a_3\bigr)=(u+v)a.}
\tag{Gap-reader-elimination}
\]

因此，仅反复消去这两个 parents 不会产生新的 independent global
obstruction；仍须利用没有包含在该 exact source-gap normalization 中的
full-concat / chosen-orientation 兼容性，才能排除 ordinary-success 支。

### 10.5 核对与严格边界

机械核对命令：

```bash
UV_CACHE_DIR=/tmp/math-uv-cache uv run python scripts/exact-lift/double-deficit/research-checks/tail/check_dd_gcd_normal_d0_gap_crt_dichotomy.py
```

脚本以 symbolic substitution核对 `(10.5)--(10.7)`，以整数幂比较核对
`1/4<alpha<2/3`，并输出 threshold 和 uniform margin；这只是 exact algebra /
常数核对。无界排除来自本节的完整推导及输入定理，不来自有限枚举。

由于 corrected Schmidt 输入含非有效 `o(1)`，本节没有提供可计算的绝对
`S` 上界，没有排除剩余有限例外，也没有排除 small-gap ordinary CRT
representative。一般 DD 的 large-gap dichotomy、ordinary circular-lock
成功支与 DD 全局空性仍须另行处理。

---

<a id="single-digit-tail-v-one"></a>

## 11. 一位第三分母的 general source 归约（2026-09-30）

**状态：已严格完成（公开 necessary denominator condition；在 DD 中完整
关闭 `m_3=1,v>1`，保留 `v=1` 普通 source族）。** 本节允许前两分母和
全部分子位数无界，不使用 canonical、`t_2=1` 或 frozen top-DD。第一项
论证对三个分支统一成立，`n_3>=1` 即可。设 `1<=b_3<=9`，前缀 word 为
`Q=b_1 10^{m_2}+b_2`。原始 source ratio 给

\[
\frac uv=\frac{10Q}{b_3}\quad((u,v)=1),
\qquad
\boxed{v=\frac{b_3}{(10Q,b_3)}\le9.}
\tag{Single-digit-tail-source-denominator}
\]

若 `2|v`，写 `e_3=v_2(b_3)>1+v_2(Q)`。原 word denominator
`D=10Q+b_3` 的二进 depth 是 `1+v_2(Q)<e_3`。但
[core.md §27.7](core.md#277-二进分母主导位置与全奇分母锥) 的整数 sphere
要求最大分母二进 depth `E_2` 唯一，因而 `v_2(R)=-E_2<=-e_3`。
原 word ratio 则给 `v_2(R)>=-v_2(D)>-e_3`，矛盾。又因一位 `b_3`
的 five-depth 至多为一，`5` 不能整除 `v`。

余下任何 `v` 的素因子只能是 `p=3,7`，均为 Gaussian inert prime。
写 `e_i=v_p(b_i)`、`s=v_p(Q)`。因 `p|v`，有 `e_3>s`，故
`v_p(D)=s`。若 `e_1=e_2`，则 `s>=e_1=e_2`，第三分母独占最大值；
若 `e_1!=e_2`，则 `s=min(e_1,e_2)`，最高 depth只能由较大前缀与
第三分母中的一个或两个取得。两坐标同为最高时，其 leading unit
squares不能相消，因为 `-1` 在 `F_p` 中不是平方。因此在所有情况下
sphere均给

\[
v_p(R)=-\max(e_1,e_2,e_3)<-s,
\]

与 word ratio的 `v_p(R)>=-v_p(D)=-s` 矛盾。这已排除 `v` 的全部
可能素因子，故

\[
\boxed{m_3=1\Longrightarrow b_3\mid10Q,\qquad v=1.}
\tag{Single-digit-tail-v-one}
\]

这是跨分支的 necessary denominator condition，不是某个完整分支的
空性。特别地，在 DD normalization `u/v=kappa/G` 中还给 `gamma=G`。
这里是无界 state 排除，并非有限 prime enumeration 的经验结论：只有
`b_3<=9` 的素支持是有限的，prefix depths 与全部 word lengths均任意。
沿用 §1 的剥离定义可逐项恢复

\[
\omega=(10,b_3),\quad L=10/\omega,\quad
\tau=q=b_3/\omega,\quad d_0=Q/\tau,\quad u=LQ/\tau.
\tag{Single-digit-tail-reduced-source-dictionary}
\]

其中 `q` 是 §1 的 reduced source quotient，不是 `q_lcm`。
`(L,tau)=1` 且 `tau|Q`；这一字典不能与 canonical `q_src/xi` 默认混用。
此时 `v`-residue 变为平凡模一条件，仍需处理 ordinary `d_0` / full-word
compatibility；没有由此增加第二份 source height。

<a id="single-digit-five-tail-unit-necessity"></a>

### 11.1 `b_3=5` 的 unique-five-tail unit 约束

**状态：已严格完成（必要条件，不是整个 `b_3=5` 子支空性）。** 进一步
假设 `5` 不整除 `b_1b_2`。因第三分母奇，core §27.7 已直接要求
`b_1,b_2` 均奇；不能再把这一二进 parent算成新排除。令
`q_lcm=5c_3`，其中 `c_3` 为 five-unit。原 word 与 integer sphere给

\[
H=\frac{c_3\mathscr A}{2Q+1},\qquad
H^2-y_3^2=y_1^2+y_2^2\equiv0\pmod{25},\qquad
y_3=c_3a_3.
\]

第三分母独占 five-depth一，sphere要求 `v_5(R)=-1`。Reducedness使
`mathscr A=a_3 mod5` 为 unit，故 `2Q+1` 也必须是 five-unit。模五
sphere与原 word强迫 `(2Q+1)^2=1 mod5`；因 `Q=b_2!=0 mod5`，只剩

\[
Q\equiv4\pmod5,\qquad H\equiv-y_3\pmod5.
\]

所以 `H-y_3` 为 five-unit，`H+y_3` 被 `25` 整除。DD 中 `n_3>=2`，
有 `mathscr A=a_3 mod25`，于是

\[
0\equiv(2Q+1)(H+y_3)
\equiv2c_3(Q+1)a_3\pmod{25}.
\]

因 `2c_3a_3` 为 unit，得到

\[
\boxed{Q\equiv24\pmod{25},\qquad b_1,b_2\text{ 均奇}.}
\tag{Single-digit-five-tail-unit-necessary-state}
\]

若 `m_2>=2`，这要求 `b_2=49 mod50`；若 `m_2=1`，则必须
`b_2=9,b_1=9 mod10`。这个 negative five-sheet在更高精度仍可兼容。
本节不宣称允许剩余类为空，不把该 unit condition收费为 independent
height budget。§27.7.3 的完整一位三分母证书是更小 denominator 域上的
另一结论，不能替代这里一般前缀分母的剩余证明。

<a id="single-digit-five-tail-unit-prefix-closure"></a>

### 11.2 unique-five-tail 且第二分母至多两位的完整 DD state 关闭（2026-10-01）

**状态：已严格完成（无界 state 为空，无原候选有限枚举）。** 假设

\[
\boxed{b_3=5,\quad5\nmid b_1b_2,\quad1\le m_2\le2,\quad n_3>1.}
\tag{Unique-five-tail-one-digit-second-domain}
\]

第一分母与全部分子位数均无界，不使用 canonical 或 frozen top-DD。
由 §11.1，两个 prefix denominators奇且 `Q=24 mod25`，故
`Q=49 mod50`。先设 `m_2=1`。因 `Q=10b_1+b_2`、`b_2` 一位，只剩

\[
b_2=9,\qquad b_1\equiv9\pmod{10},\qquad D=100b_1+95.
\]

若 `3|b_1`，第三分母为三进 unit，前两最高三进 denominator depth
由一个或两个坐标取得。`3` inert使其 unit squares不能抵消，sphere
要求 `v_3(R)<0`。但 `D=100b_1+95` 是三进 unit，word要求
`v_3(R)>=0`，矛盾。因此 `(b_1,45)=1`。

对每个 `p^e||b_1`，其它两分母均为 `p`-unit，第一分数独占最高
denominator depth；sphere给 `v_p(R)=-e`，故原 word给 `p^e|D`。
合并所有 prime powers得 `b_1|D`，从而 `b_1|95`。排除五进 support后
只有 `b_1=1,19`，再由 `b_1=9 mod10` 只留 `19`。

最后 `(b_1,b_2,b_3)=(19,9,5)` 时 `D=1995` 的三进 depth为一，第二
分数独占三进 depth二。Sphere要求 `v_3(R)=-2`，word却给
`v_3(R)>=-1`，矛盾，关闭一位第二分母。

再设 `m_2=2`。必要 `b_2=49 mod50` 只留 `b_2=49,99`。

1. **`b_2=49`。** 若 `7|b_1`，前两最高七进 depth由一个或两个坐标
   取得，inert unit squares不能抵消；但 `D=1000b_1+495` 在七进为
   unit，矛盾。因此 `(b_1,245)=1`，逐 prime power unique maximum
   再给 `b_1|D`、`b_1|495`，five-unit使 `b_1|99`。
   `b_2` 独占七进 depth二，word必须 `D=0 mod49`，即
   `20b_1+5=0 mod49`，要求 `b_1=12 mod49`。`99` 的 positive divisors
   `1,3,9,11,33,99` 均不满足，矛盾。
2. **`b_2=99`。** 若 `3` 或 `11` 整除 `b_1`，原 denominator
   `D=1000b_1+995` 分别为该 inert prime的 unit，而 sphere的最高
   depth由一个或两个 prefix坐标取得，仍矛盾。因此 `(b_1,495)=1`。
   再由 unique maximum得 `b_1|995`，five-unit只留 `1,199`。
   `b_2` 独占三进 depth二，word要求 `D=0 mod9`，即 `b_1+5=0 mod9`。
   两个允许值均为 `1 mod9`，矛盾。

因此整个 `(Unique-five-tail-one-digit-second-domain)` 为空。本节只枚举
必要 denominator values / divisors，没有有限枚举 original numerators；
第一分母与分子长度的无界覆盖由上述父式承担。允许 `5|b_1b_2` 或
`m_2>=3` 的其它五进一位尾状态仍待证。

机械核对继续使用 §10.5 的专用脚本；新增部分遍历小样本只核对 source
dictionary 和 `mod5/mod25` unit projection，无界覆盖由以上赋值及
整除推导承担。

---

## 12. 状态摘要

- **已严格完成：** `v|H_sph`、`D0-parent`、`V-parent`；
- **已严格完成：** coprime `d_0 × v` gap CRT；
- **已严格完成：** `a<d_0v` ordinary gap reconstruction；
- **已严格完成：** `a>=d_0v => F_->Q^2v^3` 与 slope consequence；
- **已严格完成：** odd-source stripped depth `r_p^(d0)=(c-t-(j-E)_+)_+`；
- **已严格完成：** `D_d0|C_Q` 且 `X_NX_H|D_d0`；
- **已严格完成：** decimal circular normalization只移动完整 `10`-powers，`r_d0,circ<=m2/2`；
- **已严格完成（非有效渐近，限 canonical one-channel）：**
  `(Canonical-small-gap-location)` 与 `delta<=1/2` 的 large-gap 无界子支排除；
- **已严格完成（同一渐近输入）：** fixed `delta_0<0.276446568952787...`
  时 `a<min(d_0,v)` 与两个单独的 ordinary gap readers；
- **已严格完成（一般一位尾分母）：** `m_3=1 => v=1`，完整排除该层
  的 `v>1` source state；unique-five-tail `b_3=5,5∤b_1b_2` 必须
  `Q=24 mod25`、两前缀分母奇；允许 ordinary source仍待证；
- **已严格完成（无界 state 关闭）：** `b_3=5,5∤b_1b_2,1<=m_2<=2,n_3>1`
  的 unique-five-tail / 至多两位第二分母 state为空；
- **边界：** `D0-failure-Fminus` 的 universal constant弱于现有 `7/8` failure lower，不能重复收费；本 theorem的新增收益集中在 enlarged ordinary modulus 与 gap CRT dichotomy；
- **未证明：** small-gap CRT lift不可能、ordinary d0 circular lock不可能、post-tail 全局 strict gap、DD emptiness。
