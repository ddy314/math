# `double-deficit`（DD）分支

DD 指第三分子比第三分母长、前两块的联合十进制缺口为正的异常分支。
其规范记号与原方程见 [core.md](core.md)。本分支整体仍为 **待证**；
下表的闭合仅在列出的作用域内成立。

## 当前严格状态

| 结论 | 作用域与证明入口 | 未覆盖部分 |
|---|---|---|
| **完整关闭** 后两分母一位的 DD 整层 | `m_2=m_3=1,n_3>=2`；第一分母与全部分子最初无界。[core §27.7.5](core.md#single-digit-last-two-denominators-complete-dd-certificate) 先作完整 denominator / numerator 高度归约，再给十九状态精确证书 | 第二或第三分母更长 |
| **完整关闭** 第二分母两位、尾分母四或八的 DD 子层 | `m_2=2,b_3=4/8,n_3>=2,n_2+n_3>3`；[core §27.7.6](core.md#two-digit-second-eight-tail-complete-dd-certificate) 八尾五状态完整证书与 [四尾尺度转移](core.md#two-digit-second-four-tail-scaling-corollary) | 其它尾分母；`k_12<=0` |
| **完整关闭** 一位偶尾的 third-two-dominant state | `b_3=2/4/6/8,n_3>=2` 且第三分母独占二进最高 depth；前缀最初无界。[core §27.7.4](core.md#single-digit-tail-third-two-dominant-closure) | prefix-two-dominant；奇尾 |
| **完整关闭** unique-five-tail 且第二分母至多两位 | `b_3=5,5∤b_1b_2,1<=m_2<=2,n_3>=2`；[gcd-normal §11.2](dd-gcd-normal-d0-gap-crt-dichotomy-2026-09-06.md#single-digit-five-tail-unit-prefix-closure)，无 original-numerator 枚举 | `5|b_1b_2`；`m_2>=3` |
| **无界 residue states 排除** | 全奇分母：`m_3=2,Qb_3=3 mod4`；`m_3>=3,Qb_3=1 mod4`；均要求 `n_3>m_3`。[core §27.7.1](core.md#all-odd-decimal-norm-mod4-exclusion) 另给 `m_3=1` 的 exact depth/residue 排除 | 允许 residues 与明确保留的 tie states |
| **非有效渐近排除** canonical large gap | corrected canonical one-channel `delta<=1/2` 的 `a>=d_0v` 无界序列；[gcd-normal §10](dd-gcd-normal-d0-gap-crt-dichotomy-2026-09-06.md#canonical-large-gap-exclusion) | finite exceptions；ordinary small gap；noncanonical |
| **非有效渐近排除** canonical `Z=3 mod4` | 同一 `delta<=1/2` neighborhood；[two-adic §6.1](dd-corrected-terminal-two-adic-uz-neighborhood-2026-08-22.md#canonical-decimal-norm-z-mod4) | finite exceptions；`Z=1 mod4` |
| **结构归约**，不等于空性 | 一位第三分母公开条件 `b_3|10Q`，DD 中 `v=1`；[gcd-normal §11](dd-gcd-normal-d0-gap-crt-dichotomy-2026-09-06.md#single-digit-tail-v-one) | 一般前缀的 ordinary source 兼容性 |
| **稀疏计数与条件唯一性**，不等于空性 | fixed `delta_0<1/2` 的非循环 joint count 与 two-channel conditional period；[sparsity](dd-corrected-terminal-global-sparsity-sharp-2026-09-06.md)、[orientation audit](dd-corrected-quartic-orientation-dependency-audit-2026-09-06.md#ordinary-gap-full-word-dictionary) | 联合参数族仍可能非空 |

各 theorem 的 exact hypotheses 与完整推导以链接正文为准。渐近排除没有
可计算的绝对 `S` cutoff；有限证书只有在已证明全局 bounds 后才承担
上述无界 slice 的闭合。中央跨分支结论见 [global-framework.md](../../global-framework.md)。

## 阅读顺序

1. [core.md](core.md)：DD 原记号、tail normalization、exact identities 与现行低层闭合。
2. [frontier.md](frontier.md)：terminal / one-channel 主线。
3. [good-genuine-ledger.md](good-genuine-ledger.md)、[high-funnel-ledger.md](high-funnel-ledger.md)、[tail-allocation-ledger.md](tail-allocation-ledger.md)：按依赖保留的推导与来源。
4. 下方 canonical 与 post-tail 专题；全局状态仍由 [status.md](../../status.md) 统一维护。

## 2026-08-22 corrected terminal 基线

从 corrected Schmidt / quantitative defect、digit polarization、one-channel
neighborhood 进入；其它局部 readers 与 entropy 专题保留如下。

<details>
<summary>Corrected 基线专题索引</summary>

- [dd-corrected-carry-u-pairmax-crt-2026-08-22.md](dd-corrected-carry-u-pairmax-crt-2026-08-22.md)
- [dd-corrected-gap-fiber-pairmax-rational-reconstruction-2026-08-22.md](dd-corrected-gap-fiber-pairmax-rational-reconstruction-2026-08-22.md)
- [dd-corrected-high-funnel-quantitative-defect-2026-08-22.md](dd-corrected-high-funnel-quantitative-defect-2026-08-22.md)
- [dd-corrected-high-funnel-schmidt-2026-08-22.md](dd-corrected-high-funnel-schmidt-2026-08-22.md)
- [dd-corrected-neighborhood-decimal-top-residue-2026-08-22.md](dd-corrected-neighborhood-decimal-top-residue-2026-08-22.md)
- [dd-corrected-neighborhood-gap-fiber-entropy-2026-08-22.md](dd-corrected-neighborhood-gap-fiber-entropy-2026-08-22.md)
- [dd-corrected-neighborhood-pairmax-fixed-crt-2026-08-22.md](dd-corrected-neighborhood-pairmax-fixed-crt-2026-08-22.md)
- [dd-corrected-neighborhood-square-source-crt-2026-08-22.md](dd-corrected-neighborhood-square-source-crt-2026-08-22.md)
- [dd-corrected-pairmax-short-suffix-reader-2026-08-22.md](dd-corrected-pairmax-short-suffix-reader-2026-08-22.md)
- [dd-corrected-schmidt-farey-slack-2026-08-22.md](dd-corrected-schmidt-farey-slack-2026-08-22.md)
- [dd-corrected-source-carry-epsilon-cancellation-2026-08-22.md](dd-corrected-source-carry-epsilon-cancellation-2026-08-22.md)
- [dd-corrected-source-carry-sigma-overlap-2026-08-22.md](dd-corrected-source-carry-sigma-overlap-2026-08-22.md)
- [dd-corrected-terminal-denominator-sunit-entropy-2026-08-22.md](dd-corrected-terminal-denominator-sunit-entropy-2026-08-22.md)
- [dd-corrected-terminal-digit-polarization-2026-08-22.md](dd-corrected-terminal-digit-polarization-2026-08-22.md)
- [dd-corrected-terminal-neighborhood-geometry-2026-08-22.md](dd-corrected-terminal-neighborhood-geometry-2026-08-22.md)
- [dd-corrected-terminal-one-channel-neighborhood-2026-08-22.md](dd-corrected-terminal-one-channel-neighborhood-2026-08-22.md)
- [dd-corrected-terminal-rough-source-neighborhood-2026-08-22.md](dd-corrected-terminal-rough-source-neighborhood-2026-08-22.md)
- [dd-corrected-terminal-rough-source-sharp-2026-08-22.md](dd-corrected-terminal-rough-source-sharp-2026-08-22.md)
- [dd-corrected-terminal-two-adic-uz-neighborhood-2026-08-22.md](dd-corrected-terminal-two-adic-uz-neighborhood-2026-08-22.md)

</details>

## 2026-09-06 canonical denominator / scale / numerator / orientation attack

### 严格结果摘要

当前 denominator / S-unit 结构给 common scale ray；fixed `(H,T,V)`
恢复 `(U,Z)`。ordinary product lock 的作用域为
`delta<0.191116422381969...`；source quotient `q<v_2` 的作用域为
`delta<0.460744281587979...`。这些均不排除 joint original candidates。

在任意 fixed `delta_0<1/2` 内，枚举 `a_2` 后的 gap reader与两条 chosen
Gaussian sheets 给 fixed `(denominators,S-units,lengths,a_2,gap,orientations)`
fiber 的 `A_12` period `Uv_1^2v_2`，其高度最终超过 prefix word。
当前安全计数为

```math
N_{\rm num}\le10^{n_2+o(S)},\qquad
N_{\rm term}(S;\delta_0)\le10^{(\delta_0/\lambda)S+o(S)},
\quad\lambda=1.436294525872677\ldots.
```

Global exponent 由 denominator entropy与保留的 short-suffix entropy共用
同一份预算得到；不是 fixed-denominator numerators 单独 subexponential。
[ordinary full-word dictionary](dd-corrected-quartic-orientation-dependency-audit-2026-09-06.md#ordinary-gap-full-word-dictionary)
明列两个单独 ordinary residues与实际 selected-sheet variables。
[decimal norm projection](dd-corrected-quartic-orientation-dependency-audit-2026-09-06.md#decimal-norm-selected-sheet-projection)
只在 `10^(s_2+d)±1` 或 `10^d±1` 的 cyclotomic overlap 上收费；其它
target primes 两 sheets均为 units。W-free rationalization仍有
`J_V>q_V,K_V>q_V` 的结构性 no-go，不能删除 orientation 后宣称第二 parent。

### 文件索引

- [dd-corrected-common-scale-ray-2026-09-06.md](dd-corrected-common-scale-ray-2026-09-06.md)
- [dd-corrected-common-scale-ray-sharp-2026-09-06.md](dd-corrected-common-scale-ray-sharp-2026-09-06.md)
- [dd-corrected-denominator-product-lock-2026-09-06.md](dd-corrected-denominator-product-lock-2026-09-06.md)
- [dd-corrected-denominator-product-lock-sharp-2026-09-06.md](dd-corrected-denominator-product-lock-sharp-2026-09-06.md)
- [dd-corrected-numerator-collapse-sharp-2026-09-06.md](dd-corrected-numerator-collapse-sharp-2026-09-06.md)
- [dd-corrected-pairmax-scale-quotient-2026-09-06.md](dd-corrected-pairmax-scale-quotient-2026-09-06.md)
- [dd-corrected-quartic-orientation-dependency-audit-2026-09-06.md](dd-corrected-quartic-orientation-dependency-audit-2026-09-06.md)
- [dd-corrected-scale-free-secondary-carrier-2026-09-06.md](dd-corrected-scale-free-secondary-carrier-2026-09-06.md)
- [dd-corrected-scale-free-secondary-norm-prefix-nogo-2026-09-06.md](dd-corrected-scale-free-secondary-norm-prefix-nogo-2026-09-06.md)
- [dd-corrected-source-quotient-lock-sharp-2026-09-06.md](dd-corrected-source-quotient-lock-sharp-2026-09-06.md)
- [dd-corrected-sunit-euclidean-lock-2026-09-06.md](dd-corrected-sunit-euclidean-lock-2026-09-06.md)
- [dd-corrected-terminal-global-sparsity-sharp-2026-09-06.md](dd-corrected-terminal-global-sparsity-sharp-2026-09-06.md)
- [dd-corrected-v2-projective-polarization-2026-09-06.md](dd-corrected-v2-projective-polarization-2026-09-06.md)

## 2026-09-06 post-tail / global decimal attack

### Folding → Euclidean → circular

Full decimal folding、Euclidean remainder 与合法完整 `10`-power phase
shifting 给 `r_circ<=m_2/2`。ordinary circular-lock failure 已无匿名 residual，
并严格满足

```math
\log_{10}F_-\ge S-r_{\rm circ}/4-o(S)\ge7S/8-o(S).
```

这是 failure-side payer accounting；ordinary-lock success 仍需额外的
原始 full-concat / moving-target 约束。

### gcd-normal `d_0` gap CRT

整个 DD gcd-normal tail 严格有 `v|H_sph`。互素 `d_0,v` 同时读取
gap quotient `a`：`0<a<d_0v` 时唯一普通重构；`a>=d_0v` 时
`F_->Q^2v^3`。两个 readers消去 `H_0` 只回到原 source-gap determinant，
不是两个 independent budgets。

### 2026-09-30 canonical large-gap 子支排除

共享 Schmidt / short-head / two-depth 预算给

```math
\frac1S\log_{10}\frac{a}{d_0v}
\le-1.691116422381968\ldots+\frac52\delta+o(1).
```

因此 canonical `delta<=1/2` 无界序列最终进入普通 small-gap 支。
更窄的 fixed `delta_0<0.276446568952787...` 内最终有
`a<min(d_0,v)`，两个 least residues都等于 `a`。证明不依赖 candidate
计数，且没有 effective cutoff。

### 文件索引

- [dd-corrected-circular-failure-no-residual-fminus-2026-09-06.md](dd-corrected-circular-failure-no-residual-fminus-2026-09-06.md)
- [dd-corrected-euclidean-failure-denominator-gcd-bootstrap-2026-09-06.md](dd-corrected-euclidean-failure-denominator-gcd-bootstrap-2026-09-06.md)
- [dd-corrected-euclidean-failure-no-residual-fminus-2026-09-06.md](dd-corrected-euclidean-failure-no-residual-fminus-2026-09-06.md)
- [dd-corrected-euclidean-failure-soft-norm-bootstrap-2026-09-06.md](dd-corrected-euclidean-failure-soft-norm-bootstrap-2026-09-06.md)
- [dd-corrected-hard-source-split-2026-08-22.md](dd-corrected-hard-source-split-2026-08-22.md)
- [dd-gcd-normal-d0-gap-crt-dichotomy-2026-09-06.md](dd-gcd-normal-d0-gap-crt-dichotomy-2026-09-06.md)
- [dd-gcd-normal-multiplicative-fminus-lower-2026-08-22.md](dd-gcd-normal-multiplicative-fminus-lower-2026-08-22.md)
- [dd-global-circular-decimal-phase-hard-source-lock-2026-09-06.md](dd-global-circular-decimal-phase-hard-source-lock-2026-09-06.md)
- [dd-global-euclidean-block-folding-hard-source-lock-2026-09-06.md](dd-global-euclidean-block-folding-hard-source-lock-2026-09-06.md)
- [dd-global-sixfold-baseline-stripped-deephard-lock-2026-09-06.md](dd-global-sixfold-baseline-stripped-deephard-lock-2026-09-06.md)
- [dd-global-sixfold-decimal-folding-source-lock-2026-09-06.md](dd-global-sixfold-decimal-folding-source-lock-2026-09-06.md)
- [dd-global-sixfold-gcd-stripped-master-lock-2026-09-06.md](dd-global-sixfold-gcd-stripped-master-lock-2026-09-06.md)
- [dd-global-sixfold-primitive-hard-source-lock-2026-09-06.md](dd-global-sixfold-primitive-hard-source-lock-2026-09-06.md)
- [dd-hard-source-determinant-gap-charge-2026-08-22.md](dd-hard-source-determinant-gap-charge-2026-08-22.md)

## 历史 / 依赖边界

- 旧 fixed-denominator `N_num=10^{o(S)}` 漏掉 fixed gap / fixed suffix 的
  条件循环，已降级；fixed-gap、fixed-`a_2` 的各自唯一性不能推出联合族唯一。
  当前非循环 joint exponent 使用 `a_2` 枚举与同一共享预算恢复。
- Unified discriminant-root identification 与 suspended `general-transfer`
  不能重新作为依赖；[general-transfer correction](dd-general-transfer-correction-2026-08-22.md)
  和 [root dependency audit](dd-discriminant-root-dependency-audit-2026-08-22.md) 为纠错入口。
- 同源 Hensel、Gaussian norm、radius 或消元 rewrite 不提供第二份 payer；
  inert source prime 的 decimal norm valuation可由原 baseline自动满足。
- 外部 SGR-9 仅在 frozen top-DD hypotheses 下成立，不能升级成一般 DD闭合；
  见 [integration audit](../../integration-audit-2026-09-06.md)。

<details>
<summary>Gaussian / frontier / 历史专题索引（状态以正文为准）</summary>

- [dd-discriminant-root-dependency-audit-2026-08-22.md](dd-discriminant-root-dependency-audit-2026-08-22.md)
- [dd-frontier-a3-triple-crt-residual-2026-08-22.md](dd-frontier-a3-triple-crt-residual-2026-08-22.md)
- [dd-frontier-genuine-radius-pairmax-collapse-2026-08-22.md](dd-frontier-genuine-radius-pairmax-collapse-2026-08-22.md)
- [dd-frontier-good-digit-shell-local-closure-2026-08-22.md](dd-frontier-good-digit-shell-local-closure-2026-08-22.md)
- [dd-frontier-phase-normalized-secondary-norm-2026-08-22.md](dd-frontier-phase-normalized-secondary-norm-2026-08-22.md)
- [dd-frontier-projective-source-pairmax-polarization-2026-08-22.md](dd-frontier-projective-source-pairmax-polarization-2026-08-22.md)
- [dd-frontier-qz-complementary-collapse-2026-08-22.md](dd-frontier-qz-complementary-collapse-2026-08-22.md)
- [dd-frontier-secondary-quadratic-reciprocity-2026-08-22.md](dd-frontier-secondary-quadratic-reciprocity-2026-08-22.md)
- [dd-frontier-source-core-projective-denominator-2026-08-22.md](dd-frontier-source-core-projective-denominator-2026-08-22.md)
- [dd-frontier-source-gaussian-divisor-2026-08-22.md](dd-frontier-source-gaussian-divisor-2026-08-22.md)
- [dd-frontier-source-orientation-euclidean-quotient-2026-08-22.md](dd-frontier-source-orientation-euclidean-quotient-2026-08-22.md)
- [dd-gaussian-deep-core-2026-08-21.md](dd-gaussian-deep-core-2026-08-21.md)
- [dd-gaussian-oriented-transversality-2026-08-21.md](dd-gaussian-oriented-transversality-2026-08-21.md)
- [dd-gaussian-overlap-stripped-2026-08-21.md](dd-gaussian-overlap-stripped-2026-08-21.md)
- [dd-general-transfer-correction-2026-08-22.md](dd-general-transfer-correction-2026-08-22.md)
- [dd-good-digit-shell-rational-collapse-2026-08-22.md](dd-good-digit-shell-rational-collapse-2026-08-22.md)
- [dd-tail-root-unit-hensel-collapse-2026-08-22.md](dd-tail-root-unit-hensel-collapse-2026-08-22.md)
- [dd-third-excess-collapse-2026-08-21.md](dd-third-excess-collapse-2026-08-21.md)
- [dd-ultrahard-tail-root-sign-collapse-2026-08-22.md](dd-ultrahard-tail-root-sign-collapse-2026-08-22.md)
- [dd-z0-charged-first-2026-08-21.md](dd-z0-charged-first-2026-08-21.md)
- [tail-rough-angular-coefficient-stripped.md](tail-rough-angular-coefficient-stripped.md)
- [tail-rough-z0-angular-only-collapse.md](tail-rough-z0-angular-only-collapse.md)
- [tail-rough-z0-two-sheet-collapse.md](tail-rough-z0-two-sheet-collapse.md)

</details>

## 机械审计

所有细粒度核对位于 `scripts/exact-lift/double-deficit/research-checks/tail/`。

| 证书 / 核对 | 覆盖与角色 |
|---|---|
| [last-two single-digit Python](../../../../../scripts/exact-lift/double-deficit/research-checks/tail/check_dd_last_two_single_digit_denominators.py) / [独立 C++](../../../../../scripts/exact-lift/double-deficit/research-checks/tail/check_dd_last_two_single_digit.cpp) | `m_2=m_3=1,n_3>=2`，完整全局 bounds 后 `3,759,479` 行；standard/factored四遍零解 |
| 同一 Python 入口 `--tail-eight-second-two` / `--four-tail-scaling-only` | `m_2=2,b_3=8` 的完整 DD 子层，两 reader 各 `103,548,188` 行无长度预筛零解；四尾完整 projection 经严格尺度转移关闭，零新增分子枚举 |
| [single-digit denominators](../../../../../scripts/exact-lift/double-deficit/research-checks/tail/check_dd_single_digit_denominators.py) | 三分母一位的独立无 norm 预筛证书 `24,621,966` 行；另含 third-two-dominant `(17,6,8)` 的 `7020` 行 extension |
| [unit-prefix modular certificate](../../../../../scripts/exact-lift/double-deficit/research-checks/tail/check_dd_unit_prefix_single_digit_tail.py) | [core §27.7.2](core.md#unit-prefix-single-digit-tail-closure) 的短同余证明；可选旧有界 audit不作新成果 |
| [gcd-normal checks](../../../../../scripts/exact-lift/double-deficit/research-checks/tail/check_dd_gcd_normal_d0_gap_crt_dichotomy.py) | 原 parents、共享预算、ordinary CRT字典与一位尾 denominator/unit推导的 exact核对 |
| [numerator / norm checks](../../../../../scripts/exact-lift/double-deficit/research-checks/tail/check_dd_corrected_numerator_collapse_sharp.py) | 条件 period、norm恒等式、selected-sheet 投影与 exact depth边界；不证明一般空性 |

运行各正文列出的 certificate命令后，用 `uv run python scripts/proof_tree.py check`
与 `git diff --check` 核对结构。结构检查不是数学证明器；有限 toy instances
也不能替代正文的无界推导。

## 当前边界

**Canonical terminal：** 剩余无界核心是 `Z=1 mod4`、ordinary small-gap 的
joint suffix / gap / moving orientation / scale-free source兼容性。需要
原 full-concat 的额外独立约束，或真正 oriented 的 deterministic location。
条件唯一性和 sparse counts都保留非空的可能。

**Post-tail / noncanonical：** ordinary circular-lock / source-gap CRT 成功支
仍开放；一位尾中的 `v>1` 已排，但一般前缀的 `v=1` 族尚未全关。
现行低层闭合与共享预算均不能外推为 `DD=empty`。下一目标仍是第二个
独立原始 parent / global moving-target control，而不是重复同源 payer。
