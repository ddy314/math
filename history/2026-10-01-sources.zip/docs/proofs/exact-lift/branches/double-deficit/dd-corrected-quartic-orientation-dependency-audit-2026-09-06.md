# DD corrected quartic / product-orientation dependency audit

> 日期：2026-09-06
>
> 依赖：[`dd-corrected-scale-free-secondary-carrier-2026-09-06.md`](dd-corrected-scale-free-secondary-carrier-2026-09-06.md)、[`dd-corrected-v2-projective-polarization-2026-09-06.md`](dd-corrected-v2-projective-polarization-2026-09-06.md)、`dd-frontier-secondary-quadratic-reciprocity-2026-08-22.md`、`good-genuine-ledger.md` 中 W-free fixed `A_12` CRT，以及 [`dd-discriminant-root-dependency-audit-2026-08-22.md`](dd-discriminant-root-dependency-audit-2026-08-22.md)。
>
> **状态：依赖审计 / no-go 定位。** 本文不新增 slope bound。目标是回答一个具体问题：2026-09-06 已经把 chosen pair-max orientation正规化成 neighborhood-valid `Pi_Omega | (...)` 后，能否立刻用 quartic reciprocity把它与 denominator prefix闭环？结论是：当前安全 parent family 中仍缺第二个 genuinely orientation-sensitive reader；只使用 rational prefix/phase/Top-residue/W-free CRT 时，quartic product orientation没有独立的交换端。

---

## 1. 当前安全的 chosen orientation parent

2026-09-06 已证明整个 corrected one-channel neighborhood存在

\[
\boxed{
\Pi_\Omega\mid
A_V2^{m-2}q_V-iB_V5^{2T-m},
\qquad N(\Pi_\Omega)=v_2,}
\]

其中

\[
A_V=g_0a_2v_1,
\qquad
B_V=R_0\tau_2.
\]

这条确实区分 `Pi_Omega` 与其 conjugate，并且完全避开旧 discriminant-root identification。

但它来自 pair-max orientation + gap reconstruction；因此与 raw pair-max line

\[
\Pi_\Omega^2\mid y_2+i y_3
\]
属于同一个 sphere/orientation parent family，不能把二者当成两个 independent orientation readers。

---

## 2. rational parents 对 conjugation 不敏感

当前其它安全的强结构包括：

\[
Uq_V=b_1^{(V)}10^{m_2}+v_2\tau_2,
\]

\[
2^HZ-5^TU=v_1v_2,
\]

Top-residue / exact carry，及 W-free fixed `A_12` CRT。

这些 identities 中 pair-max moving object只通过 rational integer

\[
\boxed{v_2=N(\Pi_\Omega)=\Pi_\Omega\overline{\Pi_\Omega}}
\]
出现。因此它们在形式上全部保持 involution

\[
\boxed{
\Pi_\Omega\longleftrightarrow\overline{\Pi_\Omega}.}
\tag{Conjugation-blind}
\]

也就是说，单靠这些 rational parents最多读取：

- rational splitting `p=pi bar pi`；
- norm / quadratic character；
- `v_2` 的 ordinary residue；

但不能选择 `pi` 与 `bar pi` 中哪一个是 candidate 的 actual orientation。

---

## 3. W-free genuine CRT 仍是 rational sphere-paid reader

`good-genuine-ledger.md` 的 W-free fixed `A_12` CRT使用已经 sphere-paid 的 rational carrier

\[
\Theta=(\kappa+G)A_c\beta+\mathscr T a_3^2,
\qquad C_G^2\mid\Theta,
\]

再结合 exact carry得到一个 fixed linear congruence modulo `C_G`。

它的重要价值是去掉旧 coefficient 中的 discriminant root `W`；但最终 reader仍然是 rational `A_12 mod C_G`，并不携带一个独立 Gaussian prime product whose conjugate choice is fixed by a different parent.

因此它可继续用于 CRT / numerator reconstruction，却不能直接作为 quartic reciprocity的第二 orientation endpoint。

---

## 4. 旧 discriminant Gaussian carrier 当前不可作为替代

历史 genuine/frontier 账本中确实存在看起来“independent-looking”的第二 Gaussian carrier，其中 chosen pair-max prime会与 discriminant/tail-root carrier比较。

但当前 canonical dependency audit已经明确：旧 DD 证明曾错误识别两个 discriminant roots；凡依赖该 identification 的 orientation/valuation continuation都必须重新证明，不能作为现行 strict-gap parent直接调用。

因此在没有完成新的 W-free Gaussian-valued replacement前，不能用这条历史 carrier补足 quartic reciprocity的第二端。

---

## 5. ordinary quadratic reciprocity为什么只能给有限 character

旧 corrected frontier secondary theorem已经从 chosen Gaussian source line安全导出 quadratic character compatibility：main pair-max primes除了 `p=1 mod 4` 外，还满足一个额外 moving quadratic splitting condition。

这是真约束，但每个 prime只增加有限 `+/-1` character；对应 prime set仍可有正密度。因此它不能单独制造 `exp(-epsilon S)` 级 height saving。

quartic reciprocity若要真正升级，必须保留 `pi/bar pi` 的 chosen orientation。由 §§2--4，当前 safe rational parents无法提供独立的 conjugation-sensitive comparison，所以仅把 quadratic symbol机械替换成 quartic symbol不会自动产生闭环。

---

## 6. 成功标准

后续 quartic/product-orientation attack只有在找到以下任一对象后才值得继续：

1. 一个 W-free Gaussian integer `G_dec`，来自 genuinely different decimal/full-concat parent，并满足 selected `pi_p` 对 `G_dec` 的 divisibility/orientation；
2. 一个 global product sign/argument invariant，能区分 `Pi_Omega` 与 `bar Pi_Omega`，且不是 pair-max sphere line本身的重写；
3. 一个 deterministic Archimedean sector for `Delta_V` whose conjugate sector is forbidden by decimal digit data。

在此之前，继续对 rational prefix、phase、Top-residue、`K_V`、`J_V` 取 norm/Jacobi/quartic symbols都不会新增独立 parent。

---

<a id="ordinary-gap-full-word-dictionary"></a>

## 7. 2026-09-30 ordinary gap / full word / 两-channel orientation 字典

**严格状态：已严格完成（exact 字典与 conditional period）；未得到新的
independent orientation height payer。** 本节接续
[`d_0` 专题 §10](dd-gcd-normal-d0-gap-crt-dichotomy-2026-09-06.md#canonical-large-gap-exclusion)，
明确区分 original full-word equation、ordinary gap location 与 chosen
Gaussian sheets 的依赖。以下均在 corrected canonical `t_2=1` chart 内使用。

### 7.1 统一两个 gap 记号

令 `F=5^T`，并把 canonical source 写成 `q_src`，以区别一般 gcd-normal
reduced source `q_red`。有

\[
u=2FU,\qquad v=V=v_1v_2,\qquad Q=Uq_{\rm src},
\qquad B=\frac{10^m}{2F}.
\]

由于 `(U,2FV)=1`，写

\[
\xi:=(2F,q_{\rm src})
\]

即得到 exact dictionary

\[
\boxed{
d_0=U\xi,\qquad L=\frac{2F}{\xi},\qquad
q_{\rm red}=\frac{q_{\rm src}}\xi,\qquad
\omega=B\xi,\qquad v=V.}
\tag{Gap-chart-dictionary}
\]

注意 `xi` 只含 `2,5`；这里不把它与旧 overlap notation中的 `eta`
混同。`c_i=q_lcm/b_i`，sphere gap为

\[
H_{\rm sph}-y_3=La.
\]

旧 primitive gap fraction的定义于是精确等于

\[
\boxed{
\frac{R_0}{g_0}
=\frac{H_{\rm sph}-y_3}{2Fc_3}
=\frac{a}{\xi c_3}.}
\tag{Ordinary-primitive-gap-dictionary}
\]

因此令 `h_a=(a,xi c_3)`，则

\[
\boxed{R_0=a/h_a,\qquad g_0=\xi c_3/h_a.}
\tag{Reduced-gap-dictionary}
\]

本轮 `a` 的 exponentially small ordinary window约束这个原有 fraction；
它没有引入第二个独立 gap variable。

### 7.2 original full-concat equation恰被 exact gap determinant吸收

完整 decimal words为

\[
\mathsf A=A_{12}10^n+a_3,\qquad
\mathsf B=Q10^m+b_3,
\qquad d=n-m.
\]

在 `y_3=a_3c_3`、`b_3=omega tau`、`10^m=omega L` 与
`H_sph-y_3=La` 已建立后，original equality

\[
q_{\rm lcm}\mathsf A=H_{\rm sph}\mathsf B
\]

**等价于**

\[
\boxed{q_{\rm lcm}A_{12}10^d-QH_{\rm sph}=\tau a.}
\tag{Full-word-gap-equivalence}
\]

两方向都只是乘除 `10^m`：右侧乘 `10^m` 等于
`b_3 La=b_3H_sph-q_lcm a_3`。再代入 gcd-normal data与
`H_sph=VH_0`，便得到原先的两个 parents

\[
\omega c_3 A_{12}10^d=a+d_0H_0,
\qquad VH_0=a_3c_3+La.
\]

消去 `H_0` 并代入 `(Gap-chart-dictionary)` 与
`(Ordinary-primitive-gap-dictionary)`，恰恢复 exact carry

\[
\boxed{
Ua_3=BV10^d A_{12}-\Sigma\frac{R_0}{g_0},
\qquad\Sigma=2FU+V.}
\tag{Full-word-carry-dictionary}
\]

所以把 ordinary `a` 再代回完整 word 的**代数 equality**，不会产生一个尚未
被 determinant/carry吸收的新 parent。剩余 original constraints是各块实际的
digit intervals、reducedness和 sphere/orientation compatibility；不能把
`(Full-word-gap-equivalence)` 作为第二份 height lower。

### 7.3 两个 selected Gaussian sheets及其实际 effective periods

对 `i=1,2`，general moving-core sphere theorem给 chosen Gaussian products

\[
N(\Pi_i)=v_i,\qquad \Pi_i^2\mid y_i+i y_3.
\tag{Two-selected-sheets}
\]

这里 Gaussian imaginary unit与下标 `i` 区分理解。逐 `p^h||v_i`，equivalent
reader是某个 selected Hensel root `iota_{i,p}`，满足

\[
\iota_{i,p}^2\equiv-1\pmod{p^{2h}},\qquad
c_i a_i+\iota_{i,p}c_3a_3\equiv0\pmod{p^{2h}}.
\tag{Two-sheet-local-readers}
\]

这些 target primes均 `p∤10 U c_i c_3 g_0`。将 carry代入，得到 W-free
full-prefix expression

\[
\boxed{
g_0Uc_i a_i
+\iota_{i,p}c_3
\bigl(g_0BV10^dA_{12}-\Sigma R_0\bigr)
\equiv0\pmod{p^{2h}}.}
\tag{Two-sheet-full-prefix}
\]

它区分 chosen sheets，但仍属于原 sphere/orientation parent加上 exact carry；
不是一个独立于 sphere的第二 orientation parent。

不过该式可以安全加强**条件重构 period**。固定 denominator/S-unit data、
全部 digit lengths、`a_2`、primitive fraction `(R_0,g_0)`，以及两个 channels
上的 selected Hensel roots。若同一 fiber有两个 candidates，记
`Delta A=A_12'-A_12`。Carry先给

\[
U\Delta a_3=BV10^d\Delta A,\qquad U\mid\Delta A.
\tag{Two-sheet-carry-difference}
\]

对 `p^h||v_2`，`a_2` fixed，故 selected sheet相减给

\[
p^{2h}\mid c_3\Delta a_3.
\]

使用 `(Two-sheet-carry-difference)` 与 `v_p(V)=h`，得到
`p^h|Delta A`，即原来的 `v_2` period。

对 `p^h||v_1`，因为 `a_1=(A_12-a_2)/10^{n_2}`，相减并乘
`U10^{n_2}` 得

\[
\boxed{
\left(Uc_1+\iota_{1,p}c_3BV10^{d+n_2}\right)\Delta A
\equiv0\pmod{p^{2h}}.}
\tag{First-sheet-unit-coefficient}
\]

括号第一项是 p-unit，第二项被 `p^h` 整除，所以整个 coefficient是
p-unit。因此 `p^{2h}|Delta A`，聚合得到

\[
\boxed{v_1^2\mid\Delta A.}
\tag{First-sheet-square-period}
\]

`U,v_1,v_2` 两两互素，故这一明写条件的 fiber具有 exact joint period

\[
\boxed{P_{\rm 2sh}:=Uv_1^2v_2=UVv_1\mid\Delta A.}
\tag{Two-sheet-conditional-period}
\]

由 common-scale sharp theorem的 `log_10(UV)/S>=1+U_*-delta-o(1)`，
有

\[
\frac{\log_{10}P_{\rm 2sh}}S
\ge1+U_*-\delta-o(1).
\]

因为 `U_*=0.691116...>1/2`，整个 fixed `delta_0<1/2` neighborhood中，
eventually `P_2sh>10^{S+2}`。而 `0<A_12<10^{S+2}`，故 fixed
`a_2+gap+two-sheet orientations` 的 `A_12` 至多一个，carry随后唯一恢复
`a_3`。这是 conditional uniqueness，不能自行消除未固定的 `a_2/gap` 联合族。

### 7.4 机械核对与下一目标

对应 algebra / prime-power / conditional-uniqueness 核对已加入

```bash
UV_CACHE_DIR=/tmp/math-uv-cache uv run python scripts/exact-lift/double-deficit/research-checks/tail/check_dd_corrected_numerator_collapse_sharp.py
```

计算只核对字典、full-word equivalence、unit-coefficient depth以及计数修复的
bookkeeping，不承担无界 coverage。下一需要解决的具体对象仍是满足真实
digit intervals的 **joint ordinary gap/suffix/orientation family**；反复对
`(Two-sheet-full-prefix)` 与 raw sphere line作 resultant只会消去同源参数。

<a id="decimal-norm-selected-sheet-projection"></a>

### 7.5 denominator-only norm 的实际 selected-sheet 投影

**严格状态：已严格完成（局部 exact projection / 非独立 payer 审计）。**
[`global-framework.md §10.2`](../../global-framework.md#denominator-word-norm)
从 original full-word plane 与 sphere 得到 denominator-only Gaussian norm。
这里记录其真实 chosen-sheet 接口，不能将一个 norm 条件自动视作第二个
全 `V` orientation endpoint。

写 `n=n_3,m=m_3,d=n-m`，并定义原 decimal coefficients

\[
t_1=b_1 10^{n_2+n},\qquad t_2=b_2 10^n,\qquad t_3=b_3,
\qquad D=Q10^m+b_3.
\]

令 `s=H+y_3>0`，则该 Gaussian integer 为

\[
G_{\rm dec}=(D+t_3)(y_1+i y_2)-(t_1+i t_2)s,
\qquad N(G_{\rm dec})=\Delta_{\rm dec}s^2,
\quad \Delta_{\rm dec}=\sum_jt_j^2-D^2.
\tag{Decimal-norm-carrier}
\]

它同时是 [core.md §51](core.md) denominator-only circle 的整系数表达；
其中 sphere 与 original coefficient plane 仍是同两个 parents。其 inert-prime
norm obstruction 是有效必要条件，但并未产生一份新的 Archimedean height
预算，尤其不能重新收费 §§1--3 的 sphere-paid depths。

对 `p^h||v_2`，使用
[`pair-max scale quotient`](dd-corrected-pairmax-scale-quotient-2026-09-06.md)
的 exact low-baseline `r_p=v_p(q_src)`；令

\[
\ell_2=\prod_{p^h\Vert v_2}p^{r_p},\qquad
b_j^{(2)}=b_j/\ell_2,
\qquad (t_j^{(2)},D^{(2)},G_{\rm dec}^{(2)})
=(t_j,D,G_{\rm dec})/\ell_2.
\tag{Decimal-second-sheet-strip}
\]

这是保留原 decimal weights 的 integer scale quotient，ghost coordinates
`H,y_j` 不变。每个 target prime 上

\[
v_p(b_1^{(2)})=0,\qquad
v_p(b_2^{(2)})=v_p(b_3^{(2)})=h,
\quad p^h\mid H,y_1,\quad p\nmid y_2y_3.
\]

若 selected `pi^h` 属于 `Pi_2`，则 `pi^{2h}|y_2+i y_3`。所以
`iy_2=y_3 mod pi^{2h}`；在 conjugate sheet 上则
`iy_2=-y_3 mod bar(pi)^{2h}`。代入 `(Decimal-norm-carrier)` 得到

\[
\boxed{G_{\rm dec}^{(2)}\equiv(D^{(2)}-t_1^{(2)})y_3\pmod{\pi^h},}
\quad
\boxed{G_{\rm dec}^{(2)}\equiv-(D^{(2)}+t_1^{(2)})y_3\pmod{\bar\pi^h}.}
\tag{Decimal-second-sheet-projection}
\]

令 `k_{12}=n_2+n-m_2-m=s_2+d>0`。因

\[
D^{(2)}\equiv b_1^{(2)}10^{m_2+m}\pmod{p^h},\qquad
t_1^{(2)}=b_1^{(2)}10^{m_2+m}10^{k_{12}},
\]

且 `b_1^(2),10,y_3` 均为 p-units，上两式具有 **exact truncated depths**

\[
\boxed{\min\{v_\pi(G_{\rm dec}^{(2)}),h\}
=\min\{v_p(10^{k_{12}}-1),h\},}
\quad
\boxed{\min\{v_{\bar\pi}(G_{\rm dec}^{(2)}),h\}
=\min\{v_p(10^{k_{12}}+1),h\}.}
\tag{Decimal-second-sheet-depths}
\]

第一 channel 同理，但应明确剥离的是其自己的 low baseline。对
`p^h||v_1`，pair-max factorization 给

\[
v_p(b_1)=v_p(b_3)=r_p+h,\qquad v_p(b_2)=r_p.
\]

令 `ell_1=prod_{p^h||v_1}p^{r_p}` 并定义相同的 `(1)` quotient。这时
`p^h|H,y_2,t_1^(1),t_3^(1)`，且 `b_2^(1),y_1,y_3` 为 p-units。
chosen `pi^{2h}|y_1+i y_3` 于是给

\[
\boxed{G_{\rm dec}^{(1)}\equiv-i(D^{(1)}+t_2^{(1)})y_3\pmod{\pi^h},}
\quad
\boxed{G_{\rm dec}^{(1)}\equiv i(D^{(1)}-t_2^{(1)})y_3\pmod{\bar\pi^h}.}
\tag{Decimal-first-sheet-projection}
\]

使用 `D^(1)=b_2^(1)10^m mod p^h` 与
`t_2^(1)=b_2^(1)10^m10^d`，得到

\[
\boxed{\min\{v_\pi(G_{\rm dec}^{(1)}),h\}
=\min\{v_p(10^d+1),h\},}
\quad
\boxed{\min\{v_{\bar\pi}(G_{\rm dec}^{(1)}),h\}
=\min\{v_p(10^d-1),h\}.}
\tag{Decimal-first-sheet-depths}
\]

这些 formulas 的实际含义是：若 `p∤10^{2k_12}-1`（第二 channel）或
`p∤10^{2d}-1`（第一 channel），则该 carrier 在两 Gaussian sheets 上都为
units。只有明确 decimal cyclotomic kernels 的 overlap 才产生 chosen-sheet
divisibility；它没有自动提供 `Pi_1` 或 `Pi_2` 的全模数第二 endpoint。
深于 `h` 的 valuation 也不由这些 congruences决定，不能延伸声称更深
Gaussian contact。

对应脚本核对 norm identity、两 sheets 的符号与截断深度。当前已关闭的
是“直接把此 norm carrier 当作全 `V` independent orientation payer”这条
推理路线；普通 small-gap 的 joint family 仍未排除。

### 7.6 `U/Z` 上已有 inert source primes 不再提供 odd-valuation 排除

**严格状态：已严格完成（局部 no-go；不新增空性）。** 在同一 canonical
chart，设 `p=3 mod4` 且 `p|UZ`。由 `(UVZ,10)=1` 与 phase式，
`U,V,Z` 两两互素。写 `t=v_p(q_src)`；`B,F` 为 p-units，并且

\[
\Sigma=2FU+V\equiv
\begin{cases}V&p\mid U,\\FU&p\mid Z\end{cases}\pmod p
\]

为 unit。所以原 full denominator `D=Bq_src Sigma` 与 `b_3=BVq_src`
满足 `v_p(D)=v_p(b_3)=t`。

对一个真实 reduced Exact-Lift candidate，必有

\[
\boxed{v_p(b_1),v_p(b_2)\le t.}
\tag{Inert-source-prefix-depth-cap}
\]

否则最大 denominator depth `M>t` 只在一个或两个 prefix blocks中取得。
Reducedness使这些主导 rational coordinates 的 p-adic units 非零；一个
平方不能相消，而两个平方在 `p=3 mod4` 下也不能相消。故 sphere
的平方和赋值为 `-2M`，平方根赋值为 `-M`。原 word ratio `A_word/D`
却具有赋值至少 `-t`，矛盾。这里使用了原 full word，是已被 candidate
满足的必要条件，不是一份新 modulus。

令 `r=min(v_p(b_1),v_p(b_2))<=t`。两十进制 weights为 p-units，
inert二平方和律给

\[
v_p(t_1^2+t_2^2)=2r.
\]

另一方面 `(Canonical-decimal-norm-expansion)` 的 negative term有

\[
v_p(D^2-b_3^2)=2t+v_p(UZ)>2r.
\]

因此没有最低层相消，严格得到

\[
\boxed{v_p(\Delta_{\rm dec})=2r\quad(p=3\bmod4,\ p\mid UZ).}
\tag{Inert-source-decimal-norm-even-depth}
\]

所以在真实 source/word parents 已满足后，`U` 或 `Z` 上这些 inert
primes 对 denominator norm 的 even-valuation条件是自动满足的。
不能因为 `U=3 mod4` 必携带 inert prime，就据此再次推断 norm 矛盾。
下一可攻击的 norm primes应来自 `p∤UZ` 的外部 odd-valuation，或
§7.5 中明确的 decimal-kernel overlap；是否能聚合成 height 或定位矛盾
仍待证明。这个结论不影响二进 odd-unit reader的 `Z=1 mod4` 限制。

---

## 8. 状态摘要

- **安全 chosen orientation parent：** scale-free secondary carrier `Pi_Omega | (...)`；
- **同源 parent：** raw pair-max line `Pi_Omega^2 | y_2+i y_3`，不可重复收费；
- **W-free genuine reader：** 仅 rational `A_12` CRT，conjugation-blind；
- **历史第二 Gaussian carrier：** discriminant-root dependency未重新证明，当前不可用；
- **已严格完成：** ordinary/primitive gap dictionary与 full-word/carry equivalence；
- **已严格完成（明写 fixed fiber）：** 两-channel period `Uv_1^2v_2`，以及
  fixed `delta_0<1/2` 的 `A_12` conditional uniqueness；
- **已严格完成：** decimal norm 在两 channels 的 exact truncated cyclotomic
  projection；其在非 cyclotomic target primes 上是两-sheet unit；
- **已严格完成（no-go）：** `U/Z` 上已有 inert source primes 的 decimal
  norm赋值自动为偶数，不能重复用于 odd-valuation contradiction；
- **结论：** quartic route 当前缺第二个 independent orientation-sensitive parent；
- **下一目标：** W-free decimal/full-concat Gaussian carrier，或 `Delta_V` 的 deterministic oriented digit-shell location。
