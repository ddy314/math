# DD corrected canonical terminal 的 global sparsity 与非循环计数修复

> 日期：2026-09-06；2026-09-30 修复 counting dependency。
>
> 依赖：[`dd-corrected-terminal-denominator-sunit-entropy-2026-08-22.md`](dd-corrected-terminal-denominator-sunit-entropy-2026-08-22.md) 的 denominator-only §§1--6、[`dd-corrected-common-scale-ray-sharp-2026-09-06.md`](dd-corrected-common-scale-ray-sharp-2026-09-06.md)、[`dd-corrected-numerator-collapse-sharp-2026-09-06.md`](dd-corrected-numerator-collapse-sharp-2026-09-06.md) 的非循环 §7，以及 [`ordinary gap / 两-channel 字典`](dd-corrected-quartic-orientation-dependency-audit-2026-09-06.md#ordinary-gap-full-word-dictionary)。
>
> **严格状态：已严格完成（corrected canonical `t_2=1` terminal neighborhood；fixed `delta_0<1/2` 的非循环 global counting）。**
>
> **纠错边界：** 旧 proof先声称 fixed-denominator numerator family为
> `10^{o(S)}`，再乘 denominator entropy。其 gap/suffix 两种条件唯一性有循环，
> 该 fixed-denominator 声明为 **失效/降级**。本文件改为先直接枚举 short suffix
> `a_2`，再使用 fixed `a_2` 的 gap uniqueness与明写 fixed gap/suffix/orientation
> 的两-channel period；最后共同优化 numerator / denominator的同一 defect budget。
> 原 `delta/lambda` global exponent由这个不同的、非循环证明恢复，并扩展到
> `delta_0<1/2`。不据此宣称 emptiness。

---

## 1. 真实枚举顺序与范围

令

\[
\alpha:=\log_{10}2,\qquad\beta:=1-\alpha,\qquad
A:=\frac{2(1+2\alpha)}3,\qquad
\lambda:=\frac{2+\alpha}{1+2\alpha},
\]

\[
M_*:=\frac3A,\qquad c_*:=2+3\lambda,\qquad
\delta:=c_*-\frac nS,\qquad \mu:=M_*-\frac mS.
\]

固定任意 `0<=delta_0<1/2`，考虑 `0<=delta<=delta_0` 的 corrected canonical
candidates。全部 digit lengths和 normalized valuation/slack layers均只有
`S^{O(1)}` 个 combinatorial choices，吸收进 `10^{o(S)}`。

对每个 denominator/S-unit candidate，枚举两-channel Gaussian orientations，
然后直接枚举实际未固定的 `a_2`：

\[
10^{n_2-1}\le a_2<10^{n_2}.
\]

Orientation choices至多 `2^{omega(V)}=10^{o(S)}`，因为 `V|G<10^S`。
对每个 fixed `a_2` 与 orientation，reader

\[
2\cdot5^T\iota_\Omega c_3R_0
\equiv a_2c_2g_0\pmod{v_2}
\]

不含 `A_12,a_1`，且所有 coefficient由 denominator/S-unit data固定。
Gap Farey determinant的 height至多 `delta S+o(S)`，而
`log_10 v_2/S>=1-delta-o(1)`；因此 `delta<=delta_0<1/2` 时 reduced
`R_0/g_0` 至多一个。

随后 fixed `a_2+gap+两-channel orientations` 的 exact period为

\[
\boxed{P_{\rm 2sh}=Uv_1^2v_2,\qquad
\frac{\log_{10}P_{\rm 2sh}}S\ge1+U_*-\delta-o(1),}
\]

其中 `U_*=0.691116422381969...>1/2`。于是 eventually
`P_2sh>10^{S+2}>A_12`，所以 `A_12` 至多一个，carry / prefix splitting
恢复 `a_3,a_1`。

故 **安全的 fixed-denominator bound** 是

\[
\boxed{N_{\rm num}\le10^{n_2+o(S)}.}
\tag{Direct-suffix-enumeration}
\]

这仍允许 positive-linear numerator entropy；后续 global proof必须把
`n_2/S` 保留在联合预算中，不能先删成 `o(1)`。

---

## 2. denominator entropy与 short-suffix height的未粗化联合式

Denominator-only Farey / rough-core / divisor-assignment proof保持有效。
Common-scale ray的 sharp refinement给每个 `(sigma_S,R)` layer

\[
\boxed{N_{\rm den/SU}\le10^{(\sigma_S+R/2)S+o(S)}.}
\tag{Denominator-scale-entropy}
\]

这里 fixed phase/factor split 后 denominator movement仅沿
`gamma=ell^2 bar_gamma` 的 common scale，因此 rough `ell` 的计数只花
`R/2`，不是 `R`。这一步不使用 numerator joint collapse。

Short suffix的未粗化 height与 short denominator同样受 digit polarization
控制。由 `s_1=max(s_1,s_2)`、`n_1>=s_1+1`、`n_1+n_2<=S+2`，有
`n_2/S<=1-s_1/S+o(1)`。保留 digit theorem的 full correction，得到

\[
\boxed{
\frac{n_2}{S}
\le\frac\delta2-\left(1-\frac\beta3\right)\mu
-\frac\beta3Q_5+\frac\beta3G_5
-\frac\beta6N_5+\frac R2+o(1).}
\tag{Suffix-sharp}
\]

由 `(Direct-suffix-enumeration)` 与 `(Denominator-scale-entropy)`，需要
控制的是联合 exponent

\[
E:=\sigma_S+\frac R2+\frac{n_2}{S}.
\]

代入 `(Suffix-sharp)`：

\[
E\le\frac\delta2+\sigma_S+R
-\left(1-\frac\beta3\right)\mu
-\frac\beta3Q_5+\frac\beta3G_5
-\frac\beta6N_5+o(1).
\tag{Joint-entropy-prebudget}
\]

不能分别把 denominator与 suffix各自的最坏 height加起来；二者使用同一份
Schmidt/digit defect budget。

---

## 3. exact `Mu-budget` 后所有 rough/valuation corrections为负

使用

\[
A\mu=\sigma_S+2\alpha Q_2+\alpha N_2
+\frac\beta3(2Q_5+4G_5+N_5)+2R+o(1).
\tag{Mu-budget}
\]

关键 exact coefficient identity为

\[
\frac{1-\beta/3}{A}=\frac\lambda2.
\]

因此 `(Joint-entropy-prebudget)` 精确变成

\[
\boxed{
\begin{aligned}
E\le{}&\frac\delta2+\left(1-\frac\lambda2\right)\sigma_S
-\alpha\lambda Q_2-\frac{\alpha\lambda}2N_2\\
&-\frac{\beta(1+\lambda)}3Q_5
+\frac{\beta(1-2\lambda)}3G_5\\
&-\frac{\beta(1+\lambda)}6N_5
+(1-\lambda)R+o(1).
\end{aligned}}
\tag{Joint-entropy-shared-budget}
\]

`1<lambda<2`，所以除 `sigma_S` 外，所有 correction coefficients严格为负。
Quantitative defect给

\[
\lambda\sigma_S\le\delta+o(1).
\]

故

\[
\boxed{
E\le\frac\delta2+
\left(1-\frac\lambda2\right)\frac\delta\lambda+o(1)
=\frac\delta\lambda+o(1).}
\tag{Joint-entropy-bound}
\]

这是 global count的非循环修复；未把 gap/suffix同源唯一性当独立 payer。

---

## 4. 修复后的 global candidate count

对 fixed `delta_0<1/2`，逐 `O(1/S)`-width normalized layers应用上节，再
汇总 polynomial many layers，得到

\[
\boxed{
N_{\rm term}(S;\delta_0)
\le10^{(\delta_0/\lambda)S+o(S)},
\qquad 0\le\delta_0<\frac12.}
\tag{Terminal-sparsity-noncircular}
\]

数值 coefficient仍是

\[
\boxed{\lambda^{-1}=0.696236030971719\ldots.}
\]

旧 positive-width global exponent被恢复，作用域从
`delta_0<0.460744281587979...` 扩至现行 one-channel的整个严格内部。
不同之处是 surviving fixed-denominator numerators仍允许
`10^{n_2+o(S)}` 个；其 entropy在全局与 denominator entropy共用同一预算，
并没有单独消失。

当 `delta->0` 时，上述安全 numerator和 global bounds都仍给
`10^{o(S)}` 的 equality-scale sparsity。该结论不提供 deterministic
location obstruction、strict slope gap或 effective absolute height bound。

---

## 5. 核对与边界

```bash
UV_CACHE_DIR=/tmp/math-uv-cache uv run python scripts/exact-lift/double-deficit/research-checks/tail/check_dd_corrected_numerator_collapse_sharp.py
UV_CACHE_DIR=/tmp/math-uv-cache uv run python scripts/exact-lift/double-deficit/research-checks/tail/check_dd_corrected_terminal_global_sparsity_sharp.py
```

脚本核对 exact joint coefficient展开、`lambda/2` identity、全部 correction
符号、条件唯一性反模型与 old/new threshold。finite models仅核对局部 algebra，
不提供 Exact-Lift 解族或无界 emptiness certificate。

当前严格成果是修复后的 global sparsity。Positive fixed `delta_0` 时右侧仍
允许指数多个 candidates；ordinary gap/suffix/chosen-orientation与真实 decimal
word的 simultaneous compatibility仍待证。没有关闭 DD。

---

## 6. 状态摘要

- **已严格完成：** denominator/S-unit counting及 common-scale `R/2` refinement。
- **失效/降级：** fixed-denominator `N_num=10^{o(S)}` 的旧 positive-width声明。
- **已严格完成：** fixed `a_2` 的 gap uniqueness，无 `A_12` 条件循环。
- **已严格完成（明写 fixed fiber）：** two-sheet period `Uv_1^2v_2` 与 `A_12` uniqueness。
- **已严格完成：** direct suffix enumeration后的联合 `E<=delta/lambda`。
- **已严格完成：** fixed `delta_0<1/2` 的 `(Terminal-sparsity-noncircular)`。
- **待证：** joint ordinary gap/suffix/orientation elimination；deterministic digit-shell exclusion；DD emptiness。
