# 全局统一框架

本文件给出三块十进制拼接 Exact Lift 的当前规范公共框架。历史长稿仍保存在 `archive/`；这里仅保留经现行分支审计仍有效、且三个异常分支共同使用的结构。主不存在性命题与 A2/DD/A1 三分支状态均由 `status.md` 和各分支 README 决定。

# 3. 整数球面提升与 canonical recovery

对三个正既约有理数

\[
r_i=\frac{a_i}{b_i},\qquad \gcd(a_i,b_i)=1,
\]

令

\[
\boxed{q=\operatorname{lcm}(b_1,b_2,b_3)},
\qquad
\boxed{y_i=\frac{qa_i}{b_i}}.
\]

若 exact lift 成立，则存在正整数 \(H\) 使

\[
\boxed{y_1^2+y_2^2+y_3^2=H^2},
\qquad
\boxed{q\alpha=H\beta},
\]

其中 \(\alpha,\beta\) 为完整 numerator / denominator decimal words。

逐坐标有精确恢复恒等式

\[
\boxed{\gcd(q,y_i)=\frac q{b_i}}.
\]

因此令

\[
d_i=\gcd(q,y_i),
\]

即可唯一恢复

\[
\boxed{a_i=\frac{y_i}{d_i},\qquad b_i=\frac q{d_i}}.
\]

所以完整候选可放在 canonical spine

\[
\boxed{(y_1,y_2,y_3,q)}
\]

上理解。给定该 spine 后，\(H\)、六个 reduced blocks、digit lengths、valuations 与后续 Exact-Lift coefficient data 都是确定性投影。Gap root、tail root、判别平方根符号、Hensel/Gaussian 标签若只是这些数据的消元表示，不能重复计作新的 original-candidate freedom。

注意：\(q=\operatorname{lcm}(b_i)\) 不自动保证 \((y_1,y_2,y_3,H)\) 整体本原；需要 primitive core 时必须显式再除公共 content。

---

# 4. 前两块公共对象与 carrier coefficients

统一定义

\[
\boxed{Q=b_1 10^{m_2}+b_2},
\qquad
\boxed{G=b_1b_2},
\]

\[
\boxed{\mathcal N_{12}=(a_1b_2)^2+(a_2b_1)^2=G^2(r_1^2+r_2^2)}.
\]

三个异常分支使用统一 coefficient pair \((C,D)\)：

\[
(C,D)=
\begin{cases}
\left(a_1 10^{m_2}+10a_2,\ Q\right),&A_2,\\[0.4em]
\left(10^{m_2+k_{12}}a_1+10^{d_3}a_2,\ Q\right),&DD,\\[0.4em]
\left(10^{g+k_{12}+m_2}a_1+a_2,\ 10^gQ\right),&A_1.
\end{cases}
\]

DD 中

\[
d_3=s_3>0,\qquad k_{12}=s_2+s_3>0,
\]

A1 中

\[
g=-s_3\ge0,\qquad k_{12}=s_2+s_3\ge1.
\]

这些定义只是把三个 carrier chamber 的 decimal coefficient plane 写入同一语言，不改变分支状态。

---

# 5. 第三尾正规化与 denominator–decimal trace

定义有效尾长

\[
\ell=
\begin{cases}
m_3,&A_2,DD,\\m_3-g,&A_1,
\end{cases}
\]

以及

\[
\boxed{\delta_3=\gcd(10^\ell,b_3)},
\qquad
\boxed{L=\frac{10^\ell}{\delta_3}},
\qquad
\boxed{\tau=\frac{b_3}{\delta_3}},
\]

故

\[
\gcd(L,\tau)=1.
\]

第三分子的相应 tail normalization 只在其定义域内使用；不能从 \(\delta_3\) 的 denominator gcd 无条件推出 \(\delta_3\mid a_3\)。涉及 primitive tail numerator 的公式必须引用对应分支已经建立的 exact-recovery 定义。

Denominator recovery 与 decimal completion 真正需要共享的 denominator-side trace 可以写成

\[
\boxed{T_{\rm blk}=(b_1,b_2,b_3,10^\ell)},
\]

或等价的 segmented word 形式

\[
\boxed{T_{\rm word}=(\beta,10^{m_2},10^{m_3},10^\ell)}.
\]

给定该 trace，\(q,Q,G,\delta_3,L,\tau\) 以及全部 denominator-only valuation/gcd data 都是确定性函数。这个接口只减少重复状态，不关闭任何分支。

A1 的 historical saturated `L=1` 子支已经在 A1 后续工作中排除；它不再是当前 A1 frontier。当前 A1 权威前沿见 `branches/a1-only/README.md`。

---

# 6. 三分支统一尾权 \(\kappa\)

三个分支的尾权可以统一写成同一个 branch-free 恒等式：

\[
\boxed{\kappa=\frac{10^{m_3}QG}{b_3}\in\mathbf Z_{>0}}.
\]

证明只是把各分支原定义代回：

- A2/DD 有 \(\ell=m_3\)，故 \(L/\tau=10^{m_3}/b_3\)；
- A1 有 \(\ell=m_3-g\)，故 \(10^gL/\tau=10^{m_3}/b_3\)。

因此旧的两种写法

\[
\kappa=\frac{LQG}{\tau}\quad(A_2,DD),
\qquad
\kappa=\frac{10^gLQG}{\tau}\quad(A_1)
\]

只是同一恒等式的 chamber-specific 展开。

公共窗口仍为

\[
\boxed{QG<\kappa\le10QG}.
\]

这个统一式是本次外部整合后正式采纳的公共简化；它不依赖任何 DD closure 假设。

---

# 7. Gap quadratic 与判别平方

令统一 gap 参数满足

\[
G(\mathcal R-r_3)=\frac\mu\nu,
\qquad \gcd(\mu,\nu)=1.
\]

三个异常分支都得到

\[
\boxed{
D(\kappa+2G)\mu^2
-2G\kappa C\mu\nu
+\kappa D\mathcal N_{12}\nu^2=0.
}
\]

于是必要整除为

\[
\boxed{\nu\mid D(\kappa+2G)},
\qquad
\boxed{\mu\mid\kappa D\mathcal N_{12}}.
\]

定义

\[
\boxed{K_{C,D}=G^2C^2-D^2\mathcal N_{12}}.
\]

存在有理 gap root 的必要条件是

\[
\boxed{
\kappa\bigl(\kappa K_{C,D}-2GD^2\mathcal N_{12}\bigr)=W^2
}
\]

对某个整数 \(W\)。

这类 quadratic / discriminant 条件是 exact candidate 的投影证书。若在某个更完整的 recovery chart 中它们由同一 exact reconstruction 自动推出，就不能作为额外独立 obstruction 再次收费；具体独立性由对应分支 dependency audit 决定。

定义

\[
G_0=\gcd(\mathcal N_{12}\nu^2-\mu^2,2G\mu\nu).
\]

已有公共结果

\[
\boxed{G_0\mid2G\mathcal N_{12}},
\]

所以 recovery 中出现的额外 gcd 不能充当完全独立的无界素数储存池。

---

# 8. Tail quadratic 与 denominator-tail certificate

在各分支已经建立相应 primitive-tail recovery 的定义域内，可得到统一 tail quadratic 与有理根整除。其最稳定、跨分支可直接使用的 denominator-side 结论是

\[
\boxed{10^\ell\mid\kappa^2(\kappa+2G)}.
\]

由于第 6 节的 branch-free \(\kappa\) 公式，这个 certificate 的 denominator side 完全由

\[
(b_1,b_2,b_3,10^\ell)
\]

决定。

令

\[
S_{12}=m_1+m_2.
\]

由

\[
Q,G<10^{S_{12}}
\]

以及 \(QG<\kappa\le10QG\)，得到公共粗尾长锥

\[
\boxed{\ell\le6S_{12}+3}.
\]

于是 A2/DD 有

\[
\boxed{m_3\le6S_{12}+3},
\]

A1 有

\[
\boxed{m_3-g\le6S_{12}+3}.
\]

这些只是 prefix-uniform 高度约束，不是全局空性。

---

# 9. Vieta / prime-flow 工具的使用边界

Gap/tail quadratic 常可产生 Vieta conjugate、cross-difference、prime-power allocation 或 quadratic-residue 条件。这些工具在局部算术上有效，但必须区分：

1. 共轭根是否仍对应正的 original decimal block；
2. 变换后是否保持逐块既约；
3. 是否保持同一 decimal coefficient plane / carrier chamber；
4. prime-flow 条件是否只是原 quadratic 的等价投影。

本仓库早期曾多次把“有 companion root / Gaussian flip 改变尺度”误当成合法 descent。现行审计已经确认：没有证明上述保持性时，Vieta/Gaussian 变换只能作为局部 factorization 工具，不能迭代成全局下降。

A1 的外部 word-recovery 审计还提供了一个重要反例原则：即使 sphere、tail、Gaussian、reducedness 的多个投影同时成立，只要没有强制 **同一个真实 first-two decimal cut**，仍可留下无穷 ambient pseudo-family。因此后续 prime-flow 结论必须回接真实 word realization。

---

# 10. Denominator prime graph

对任意素数 \(p\)，记

\[
e_i=v_p(b_i),\qquad E=\max(e_1,e_2,e_3).
\]

逐坐标 recovery

\[
v_p(\gcd(q,y_i))=E-e_i
\]

把 denominator exponent pattern 精确送入整数球面。

对于奇素数 \(p\ne2,5\)，若最大赋值只在一块出现，则 complementary denominator relation 强迫另外两块的 \(p\)-进指数相等；pair-max 情形结合二平方和局部条件，会对 \(p\bmod4\) 产生严格限制。所有更细的 unique-max / pair-max 结论必须引用相应分支的已审计 lemma，不能从这张 skeleton 自动外推全局关闭。

对 \(p=2\)，必须区分 \(E_2=\max_i v_2(b_i)>0\) 与三个分母全奇。
若 \(E_2>0\)，在达到最大值的坐标上，既约性保证 \(a_i\) 为奇数，
故至少一个 \(y_i\) 为奇数。整数球面模 \(4\) 给出 \(H\) 为奇数，
且三个 \(y_i\) 中恰有一个奇数。因此

\[
\boxed{E_2>0\Longrightarrow\max_i v_2(b_i)\text{ 必须唯一取得}.}
\]

若 \(E_2=0\)，不能直接断言 \(H\) 为奇数，也不能断言最大值唯一。
例如全偶球面坐标不被模 \(4\) 排除。DD 已在
[core.md §27.7](branches/double-deficit/core.md) 单独处理全奇分母锥。
这项本地范围修正不声称找到了 exact-lift 反例。现行分支文档中的
2-adic locks 仍须在各自假设下使用。

若 `E2>=2`，模八还给出一个 denominator-only 必要条件：另外两块中
深度恰为 `E2-1` 的分母数量必须为偶数（零或二）。这些深度为正，
既约性使对应分子为奇数，故其 `yi²=4 mod8`；更浅分母的坐标平方
为零，最大深度坐标与 `H` 的奇平方都为一。因此单独一块相差一层
会给 `1=1+4 mod8`，矛盾。`E2=1` 时其他分子的奇偶自由，不能只数
分母。DD 对一位偶尾的完整应用见
[third-2-dominant 低层排除](branches/double-deficit/core.md#single-digit-tail-third-two-dominant-closure)。

原 word equation 还给出一个更直接的接口：若 `b3` 为奇数，则完整
`beta=Q*10^m3+b3` 为奇数。假如 `E2>0`，上面的 sphere 条件使 `H`
为奇数，而 `q alpha` 为偶数，违反 `q alpha=H beta`。因此
\[
\boxed{b_3\text{ 奇}\Longrightarrow b_1,b_2,b_3\text{ 全奇}.}
\]
这里仍不推断全奇分母下的 `H` 奇偶；它只排除奇尾分母与偶前缀分母
同时出现的无界状态。

因此 denominator prime graph 的作用是组织 prime supply 与 recovery depth，不是单独的 contradiction theorem。


<a id="denominator-common-mod9"></a>

## 10.1 同三进赋值分母的模九阻碍（2026-09-30）

**状态：已严格完成（跨分支必要条件与无界子域排除）。** 假设
\[
v_3(b_1)=v_3(b_2)=v_3(b_3)=E\ge0,\qquad
c_i:=b_i/3^E\equiv c\pmod3\quad(i=1,2,3),
\]
其中选取 `c=1` 或 `c=-1`。若原 exact lift 成立，则必须有
\[
\boxed{c_1^2+c_2^2+c_3^2\equiv0\pmod9,}
\qquad
\boxed{c_1+c_2+c_3\equiv6c\pmod9.}
\tag{D9}
\]
两条件在上述同剩余类假设下等价。因此违反 (D9) 的整个分母子域为空，
无论三个分子和六个块的位数如何增长。它不覆盖不同三进赋值或不同
`c_i mod3` 的状态，也不证明通过 (D9) 的状态存在。

### 固定十进制权重上的三进正规化

依赖 §3 的 canonical sphere 和原始 word equation。令
\[
q=3^E q',\qquad q'=\operatorname{lcm}(c_1,c_2,c_3),
\qquad y_i=q'a_i/c_i.
\]
把 `q alpha=H beta` 除以 `3^E` 得到精确线性式
\[
\sum_i c_i X_i y_i=H\sum_i c_i Y_i,
\]
其中 `(X_1,X_2,X_3)=(10^{n_2+n_3},10^{n_3},1)`，
`(Y_1,Y_2,Y_3)=(10^{m_2+m_3},10^{m_3},1)`。

取 `t=min(v3(y1),v3(y2),v3(y3),v3(H))`，令 `z_i=y_i/3^t`、`h=H/3^t`。
球面与这条**固定权重**线性式都可同时除以 `3^t`；这里不声称
正规化后的坐标仍恢复原十进制块，也不构造 decimal descent。
于是至少一个 `(z1,z2,z3,h)` 是三进单位，并有
\[
\sum_i z_i^2=h^2,\qquad
\sum_i c_i z_i\equiv h\sum_i c_i\pmod9,
\tag{D9-spine}
\]
因为所有 `X_i,Y_i` 均为 `1 mod9`。

若 `3 not|h`，球面模三说明恰有一个 `z_i` 为单位；线性式模三却要求
`sum z_i=0`，矛盾。因此 `3|h`。球面模三与三进本原性随后说明
三个 `z_i` 都为单位；它们的和为零又强迫三者同为 `sigma mod3`，
其中 `sigma=1` 或 `sigma=-1`。

写
\[
z_i=\sigma+3t_i,\qquad c_i=c+3u_i.
\]
球面模九给出
\[
3+6\sigma\sum_i t_i\equiv0\pmod9,
\qquad\sum_i t_i\equiv\sigma\pmod3.
\]
另一方面 `3|h` 且 `3|sum c_i`，所以 (D9-spine) 的右端为零模九。
代回左端并除以三，得到
\[
c\sigma+c\sum_i t_i+\sigma\sum_i u_i\equiv0\pmod3,
\qquad\sum_i u_i\equiv c\pmod3.
\]
因此 `sum c_i=3c+3 sum u_i=6c mod9`，且
`sum c_i^2=3+6c sum u_i=0 mod9`，证明 (D9)。

**推论。** 若 `c_1=c_2=c_3`，则 `sum c_i^2=3c_1^2 not=0 mod9`，
故所有等分母候选为空。这重新在公共框架中给出了等分母排除，
同时把它扩展到许多不相等的分母；它不借用外部 DD closure 前提。
更一般，若 `c1,c2,c3` 具有同一模九单位剩余类，也同样为空。
因此对任意正整数 `b` 与非负整数 `e1,e2,e3`，整个
`(b1,b2,b3)=(b*10^e1,b*10^e2,b*10^e3)` 十进制分母射线均被排除；
特别地三个分母都是十进制幂的状态已全部关闭，不留 equal-prefix 例外。

### 有限局部证书与边界

```bash
UV_CACHE_DIR=/tmp/math-uv-cache uv run --offline python scripts/exact-lift/check_denominator_mod9.py
```

2026-09-30 核对：穷尽模九的 540 个三进本原球面剩余类，以及 54 个
`c_i` 为单位且同模三符号的有序分母剩余类；其中 36 类没有满足线性式
的本原点，18 类只在这个局部投影上允许点。脚本还核对 (D9) 两种
写法等价与等分母推论。有限证书只核对完整模九投影；上面的无界
排除来自对任意原候选的严格约化，不是把有界整数枚举外推。

<a id="denominator-word-norm"></a>

## 10.2 原始 coefficient plane 的分母 norm 阻碍（2026-09-30）

**状态：已严格完成（跨分支必要条件与无界剩余类排除）。** 本节不要求
三个分母有相同三进赋值。仍使用原始六个十进制块，定义
\[
(t_1,t_2,t_3)
=(b_1 10^{n_2+n_3},b_2 10^{n_3},b_3),\qquad D=\beta,
\]
\[
\boxed{\Delta_{\rm dec}=t_1^2+t_2^2+t_3^2-D^2.}
\]
这里 `Delta_dec` 由三个分母和六块的位数决定，不含分子的数值。
若 exact lift 成立，则
\[
\boxed{\Delta_{\rm dec}\ge0,\qquad
\Delta_{\rm dec}\text{ 是两个有理平方之和}.}
\tag{D-norm}
\]
特别地，若 `Delta_dec!=0`，每个 `p=3 mod4` 的赋值都必须为偶数。
这是一条原 sphere/word equation 的必要投影，不是额外独立的高度预算。

### 精确 Gaussian identity

依赖 §3，原 word equation 可以写成
\[
DH=t_1y_1+t_2y_2+t_3y_3.
\]
令 `s=H+y3>0`，以及
\[
G_{\rm dec}=(D+t_3)(y_1+iy_2)-(t_1+it_2)s.
\]
直接展开得到恒等式
\[
\begin{aligned}
N(G_{\rm dec})-\Delta_{\rm dec}s^2
={}&-(D+t_3)^2(H^2-y_1^2-y_2^2-y_3^2)\\
&+2(D+t_3)s(DH-t_1y_1-t_2y_2-t_3y_3).
\end{aligned}
\tag{D-norm-identity}
\]
两括号由 sphere 与原 coefficient plane 同时为零。因此
`Delta_dec=N(G_dec/s)`，证明 (D-norm)，包括 `Delta_dec=0` 的情形。
对 `p=3 mod4`，两个整数平方之和若被 `p` 整除，则两个整数都被 `p`
整除；除尽共同 `p` content 后，该和的赋值为零。清除有理分母只改变
偶数赋值，故非零有理 norm 的 `p` 赋值必为偶数。

### 任意共同三进 content 下的模九排除

令
\[
j=\min_i v_3(b_i),\qquad c_i=b_i/3^j.
\]
至少一个 `ci` 为三进单位。所有十进制权重为 `1 mod9`，所以
\[
\frac{\Delta_{\rm dec}}{3^{2j}}
\equiv\sum_i c_i^2-\left(\sum_i c_i\right)^2
=-2(c_1c_2+c_1c_3+c_2c_3)\pmod9.
\]
若 pair sum 为 `3` 或 `6 mod9`，右侧恰被三整除而不被九整除，
故 `v3(Delta_dec)=2j+1`，与 (D-norm) 矛盾。因此得到无界排除
\[
\boxed{c_1c_2+c_1c_3+c_2c_3\equiv3\text{ 或 }6\pmod9
\Longrightarrow\varnothing.}
\tag{D9-general}
\]
这覆盖任意分子、任意位数和任意三个分母的三进赋值差。
例如 `ci=(1,3,3) mod9` 已被排除，超出 §10.1 的共同赋值范围。
当 `ci` 同为单位且同模三符号时，`sum ci=0 mod3`，此条件恰与
§10.1 的 (D9) 相同；`(1,1,4) mod9` 是允许类，不能误报为空。

同一核对脚本穷尽 702 个至少含一个三进单位的模九系数类，144 类
因 (D9-general) 被排除；其余 558 类在本原 sphere/plane 模九投影上
有允许点。这些允许点不证明有原 exact-lift 解。脚本另以符号展开核对
(D-norm-identity)。对其他 inert primes 的偶赋值要求仍只是一条必要条件，
本节没有从它推出任一完整分支关闭。

<a id="unit-prefix-single-digit-denominator"></a>

## 10.3 单位前缀分母与一位第三分母全部排除（2026-09-30）

**状态：已严格完成（整个无界分母子域）。** 假设
\[
\boxed{b_1=b_2=1,\qquad1\le b_3\le9.}
\]
对任意正整数 `a1,a2,a3` 及任意三分子位数，均不存在原 exact lift。
本节没有限制分子的高度，也不依赖有界搜索。

由 §3，`q=b3`，故
\[
(y_1,y_2,y_3)=(b_3a_1,b_3a_2,a_3),\qquad
H^2=y_1^2+y_2^2+y_3^2,\qquad b_3\alpha=H(110+b_3),
\]
其中 `H` 是正整数，`gcd(a3,b3)=1`。按第三分母作穷尽分支：

1. `b3=1`：三个分母相等，由 §10.1 排除。
2. `b3=3,6,9`：取 `p=3`；`b3=7`：取 `p=7`。球面模 `p` 给
   `H²=a3²!=0 modp`，所以 `H` 是 `p`-unit；但 `110+b3` 也是
   `p`-unit，而 `b3 alpha` 被 `p` 整除。整数 word equation 矛盾。
3. `b3=2,4,6,8`：既约性使 `a3` 奇，球面使 `H` 奇，原分子 word
   `alpha=A12*10^n3+a3` 也奇。若 `v2(b3)=1`，`110+b3` 被四整除；
   若 `v2(b3)>=2`，`110+b3` 恰含一个二。两种情况都使 word equation
   的两端二进赋值不同。与上一项重叠的 `b3=6` 不影响穷尽性。
4. `b3=5`：word equation 给 `H=alpha/23`，故
   `H=2a3 mod5`，因为 `alpha=a3 mod5`。球面却给 `H²=a3² mod5`。
   于是 `4a3²=a3² mod5`，与 `5 not|a3` 矛盾。

这些情形覆盖全部一位正分母，证明命题。DD 中 `m3=1,n3>1` 的
单位前缀 slice 是本节的一个完整推论，见
[DD 低层记录](branches/double-deficit/core.md#unit-prefix-single-digit-tail-closure)。它不覆盖一般前缀分母，
也不把 DD、A2 或 A1 任何完整分支提升为已关闭。

<a id="single-digit-denominator-complete-certificate"></a>

## 10.4 三个一位分母的完整高度归约与有限证书（2026-09-30）

**状态：有限证书（经证明的高度归约覆盖整个指定分母子域）。**
对任意正既约分子，若 `1<=b1,b2,b3<=9`，则原 exact lift 不存在。
这里分子的高度没有作为输入假设；以下推导先覆盖全部分子位数，
再进行有限精确计算。一般的多位分母仍不在结论中。

依赖 §3 的整数球面与原 word equation。令
`q=lcm(b1,b2,b3)<=729`、`ci=q/bi`、`D=100b1+10b2+b3<=999`，
以及 `X=10^n2,Y=10^n3`。若有原解，则

```math
\alpha=(a_1X+a_2)Y+a_3,
\qquad q\alpha=DH,
\qquad H^2=\sum_i(c_i a_i)^2,\quad H\in\mathbf Z_{>0}.
```

三个比值均正，故严格三角界给 `alpha<D(a1+a2+a3)`。
另对任一坐标 `yi=ci ai`，正整数 `H-yi>=1` 给出统一 gap 界

```math
a_i<\frac{q b_i}{2}\sum_{j\ne i}(a_j/b_j)^2.
\tag{SD-gap}
```

这是因为 `sum_{j!=i} yj²=(H-yi)(H+yi)>2yi`。
以下五个互不重叠的情形覆盖全部正整数 `n2,n3`。

| 位数情形 | 有限枚举的已知分子 | 精确重构的分子 |
| --- | --- | --- |
| `3<=n3<=8,n2=1,2` | `1<=a1<=110`，`a2` 为 `n2` 位 | `a3` |
| `n3=2,2<=n2<=8` | `1<=a1<=22,10<=a3<=99` | `a2` |
| `n3=2,n2=1` | `1<=a2<=9,10<=a3<=99` | 任意高度的 `a1` |
| `n3=1,3<=n2<=8` | `1<=a1<=111,1<=a3<=9` | `a2` |
| `n3=1,n2=1,2` | `a2` 为 `n2` 位，`1<=a3<=9` | 任意高度的 `a1` |

**第一行的无界归约。** 当 `n3>=3`，`Y>=1000>D`。三角界改写为
`a1(XY-D)<(D-Y)a2+(D-1)a3<(D-1)Y`，所以
`a1(X-D/Y)<D-1<=998`。`X>=1000` 时左侧至少 `999.001`，矛盾；
因此 `n2<=2,a2<=99`。又 `X-D/Y>=9.001`，故
`a1<998/9.001<111`。由 (SD-gap)，
`a3<6561*(110²+99²)/2<10^8`，所以 `n3<=8`。

**第二行的无界归约。** 当 `n3=2,n2>=2`，三角界给
`a1<999(X+99)/(100X-999)`。右侧随 `X` 递减，在 `X=100` 时为
`198801/9001<23`，故 `a1<=22`。再由 (SD-gap)，
`a2<6561*(22²+99²)/2<10^8`，故 `n2<=8`。

**第四行的无界归约。** 当 `n3=1,n2>=3`，同理
`a1<999(X+9)/(10X-999)`。在 `X>=1000` 上右侧递减且不超过
`1007991/9001<112`，故 `a1<=111`。由 (SD-gap)，
`a2<6561*(111²+9²)/2<10^8`，故 `n2<=8`。
其余两行只枚举已知的短分子，不截断第一分子的高度。

**精确整数二次重构。** 固定一行中的两个已知分子后，记未知分子为
`x`、其 word coefficient 为 `Cx`、其 sphere coefficient 为 `cx`，
并写 `alpha=Cx*x+K`、其余 sphere 平方和为 `S`。原方程恰为

```math
A x^2+B x+C=0,
\quad A=q^2 C_x^2-D^2 c_x^2,\quad
B=2q^2 C_xK,\quad C=q^2K^2-D^2S.
```

脚本用标准整数判别式 `B²-4AC` 穷尽所有正整数根，逐个检查实际
位数、既约性与原方程。`A=0` 时按 `B>0` 的线性方程处理，不跳过
退化情形。另一 reader 独立使用恒等式
`B²-4AC=4D²(q² cx² K²+A S)`；两种 reader 都使用整数平方根，
没有浮点容差，也不依赖模类或 norm 预筛。

```bash
uv run python scripts/exact-lift/check_single_digit_denominators.py
uv run python scripts/exact-lift/check_single_digit_denominators.py --reader factored
```

两次运行均覆盖 **26,836,101** 个既约已知分子二次重构行，五行计数
依次为 `20,104,038 / 4,258,548 / 259,380 / 1,927,530 / 286,605`，
原解数均为 **0**。`n3>=2` 的前三行另由
[DD 专用证书](branches/double-deficit/core.md#single-digit-denominators-complete-dd-certificate)
独立核对。这一完整有限证书只关闭指定的一位分母子域；它没有给
多位分母统一上界，不能由此推出三个异常分支已关闭。

<a id="single-digit-tail-denominator-divisibility"></a>

## 10.5 一位第三分母的无界 prefix 整除（2026-09-30）

**状态：已严格完成（必要条件，不是该子域空性）。** 令
`Q=b1*10^m2+b2`。不论三个分子位数及分支为何，只要 `1<=b3<=9`，
原 exact lift 必满足

```math
\boxed{b_3\mid10Q.}
```

这里两个前缀分母可任意大。依赖 §3 的 `q alpha=beta H`、整数球面，
以及 §10 已证明的正二进最大分母深度唯一性。证明如下。
若结论失败，取素数 `p` 满足
`e3=v_p(b3)>t=v_p(10Q)`。因 `beta=10Q+b3`，`v_p(beta)=t`。
原 word equation 给 `v_p(R)=v_p(alpha)-t>=-t`。

- `p=5` 不可能：一位 `b3` 的五进深度至多一，而 `10Q` 至少含一个五。
- `p=2` 时，正最大深度 `E=max_i v2(bi)>=e3` 唯一取得，球面中仅一个
  `yi` 为奇数，故 `H` 奇、`v2(R)=-E<=-e3<-t`，矛盾。
- 其余可能只有 `p=3,7`，均为 inert prime。三个分母不能同时达到最大
  深度 `E`：若同时达到，则 `e3=E` 且 `v_p(Q)>=E`，与 `e3>t` 矛盾。
  因此球面最浅层至多有两个单位坐标。一个单位平方不会为零；两个
  单位平方之和也不会在 `p=3 mod4` 上为零。所以 `H` 为单位，
  `v_p(R)=-E<=-e3<-t`，仍矛盾。

穷尽一位分母的素因子即得结论。DD 中此条件等价于 gcd-normal
`v=b3/gcd(10Q,b3)=1`，其真实恢复字典见
[一位 tail 的 v=1 reader](branches/double-deficit/dd-gcd-normal-d0-gap-crt-dichotomy-2026-09-06.md#single-digit-tail-v-one)。
它关闭的是违反该整除的整个无界前缀状态；通过整除者仍须满足原
分子 word、球面、位数与既约性，不能因此称整个一位 tail 分支为空。

<a id="denominator-complement-lcm-divisibility"></a>

## 10.6 Denominator recovery 的完整素幂整除（2026-10-01）

**状态：已严格完成（必要条件）。** 令

```math
C_1=b_2 10^{m_3}+b_3,\quad
C_2=b_1 10^{m_2+m_3}+b_3,\quad
C_3=(b_1 10^{m_2}+b_2)10^{m_3}.
```

任意原 exact lift 必满足

```math
\boxed{b_i\mid\operatorname{lcm}(b_j,b_k,C_i)
\quad(\{i,j,k\}=\{1,2,3\}).}
```

逐素数证明：若 `ei>max(ej,ek)`，则该 sphere 坐标独占分母最大深度，
其 `yi` 为单位而另外两个为 `p` 的倍数，所以 `H²=yi²!=0 modp`，
`H` 为单位。原 word 给 `vp(beta)=ei+vp(alpha)>=ei`；
`beta-Ci` 是该分母乘十进制整数权重，亦含完整 `p^ei`，故
`vp(Ci)>=ei`。若最大值未独占，则其他分母已承载所需深度。
因此整除保留每个素数幂，不仅是 radical 支持。

特别地

```math
\boxed{b_1\mid\operatorname{lcm}(b_2,b_3,b_2 10^{m_3}+b_3).}
```

右端由最后两个分母确定，因而固定这两个分母后，第一分母的候选
可有效穷尽。对 `1<=b2,b3<=9`，粗界为 `b1<=9*9*99=8019`。
这不是无界后缀的统一上界。`C2,C3` 还含相应分母的位数，不能
照搬第一分母的有效有限性到全部三分母的并集。

对于 `p∤10`，第三项还给 tail 非十进制部分的深度界
`v_p(b3)<=max(v_p(b1),v_p(b2),v_p(Q))`。
这些整除均来自同一原 sphere/word，不构成额外高度预算。

---

<a id="single-digit-denominator-suffix-complete-certificate"></a>

## 10.7 后两分母为一位的完整子域（2026-10-01）

**状态：有限证书（先证明全部高度归约，完整覆盖指定子域）。**
任意 `b1>=1`、`1<=b2,b3<=9` 和任意正既约分子均不可能给出原
exact lift。第一分母与三个分子没有预设搜索上界。本节合并
`n3>=2` 的 [DD 完整证书](branches/double-deficit/core.md#single-digit-last-two-denominators-complete-dd-certificate)
与以下 `n3=1` 证书；不覆盖多位第二或第三分母。

### 分母投影与其必要条件

此时 `m2=m3=1`，`Q=10b1+b2`、`D=100b1+10b2+b3`。
§10.6 的完整素幂整除先给
`b1|lcm(b2,b3,10b2+b3)`，共 **994** 个分母三元组，最大第一分母
为 `6408`。再应用以下来自原 word/sphere 的必要条件：

1. §10.5 的 `b3|10Q`。
2. 正二进最大深度 `E` 唯一；`E>0` 时尾分母必须偶，尾分子既约
   为奇，从而 `v2(D)=E`。若 `E>=2`，其他分母中恰有一个深度为
   `E-1` 会在 sphere 模八产生 `H²=5 mod8`，必须排除。
3. 任一素数的最大深度独占时，或 inert prime 的最大深度只由两个
   分母取得时，最浅 sphere 层不能为零，故 `vp(D)>=E`。
4. §10.2 的分母 norm：剥去共同三进深度后，三个单位化分母的
   pair-product sum 不得为 `3/6 mod9`。
5. 若 `b3=5` 且 `5∤b1b2`，则 `Q=4 mod5`。确实，写 `q=5q0`，
   原 word 给 `q0*a3=(2Q+1)H mod5`，sphere 给
   `H²=(q0*a3)² mod5`；单位平方消去得 `(2Q+1)²=1 mod5`。
   `Q=b2!=0 mod5` 排除 `Q=0`，只余 `Q=4`。这里没有使用仅适用于
   `n3>=2` 的更强模二十五条件。

这些条件适用于任意分子位数。其完整投影正好留下 **19** 个三元组：

```text
(11,1,1) (5,1,5) (15,1,5) (7,2,8) (33,3,3)
(5,5,1) (15,5,1) (85,5,1) (255,5,1) (265,5,3)
(1,5,5) (11,5,5) (55,5,5) (40,5,6) (280,5,6)
(1,6,8) (15,7,5) (77,7,7) (99,9,9)
```

它们只是必要条件投影，尚未判为原解。DD 的模二十五投影恰好留下
同一列表；完整子域结论仍须以下分子重构证书。

### `n3=1` 的全部分子高度归约

固定上述分母，令 `q=lcm(b1,b2,b3)`、`X=10^n2`；尾分子
`1<=a3<=9`。若 `n2>=2`，原拼接与三角不等式给

```math
\frac{10Xa_1}{D}<R<\frac{a_1}{b_1}+\frac{X}{b_2}+\frac9{b_3},
\qquad
a_1< F(X):=\frac{X/b_2+9/b_3}{10X/D-1/b_1}.
```

`D/b1<=199`，所以 `X>=100` 时分母严格正。`F(X)` 的导数严格负，
故 `a1<=A1=ceil(F(100))-1`，在这 19 组中 `A1<=823`。
整数 sphere 中 `H-(q/b2)a2` 为正整数，因而

```math
a_2<\frac{qb_2}{2}
\left[\left(\frac{A_1}{b_1}\right)^2+
      \left(\frac9{b_3}\right)^2\right].
```

取严格整数上界后，全部 19 组都满足 `n2<=5`。程序针对实际 `X`
再取 `ceil(F(X))-1`，枚举 `a1,a3` 并恢复所有正整数 `a2`。
若 `n2=1`，仅枚举 `1<=a2,a3<=9`，直接恢复**全部**正整数 `a1`，
不对它作高度截断。两片均从原式
`q² alpha²=D² sum((q/bi ai)²)` 生成二次方程；标准和 factored
reader 穷尽所有正整数根，包括二次项为零的线性退化，并检查实际
位数、既约性和原方程。

### 精确证书与独立核对

```bash
uv run python scripts/exact-lift/check_single_digit_suffix.py
uv run python scripts/exact-lift/check_single_digit_suffix.py --reader factored
uv run python scripts/exact-lift/double-deficit/research-checks/tail/check_dd_last_two_single_digit_denominators.py
uv run python scripts/exact-lift/double-deficit/research-checks/tail/check_dd_last_two_single_digit_denominators.py --reader factored
g++ -O2 -std=c++20 -Wall -Wextra scripts/exact-lift/double-deficit/research-checks/tail/check_dd_last_two_single_digit.cpp -o /tmp/check-dd-last-two-single-digit
/tmp/check-dd-last-two-single-digit --tail-one
/tmp/check-dd-last-two-single-digit --tail-one --standard
/tmp/check-dd-last-two-single-digit
/tmp/check-dd-last-two-single-digit --standard
```

`n3=1` 的两种 Python reader 各核对 **45,015** 行，`n3>=2` 的两种
reader 各核对 **3,759,479** 行，均为零个原解。独立 C++ 程序重新
生成全部分母、精确有理边界和二次方程，两种判别式逐组得到相同
计数。C++ 使用有溢出检查的 256 位整数，所有判别式在正文归约盒
中小于 `2^190`；超出算术范围会直接报错。所有原生 `uint64` 边界
乘式的粗上界为 `70,701,190,630,418,880<2^56`。本子域二次项不会
退化：恢复 `a3` 时 `D>b3`；恢复 `a2` 时 `D` 末位非零而
`10^n3*b2` 末位为零；尾一位的两个恢复则分别有 `D>10b2`、
`D>100b1`。C++ 对此直接断言，Python 另具通用线性退化处理。
完整 UBSan 四模式复算没有诊断。单次标准或 factored
覆盖合计 **3,804,494** 行。

这里的有限计算闭合来自已证明的全部参数归约，绝不把截断搜索
当作无界证明。三个完整异常分支仍有多位分母的无界核心。

---

# 11. Gaussian 整数结构与当前边界

整数球面有

\[
y_1^2+y_2^2=(H-y_3)(H+y_3),
\]

同时在 \(\mathbf Z[i]\) 中

\[
y_1^2+y_2^2=(y_1+iy_2)(y_1-iy_2).
\]

这给出 Gaussian factor matching、split/inert prime allocation、norm squareclass 与局部容量约束。三个分支的大量严格中间结果都建立在这一接口上。

必须保留的全局边界是：

\[
\boxed{\text{Gaussian flip 一般不保持原 decimal coefficient plane。}}
\]

所以 Gaussian normalization 可以用于局部因子归约、source orientation、prime allocation 和 certificate；除非额外证明变换后的点仍满足 original exact-lift word equations、digit cells 与 reducedness，否则不能称为合法 descent。

当前完整证明仍必须回到三条权威分支：A2、DD、A1。任何外部或历史报告中的 `CLOSED` 标签都需要先通过当前 `status.md` 与分支 README 的 coverage 审计。
